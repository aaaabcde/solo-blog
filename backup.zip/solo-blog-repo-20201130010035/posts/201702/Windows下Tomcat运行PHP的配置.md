title: Windows下 Tomcat 运行 PHP 的配置
date: '2017-02-13 17:01:14'
updated: '2018-12-27 11:08:56'
tags: [PHP, Tomcat]
permalink: /articles/2017/02/13/1486976473999.html
---
# 前言：

由于本人在开发和学习过程中需要同时部署 JavaWeb 和 PHP 项目，于是整理了网上的一些相关资料，并结合自己的实际操作，记录于此，以供参考。

# 一、环境（64bit）：

## 1.操作系统、Tomcat 和 JDK 环境：
>```
>Server version: Apache Tomcat
>Server built: Mar 12 2016 11:39:59 UTC
>OS Name: Windows Server 2008
>Architecture: amd64
>Java Home: D:\Java\jre
>JVM Version: 1.8.0
>CATALINA_BASE: D:\Installed\Tomcat
>CATALINA_HOME: D:\Installed\Tomcat
>```
>（Tomcat 服务器和 Jdk 的配置很简单，需要的自己搜索）

Tomcat 下载地址：[http://archive.apache.org/dist/tomcat/](http://archive.apache.org/dist/tomcat/ "Tomcat下载")

JDK 下载地址：[http://www.oracle.com/technetwork/java/javase/downloads/index.html](http://www.oracle.com/technetwork/java/javase/downloads/index.html "JDK下载")

### 环境变量：
>```
>JAVA_HOME　　　　D:\Java
>CLASSPATH　　　　.\;%JAVA_HOME%\lib\tools.jar
>TOMCAT_HOME　　 D:\Installed\Tomcat
>Path　　　　　　　%JAVA_HOME%\bin;
>```

## 2.PHP环境：

我所使用的 PHP 版本为 7.0.5，下载地址：[http://windows.php.net/download/](http://windows.php.net/download/ "PHP 下载")
此版本的 PHP 需要 VC++ 2015 的运行环境(64bit)，[点击下载](https://download.microsoft.com/download/9/3/F/93FCF1E7-E6A4-478B-96E7-D4B285925B00/vc_redist.x64.exe "64位VC++2015")。
将下载后的 PHP 压缩包解压到 Tomcat 服务器根目录，命名为“php”。

### 环境变量：
> ```
>Path　　　　%TOMCAT_HOME%\php;
>```

# 二、配置：

## 1.配置 Context：

打开 Tomcat 根目录\conf\context.xml，找到  标签，添加属性： privileged=”true”
```xml
<Context privileged="true" antiResourceLocking="true">
  <WatchedResource>WEB-INF/web.xml</WatchedResource>
  <WatchedResource>${catalina.base}/conf/web.xml</WatchedResource>
</Context>
```

## 2.配置 Web-App：

打开 Tomcat 根目录\conf\web.xml，配置 php 的 Servlet：
```xml
<servlet>
	<servlet-name>php</servlet-name>
	<servlet-class>org.apache.catalina.servlets.CGIServlet</servlet-class>
	<init-param>
		<param-name>clientInputTimeout</param-name>
		<param-value>200</param-value>
	</init-param>
	<init-param>
		<param-name>debug</param-name>
		<param-value>0</param-value>
	</init-param>
	<init-param>
		<param-name>executable</param-name>
		<param-value>D:\Installed\Tomcat\php\php-cgi.exe</param-value>
		<!-- 此节点值为“php-cgi.exe”亦可 -->
	</init-param>
	<init-param>
		<param-name>passShellEnvironment</param-name>
		<param-value>true</param-value>
	</init-param>
	<init-param>
		<param-name>cgiPathPrefix</param-name>
		<param-value>WEB-INF/php</param-value>
	</init-param>
	<load-on-startup>5</load-on-startup>
</servlet>
```


## 3.配置 pnp.ini：
打开 Tomcat 根目录下的 php 目录，找到 php.ini-development 文件，复制一份重命名为 php.ini，修改 php.ini 文件：
### a) 启用 extension_dir（去掉前面的分号），设置 extension_dir 为 “Tomcat 根目录\php\ext”，或”ext”
### b) 设置 cgi.force_redirect 为 0

```properties
extension_dir = "D:\Installed\Tomcat\php\ext"
cgi.force_redirect = 0
```

# 三、部署 PHP，查看效果：
 1.在 Tomcat 根目录\webapps\ROOT\WEB-INF 目录下创建一个名为 “php”的目录，在目录中创建一个 PHP 测试文件 test.php：
```php
<?php
?>
```
 2.启动 Tomcat，访问 [http://127.0.0.1:8080/php/test.php](http://127.0.0.1:8080/php/test.php "查看效果") （Tomcat 默认端口为 8080），可以看到输出三行 Hello …!：

```
Hello World!
Hello Tanken·L!
Hello itanken.net!
```

[_**Done.**_](http://www.itanken.net/ "完成！")

>　来源：[http://www.cnblogs.com/iTanken/](http://www.cnblogs.com/iTanken/)
