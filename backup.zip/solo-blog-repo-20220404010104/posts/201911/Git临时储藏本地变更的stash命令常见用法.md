title: Git 临时储藏本地变更的 stash 命令常见用法
date: '2019-11-04 20:10:04'
updated: '2019-11-04 20:11:08'
tags: [Git, 命令行, 笔记]
permalink: /git-bash-stash-usage
---
临时保存的本地变更，储藏位置在 Git 栈中，与分支无关，所有分支共用一个储藏栈。

  1. 临时保存工作目录中已跟踪文件和暂存区的修改，以供后续切换回当前分支继续使用：

     ```bash
     git stash
     ```

  2. 同时保存工作目录未跟踪和已跟踪文件和暂存区的修改：

     ```bash
     git stash -u

     # 完整命令参数写法：
     git stash --include-untracked
     ```

  3. 查看临时保存记录，保存了几次就显示几条数据：

     ```bash
     $ git stash list

     # 执行结果：
     stash@{0}: WIP on master: d9b3b91 提交信息.
     stash@{1}: WIP on master: d9b3b91 提交信息.
     ```

  4. 临时保存并添加备注信息：

     ```bash
     # 储藏工作目录中已跟踪文件和暂存区的修改
     $ git stash save '修改的已跟踪文件'

     # 储藏工作目录中未跟踪的文件
     $ git stash save '添加的未跟踪文件' -u

     # 查看临时保存记录
     $ git stash list
     stash@{0}: On master: 添加的未跟踪文件
     stash@{1}: On master: 修改的已跟踪文件
     ```

  5. 储藏时只保存工作目录中的变更，保持已暂存的变更在暂存区中不动：

     ```bash
     git stash -k

     # 完整命令参数写法：
     git stash --keep-index
     ```

  6. 恢复上次临时保存的内容到工作目录，但在暂存区储藏的内容不会重新暂存，并在储藏栈中删除，`git stash list` 显示几条记录就可以执行此命令恢复几次：

     ```bash
     # 倒序恢复：stash@{1}
     git stash pop

     # 最后一条：stash@{0}
     git stash pop
     ```

  7. 恢复上次临时保存的内容到工作目录和暂存区，不会在储藏栈中自动删除：

     ```bash
     git stash apply --index
     ```

  8. 手动删除储藏栈中的无用内容，如通过 `git stash apply` 恢复后的遗留内容：

     ```bash
     # 多次执行逐条删除 stash@{0}
     git stash drop

     # 删除指定记录
     git stash drop stash@{0}
     ```

  9. 交互式储藏，由 Git 询问对每个变更的处理方式：

     ```bash
     $ git stash --patch

     # 执行效果：
     diff --git a/README.md b/README.md
     index b8f1529..d5c5175 100644
     --- a/README.md
     +++ b/README.md
     @@ -8,6 +8,7 @@
      1
      2
      3
     +
      git diff
      git diff2
      git diff3
     Stash this hunk [y,n,q,a,d,e,?]? 
     ```
  10. 恢复临时存储的内容到一个新的分支，并在储藏栈中删除，以避免恢复时发生冲突：

      ```bash
      $ stash branch StashBranch

      # 执行结果
      Switched to a new branch 'StashBranch'
      On branch StashBranch
      Changes not staged for commit:
        (use "git add <file>..." to update what will be committed)
        (use "git restore <file>..." to discard changes in working directory)
              modified:   README.md

      no changes added to commit (use "git add" and/or "git commit -a")
      Dropped refs/stash@{0} (e869a51f180db78e3520811a94a1e672d8f7cb71)
      ```

