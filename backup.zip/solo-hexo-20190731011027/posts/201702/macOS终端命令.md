title: macOS终端命令
date: '2017-02-13 17:36:38'
updated: '2017-03-19 23:56:03'
tags: [mac, 终端]
permalink: /articles/2017/02/13/1486978228421.html
---
苹果Mac OS X操作系统下，也有类似于Windows下面的CMD运行框！在这里你可以像 Windows 一样在 Mac 终端里面使用各种指令来操作你的Mac，例如：隐藏和显示文件，修改Hosts等等。

> ```
> # 用文本编辑来直接修改hosts
> sudo 
> /Applications/TextEdit.app/Contents/MacOS/TextEdit /etc/hosts
> 
> # 隐藏文件是否显示有很多种设置方法，最简单的要算在终端输入命令。显示/隐藏Mac隐藏文件命令如下(注意其中的空格并且区分大小写)：
> # 显示Mac隐藏文件的命令
> defaults write com.apple.finder AppleShowAllFiles -bool true 或者
> defaults write com.apple.finder AppleShowAllFiles YES
> # 隐藏Mac隐藏文件的命令
> defaults write com.apple.finder AppleShowAllFiles -bool false 或者
> defaults write com.apple.finder AppleShowAllFiles NO
> # 输完按Enter键，退出终端，重新启动Finder就可以了。
> 
> # 通过命终端令用 Finder 打开指定目录：
> open . # 打开当前用户根目录 
> open .. # 打开 /Users 目录
> open ./.m2 # 打开当前用户下的 .m2 目录
>
> # 清理右键“打开方式”的重复项：
> /System/Library/Frameworks/CoreServices.framework/Versions/A/Frameworks/LaunchServices.framework/Versions/A/Support/lsregister -kill -r -domain local -domain user;killall Finder;echo "打开方式已重建，Finder 即将重启。"
> ```

> *   mac os x terminal清屏快捷键: cammand+k （clear只是滚动，并未清空）
> *   linux系统清屏快捷键 : ctrl+l (reset)
> *   windows 命令行清屏命令: cls

## 实用终端命令行

> 1.  阻止Mac运行屏幕保护和睡眠：caffeinate -t 3600 ` 一小时内不进入睡眠状态 `
> 2.  解压PKG文件：pkgutil –expand macx.pkg ~/Desktop/  ` 将macx.pkg文件解压至桌面 ` 
> 3.  释放内存：purge   ` purge命令可以清除内存和硬盘的缓存，与重启Mac的效果差不多 ` 
> 4.  开启多个相同应用：open -n /Applications/QQ.app  ` 使用-n可以开启多个QQ应用 ` 
> 5.  不通过App Store更新macOS：sudo softwareupdate -i -a  ` 使用终端升级系统 ` 
> 6.  将所有下载过的文件列出来：sqlite3 ~/Library/Preferences/com.apple.LaunchServices.QuarantineEventsV* ‘select LSQuarantineDataURLString from LSQuarantineEvent’ |more
> 7.  隐藏文件或文件夹：chflags hidden ~/Desktop/macx  ` 隐藏桌面上的macx文件夹。若显示该文件夹，只需将hidden改为nohidden即可 ` 
> 8.  自动输入文件路径：从Finder中将任意文件拖拽至终端窗口即可获得文件的详细路径
> 9.  自动补齐文件／文件夹名：在终端命令中输入文件或文件夹的首字母后再按tab键即可自动补齐剩余字母
> 10.  创建有密码保护的压缩文件：zip -e protected.zip ~/Desktop/macx.txt  ` 将桌面上的macx.txt文件创建成有密码保护压缩文件protected.zip ` 
> 11.  关闭macOS系统开机声音：sudo nvram SystemAudioVolume=%80  ` 恢复开机声音：sudo nvram -d SystemAudioVolume ` 
> 12.  设置截图保存默认格式：defaults write com.apple.screencapture type jpg
>      然后重启SystemUIServer：killall SystemUIServer  ` 保存为Gif格式命令为：defaults write com.apple.screencapture type gif ` 
> 13.  设置截图默认保存位置：defaults write com.apple.screencapture location ~/Pictures/截图/  ` 需要提前创建好此文件夹 ` 
>      然后重启SystemUIServer：killall SystemUIServer

## 终端命令大全

> ### 目录操作
> 
> | 命令名 | 功能描述 | 使用举例 |
> | --- | --- | --- |
> | mkdir | 创建一个目录 | mkdir dirname |
> | rmdir | 删除一个目录 | rmdir dirname |
> | mvdir | 移动或重命名一个目录 | mvdir dir1 dir2 |
> | cd | 改变当前目录 | cd dirname |
> | pwd | 显示当前目录的路径名 | pwd |
> | ls | 显示当前目录的内容 | ls -la |
> | dircmp | 比较两个目录的内容 | dircmp dir1 dir2 |
> 
> ### 文件操作
> 
> | 命令名 | 功能描述 | 使用举例 |
> | --- | --- | --- |
> | cat | 显示或连接文件 | cat filename |
> | pg | 分页格式化显示文件内容 | pg filename |
> | more | 分屏显示文件内容 | more filename |
> | od | 显示非文本文件的内容 | od -c filename |
> | cp | 复制文件或目录 | cp file1 file2 |
> | rm | 删除文件或目录 | rm filename |
> | mv | 改变文件名或所在目录 | mv file1 file2 |
> | ln | 联接文件 | ln -s file1 file2 |
> | find | 使用匹配表达式查找文件 | find . -name “*.c” -print |
> | file | 显示文件类型 | file filename |
> | open | 使用默认的程序打开文件 | open filename |
> 
> ### 选择操作
> 
> | 命令名 | 功能描述 | 使用举例 |
> | --- | --- | --- |
> | head | 显示文件的最初几行 | head -20 filename |
> | tail | 显示文件的最后几行 | tail -15 filename |
> | cut | 显示文件每行中的某些域 | cut -f1,7 -d: /etc/passwd |
> | colrm | 从标准输入中删除若干列 | colrm 8 20 file2 |
> | paste | 横向连接文件 | paste file1 file2 |
> | diff | 比较并显示两个文件的差异 | diff file1 file2 |
> | sed | 非交互方式流编辑器 | sed “s/red/green/g” filename |
> | grep | 在文件中按模式查找 | grep “^[a-zA-Z]” filename |
> | awk | 在文件中查找并处理模式 | awk ‘{print $1 $1}’ filename |
> | sort | 排序或归并文件 | sort -d -f -u file1 |
> | uniq | 去掉文件中的重复行 | uniq file1 file2 |
> | comm | 显示两有序文件的公共和非公共行 | comm file1 file2 |
> | wc | 统计文件的字符数、词数和行数 | wc filename |
> | nl | 给文件加上行号 | nl file1 >file2 |
> 
> ### 安全操作
> 
> | 命令名 | 功能描述 | 使用举例 |
> | --- | --- | --- |
> | passwd | 修改用户密码 | passwd |
> | chmod | 改变文件或目录的权限 | chmod ug+x filename |
> | umask | 定义创建文件的权限掩码 | umask 027 |
> | chown | 改变文件或目录的属主 | chown newowner filename |
> | chgrp | 改变文件或目录的所属组 | chgrp staff filename |
> | xlock | 给终端上锁 | xlock -remote |
> 
> ### 编程操作
> 
> | 命令名 | 功能描述 | 使用举例 |
> | --- | --- | --- |
> | make | 维护可执行程序的最新版本 | make |
> | touch | 更新文件的访问和修改时间 | touch -m 05202400 filename |
> | dbx | 命令行界面调试工具 | dbx a.out |
> | xde | 图形用户界面调试工具 | xde a.out |
> 
> ### 进程操作
> 
> | 命令名 | 功能描述 | 使用举例 |
> | --- | --- | --- |
> | ps | 显示进程当前状态 | ps u |
> | kill | 终止进程 | kill -9 30142 |
> | nice | 改变待执行命令的优先级 | nice cc -c *.c |
> | renice | 改变已运行进程的优先级 | renice +20 32768 |
> 
> ### 时间操作
> 
> | 命令名 | 功能描述 | 使用举例 |
> | --- | --- | --- |
> | date | 显示系统的当前日期和时间 | date |
> | cal | 显示日历 | cal 8 1996 |
> | time | 统计程序的执行时间 | time a.out |
> 
> ### 网络与通信操作
> 
> | 命令名 | 功能描述 | 使用举例 |
> | --- | --- | --- |
> | telnet | 远程登录 | telnet hpc.sp.net.edu.cn |
> | rlogin | 远程登录 | rlogin hostname -l username |
> | rsh | 在远程主机执行指定命令 | rsh f01n03 date |
> | ftp | 在本地主机与远程主机之间传输文件 | ftp ftp.sp.net.edu.cn |
> | rcp | 在本地主机与远程主机 之间复制文件 | rcp file1 host1:file2 |
> | ping | 给一个网络主机发送 回应请求 | ping hpc.sp.net.edu.cn |
> | mail | 阅读和发送电子邮件 | mail |
> | write | 给另一用户发送报文 | write username pts/1 |
> | mesg | 允许或拒绝接收报文 | mesg n |
> 
> ### Korn Shell 命令
> 
> | 命令名 | 功能描述 | 使用举例 |
> | --- | --- | --- |
> | history | 列出最近执行过的 几条命令及编号 | history |
> | r | 重复执行最近执行过的 某条命令 | r -2 |
> | alias | 给某个命令定义别名 | alias del=rm -i |
> | unalias | 取消对某个别名的定义 | unalias del |
> 
> ### 其它命令
> 
> | 命令名 | 功能描述 | 使用举例 |
> | --- | --- | --- |
> | uname | 显示操作系统的有关信息 | uname -a |
> | clear | 清除屏幕或窗口内容 | clear |
> | env | 显示当前所有设置过的环境变量 | env |
> | who | 列出当前登录的所有用户 | who |
> | whoami | 显示当前正进行操作的用户名 | whoami |
> | tty | 显示终端或伪终端的名称 | tty |
> | stty | 显示或重置控制键定义 | stty -a |
> | du | 查询磁盘使用情况 | du -k subdir |
> | df | 显示文件系统的总空间和可用空间 | df /tmp |
> | w | 显示当前系统活动的总信息 | w |

[相关参考资料](http://www.jianshu.com/p/3291de46f3ff)
