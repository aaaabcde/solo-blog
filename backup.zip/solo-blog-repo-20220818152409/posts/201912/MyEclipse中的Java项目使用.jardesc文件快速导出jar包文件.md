title: (My)Eclipse 中的 Java 项目使用 .jardesc 文件快速导出 jar 包文件
date: '2019-12-08 15:59:00'
updated: '2019-12-08 15:59:00'
tags: [Java, 工具, 分享]
permalink: /my-eclipse-java-jardesc-export-jar
---
![](https://img.hacpai.com/bing/20181125.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 导出 JAR 包的常规操作

在 Eclipse 或 MyEclipse 中，未使用 Maven 或其他构建工具的 Java 项目，导出 jar 包文件的操作非常繁琐，基本要经历以下步骤：

1. 右键项目，点击 `Export` 导出功能菜单：
   ![image.png](https://img.hacpai.com/file/2019/12/image-f8b30f3f.png)

2. 在弹出的 `Export` 窗口中选择 `Java` > `JAR file`，如果是可执行 jar 文件则需要选择  `Runnable JAR file`，然后点击 <kbd>Next &gt;</kbd> 按钮进入下一步：
   ![image.png](https://img.hacpai.com/file/2019/12/image-d74929a9.png)

   > Export resources into a JAR file on the local file system.

   `JAR file` 选项用于  “将资源导出到本地文件系统上的JAR文件中”。

3. 在 `JAR Export` 窗口中，通常需要再进行以下操作：
   ![image.png](https://img.hacpai.com/file/2019/12/image-9129af57.png)
   - 取消选择 lib 文件夹，防止将依赖的 jar 文件包含进去使导出的 jar 包文件过大；
   - 取消选择 `.classpath` 和 `.project` 等 (My)Eclipse 专用的配置文件；
   - 点击 `JAR file:` 项目后的 <kbd>Browser...</kbd> 按钮选择 jar 包的导出路径；
   - 在 `Options:` 项目下选中需要的选项。

   > Define which resources should be exported into the JAR.

   如上所示，此步用于 “定义哪些资源应该导出到 JAR 中”，是所有操作中最复杂的一步。

4. 此时可以点击 <kbd>Finish</kbd> 按钮直接导出 jar 包或点击 <kbd>Next &gt;</kbd> 按钮进行一些其他的配置后再完成导出，此步也是本文说明的重点：
   ![image.png](https://img.hacpai.com/file/2019/12/image-8adf6966.png)

   需要进行的操作就是选中最后一项 `Save the description of this JAR in the workspace`，即将该 JAR 包的描述文件保存在工作区中，然后点击 `Description file:` 项目后的 <kbd>Browser...</kbd> 按钮选择描述文件的保存位置。

   此步骤的下一步用于自定义 JAR 文件的清单文件（MANIFEST.MF）` Customize the manifest file for the JAR file`，通常无需进行此步，直接完成导出即可。

### 一键快速导出 JAR 包

如果每次都按以上的操作步骤导出 jar 包，可想而知是极其浪费时间的一件事，此时就到了说明上述第 4 步中保存的 **.jardesc** 文件的时候。

#### 先说明一下此文件的作用

> The **jardesc file extension** is associated with the **Eclipse**, an integrated development environment for Windows, Apple Mac and Linux.
> The **jardesc** files contain saved settings for exported .jar JAVA archive files.

上述参考信息地址：https://www.file-extensions.org/jardesc-file-extension

大意就是 **jardesc 文件扩展名** 与 Eclipse 相关联，**jardesc** 文件包含导出的 .jar 包文件已保存的设置。

**.jardesc** 文件的内容其实就是 XML 文件，包含了之前导出 jar 包进行的所有配置：

```xml
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<jardesc>
    <jar path="E:/Files/Desktop/Test.jar"/>
    <options buildIfNeeded="true" compress="true" descriptionLocation="/zTest/ExportJar.jardesc" exportErrors="true" exportWarnings="true" includeDirectoryEntries="false" overwrite="true" saveDescription="true" storeRefactorings="false" useSourceFolders="false"/>
    <storedRefactorings deprecationInfo="true" structuralOnly="false"/>
    <selectedProjects/>
    <manifest generateManifest="true" manifestLocation="" manifestVersion="1.0" reuseManifest="false" saveManifest="false" usesManifest="true">
        <sealing sealJar="false">
            <packagesToSeal/>
            <packagesToUnSeal/>
        </sealing>
    </manifest>
    <selectedElements exportClassFiles="true" exportJavaFiles="false" exportOutputFolder="false">
        <javaElement handleIdentifier="=zTest/src"/>
    </selectedElements>
</jardesc>
```

#### 然后说一下此文件的使用方法

在 (My)Eclipse 直接点击此文件，或者右键此文件，然后依次选择 `Open With` > `JAR Export Wizard`：
![image.png](https://img.hacpai.com/file/2019/12/image-8b5b8531.png)

在弹出的 `Export` 窗口中，可以看到之前导出 JAR 包时的设置依然存在，此时如果没有需要改动的设置，还是按照之前的设置导出 JAR 包，直接点击 <kbd>Finish</kbd> 按钮导出即可，无需进行其他任何操作，大大提高了导出效率，节省操作时间。

![jardesc.gif](https://img.hacpai.com/file/2019/12/jardesc-d95a0377.gif)

