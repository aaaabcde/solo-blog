title: 使用 Office 打开下载的 xlsx 格式 Excel 文件报“文件已损坏，无法打开”错误问题处理
date: '2021-08-09 10:07:04'
updated: '2021-12-25 21:45:04'
tags: [Windows, Office, Excel, xlsx]
permalink: /windows-office-open-download-xlsx-excel-error-file-corrupted
---
![](https://b3logfile.com/bing/20200915.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 概述

在使用 Office 打开下载的 xlsx 格式 Excel 文件可能会出现报“**文件已损坏，无法打开**”错误的问题，出现这种问题的原因是因为 Windows 系统会锁定来自网络或其他计算机的 xlsx 文件，以阻止 Office 打开此文件，来保护操作系统不被侵害。

### 解决方式一

在网络上很容易搜到一种解决方式，是通过在 Office 软件的“信任中心设置”中取消“受保护的视图”，这种方式一劳永逸，但却降低了系统的安全性。

![image.png](https://b3logfile.com/file/2021/08/image-3d946089.png)

### 解决方式二

个人发现的另外一种解决方式，是通过修改下载的 xlsx 文件属性，来允许打开当前下载的文件，来解决“文件已损坏，无法打开”的问题。

这样做唯一的缺点就是，打开每个下载的文件都需要单独去修改文件属性，打开多个文件时操作稍有繁琐，但却没有降低系统的安全性，保证了要打开的文件确实是自己信任的文件。操作步骤如下：

1. 右键下载的 xlsx 文件，点击“属性”选项：
   ![image.png](https://b3logfile.com/file/2021/08/image-8e56a2f5.png)
2. 勾选“解除锁定”，点击 <kbd>确定</kbd> 按钮即可：
   ![image.png](https://b3logfile.com/file/2021/08/image-86a619f4.png)

