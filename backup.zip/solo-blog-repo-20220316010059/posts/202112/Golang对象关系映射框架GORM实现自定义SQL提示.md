title: Golang 对象关系映射框架 GORM 实现自定义 SQL 提示
date: '2021-12-25 20:24:49'
updated: '2021-12-25 21:50:23'
tags: [Go, Golang, GORM, SQL]
permalink: /golang-gorm-custom-table-hints
---
![](https://b3logfile.com/bing/20210902.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

NO-ORMer 请绕道 👉 [Golang, ORMs, and why I am still not using one. (hydrogen18.com)](http://www.hydrogen18.com/blog/golang-orms-and-why-im-still-not-using-one.html)。

GORM 原生支持 3 种提示，分别是：

- `Index Hints`：MySQL 索引提示；
- `Optimizer Hints`：MySQL 优化器提示；
- `Comment Hints`：注释提示，在任意 SQL 关键字之前或之后添加 `/* */` 块注释。

> [Hints | GORM - The fantastic ORM library for Golang, aims to be developer friendly.](https://gorm.io/zh_CN/docs/hints.html)

所以 GORM 对 MySQL 的支持很好，然而本人工作中主要使用 SQL Server，其[表提示](https://docs.microsoft.com/zh-cn/sql/t-sql/queries/hints-transact-sql-table?view=sql-server-ver15) `WITH(...)` 会经常使用，所以查看了 GORM Hints 相关代码后，实现了 SQL Server 的 `WITH` 表提示，代码如下所示：

## TableHints.go

```go
package tool

import (
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
	"gorm.io/hints"
)

// TableHints 自定义 GORM 表提示
//
// @Author zixizixi.cn
type TableHints struct {
	Type string
	Keys []string
}

// ModifyStatement 实现 gorm.StatementModifier 接口方法
func (tableHint TableHints) ModifyStatement(stmt *gorm.Statement) {
	for _, name := range []string{"FROM", "INTO"} {
		stmtClause := stmt.Clauses[name]

		if stmtClause.AfterExpression == nil {
			stmtClause.AfterExpression = tableHint
		} else {
			stmtClause.AfterExpression = hints.Exprs{stmtClause.AfterExpression, tableHint}
		}

		stmt.Clauses[name] = stmtClause
	}
}

// Build 实现 clause.Expression 接口方法
func (tableHint TableHints) Build(builder clause.Builder) {
	if len(tableHint.Keys) > 0 {
		_, _ = builder.WriteString(tableHint.Type)
		_ = builder.WriteByte('(')
		for idx, key := range tableHint.Keys {
			if idx > 0 {
				_ = builder.WriteByte(',')
			}
			_, _ = builder.WriteString(key)
		}
		_ = builder.WriteByte(')')
	}
}

// With Sql Server 使用 WITH(?) 表提示
func (tableHint TableHints) With(names ...string) TableHints {
	return TableHints{Type: "WITH", Keys: names}
}

// UseWithNolock Sql Server 使用 WITH(NOLOCK) 表提示
func (tableHint TableHints) UseWithNolock() TableHints {
	return tableHint.With("NOLOCK")
}
```

## Usage

- WITH(NOLOCK) 脏读表提示

```go
import (
    "gorm.io/hints"
    "tool"
)

db.Clauses(tool.TableHints{}.UseWithNolock()).Find(&User{})
// SELECT * FROM users WITH(NOLOCK)
```

- 其他表提示

```go
import (
    "gorm.io/hints"
    "tool"
)

db.Clauses(tool.TableHints{}.With("NOWAIT")).Find(&User{})
// SELECT * FROM users WITH(NOWAIT)

db.Clauses(tool.TableHints{}.With("ROWLOCK")).Find(&User{})
// SELECT * FROM users WITH(ROWLOCK)
```

2021年12月25日一个人发布于[https://zixizixi.cn/golang-gorm-custom-table-hints](https://zixizixi.cn/golang-gorm-custom-table-hints)

