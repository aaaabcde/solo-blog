title: Windows下Nginx整合Tomcat和Jetty并通过两个域名分别访问
date: '2017-02-13 17:28:40'
updated: '2017-02-13 17:28:40'
tags: [Nginx]
permalink: /articles/2017/02/13/1486977986468.html
---
在实际的网站部署中，可能需要在同一个服务器上同时启动多个服务，比如一个Tomcat，端口为8080，和一个Jetty，端口为8081。由于域名解析时只能解析到默认的80端口，所以这时想要通过两个域名分别访问同一个服务器上的两个不同端口的服务，就需要用到[nginx](http://baike.baidu.com/link?url=2YWC9Im4wMIl9cjndyvkMsEI7GRRmHZXn_CZzcBbOadHOsmIRQ2kEsZtE_Pv2R3ABceEoTvipNP0lI1jTDi9M_) 。

Tomcat，Jetty和Nginx是什么这里就再不多说了，[百度一下，你就知道](https://www.baidu.com/s?wd=Tomcat+Jetty+Nginx&tn=84053098_3_dg&ie=utf-8)。这里只介绍Nginx整合两个服务的配置。

首先，需要到 [Nginx官网](http://nginx.org/en/download.html) 下载 [Windows版](http://nginx.org/download/nginx-1.10.2.zip) 的Nginx，这里使用的是1.10.2版。下载完成后直接解压至D盘根目录，路径根据自己实际情况决定。

然后找到解压目录中的conf目录，这里存放的是nginx的配置文件，找到nginx.conf文件，用文件编辑器（Notepad++等）打开，可以看到有一个默认开启的监听80端口的配置，将请求转发到localhost。此配置可以不用改动，直接在此配置下添加两条server配置。

### 先添加一条Tomcat的配置

> 
> `# Tomcat`
> server {
> listen 80; # 监听80端口
> server_name itanken.cn www.itanken.cn; # 转发通过此地址访问的请求
> if ($host = 'itanken.cn' ) { # 将请求重定向到带有 www 的域名
> rewrite ^/(.*)$ http://www.itanken.cn/$1 permanent;
> }
> location ~ \.(js|css|png|gif|jpg|ico|svg|otf|eot|ttf|woff|woff2)$ {
> root D:/Tomcat/webapps/ROOT/static; # 将Tomcat中的静态资源使用Nginx进行缓存
> expires 7d; # 缓存7天
> }
> location / {
> proxy_pass http://localhost:8080; # 将请求转发到Tomcat的8080端口
> }
> }
> 
> `通过此配置即可将通过域名itanken.cn访问的请求转发到端口为8080的Tomcat上。`

### 再添加一条Jetty的配置

> `#Jetty`
> server {
> listen 80;
> server_name itanken.net www.itanken.net; # 转发通过此地址访问的请求
> location / {
> proxy_pass http://localhost:8081; # 将请求转发到8081端口
> }
> }
> 
> `通过此配置即可将通过域名itanken.net访问的请求转发到端口为8081的Jetty上。`

到这里配置就基本完成了，打开cmd窗口，进入Nginx根目录，通过命令start nginx.exe启动nginx，然后分别访问两个域名查看效果。

示例：[http://www.itanken.cn/](http://www.itanken.cn/) 和 [http://www.itanken.net/](http://www.itanken.net/) 这两个域名都是解析到同一个IP上的，但是通过Nginx，转发到了两个不同的服务。

[相关参考资料：http://zyjustin9.iteye.com/blog/2017394](http://zyjustin9.iteye.com/blog/2017394)

> nginx 中，应该使用`try_files`来判断文件是否存在
> 
> location / {
> try_files index.html index.php =404;
> }
