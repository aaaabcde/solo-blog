title: Git Bash 命令之 reflog 查看引用的指向记录
date: '2019-11-05 15:59:58'
updated: '2019-11-05 15:59:58'
tags: [Git, 命令行, 笔记]
permalink: /git-bash-reflog-usage
---
![](https://img.hacpai.com/bing/20190521.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


`reflog` 一般用于分支被删除后查找分支的指向（移动）记录，以便恢复被删除的分支：

1. 查看 `HEAD` 的引用记录，找到被删除分支的提交：

   ```bash
   git reflog
   ```

2. 通过在引用记录中找到的提交重新创建被删除的分支：

   ```bash
   git checkout -b temp c45acc6
   ```

### 与 `log` 的区别

- `git log` 的来源对象的是提交 `commits`；
- `git reflog` 的来源对象是引用 `refs`（头指针、分支、标签）。

- `git log` 查看的是哪些引用 `refs` 指向了哪些提交（最新提交及其家族提交）；
  - _家族提交_ 是指最新提交的父提交、兄弟提交（其他分支）、祖宗提交等等；
- `git reflog` 查看的是指定的引用（默认为 `HEAD`）当前及曾经指向过哪些提交。

### 更多使用方法

  ```bash
  git reflog [引用（HEAD|分支|标签）]
  ```

1. 查看 `HEAD` 的引用记录（头指针指向提交对象的移动记录）：

   ```bash
   # 本地头指针
   git reflog
   # 或者
   git reflog HEAD

   # 远程头指针
   git reflog origin/HEAD
   ```

2. 查看指定分支的引用记录（分支指向提交对象的移动记录）：

   ```bash
   # 本地分支
   git reflog master

   # 远程分支
   git reflog origin/master
   ```

3. 查看指定标签的引用记录（标签固定不动且默认无引用日志，默认情况下此命令无意义，不会输出任何内容，若想输出内容，创建标签时必须使用 `--create-reflog` 创建标签的引用日志）：

   ```bash
   git reflog v1.0
   ```

### 其他用法

`reflog` 支持部分 `log` 命令的参数，如 `--stat`、`--author` 等等：

- 查看引用记录及其指向的提交的概要统计：

   ```bash
   git reflog master --stat
   ```

- 查看引用指向特定用户的提交的历史记录：

   ```bash
   git reflog master --author username
   ```

- 另外，`reflog` 还有一些通常不会使用的选项，如 `expire` 用于删除较旧的过期引用记录、`delete` 用于删除指定引用记录，详见 <https://git-scm.com/docs/git-reflog>。

