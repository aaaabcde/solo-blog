title: Linux 系统使用 CUPS 打印文件相关命令
date: '2022-09-28 14:36:20'
updated: '2022-09-28 14:36:20'
tags: [Linux, Unix, CUPS, 打印]
permalink: /linux-unix-cups-printers-shell-command
---
![](https://b3logfile.com/bing/20220604.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

- `OpenPrinting CUPS`：[https://openprinting.github.io/cups/](https://openprinting.github.io/cups/)
  
  由 [OpenPrinting](https://openprinting.github.io/) 为 Linux® 和其他类 Unix® 的操作系统开发的基于标准的开源打印系统。CUPS 使用 [IPP Everywhere™](https://www.pwg.org/ipp/everywhere.html) 来支持对本地和网络打印机的打印。
  
  > The current standards-based, open source printing system developed by [OpenPrinting](https://openprinting.github.io/) for Linux® and other Unix®-like operating systems. CUPS uses [IPP Everywhere™](https://www.pwg.org/ipp/everywhere.html) to support printing to local and network printers.
- `CUPS-PDF`：[https://www.cups-pdf.de/](https://www.cups-pdf.de/)
  
  该软件旨在通过在 central fileserver 上提供 PDF 打印机来在异构网络中生成 PDF 文件。
  
  > This software is designed to produce PDF files in a heterogeneous network by providing a PDF printer on the central fileserver.

## 安装 PDF 打印机

**仅用于测试执行打印命令，实际打印请使用真实的打印机名称。**

- Ubuntu
  
  ```shell
  sudo apt install -y cups-pdf
  ```
- CentOS
  
  ```shell
  sudo yum install -y cups-pdf
  ```

## 设置默认打印机

- Ubuntu
  
  `PDF` 替换为实际打印机名称：
  
  ```shell
  lpoptions -d PDF
  ```
- CentOS
  
  `Cups-PDF` 替换为实际打印机名称：
  
  ```shell
  lpoptions -d Cups-PDF
  ```

## 查看全部打印机状态及默认打印机

```shell
lpstat -p -d
```

## 使用默认打印机打印文件

`filename` 替换为实际文件路径：

```shell
lp filename
```


