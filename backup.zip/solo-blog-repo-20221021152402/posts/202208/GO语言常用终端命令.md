title: GO 语言常用终端命令
date: '2022-08-05 17:32:26'
updated: '2022-09-22 11:23:51'
tags: [Go, Golang, bat, 命令行]
permalink: /go-command
---
## 环境

- 操作系统：windows
- GO 版本：1.19

## 本文占位符说明

- `ProjectRoot`：GO 项目源码根路径；
- `ProjectName`：GO 项目名称；
- `%GOROOT%`：GO SDK 安装目录环境变量，unix 中为 `$GOROOT`；

## 安装 GO 程序最新版到 `%GOPATH%/bin`

```shell
go install github.com/google/gops@latest
```

## 直接编译运行某 GO 程序的指定版本命令

```shell
go run github.com/swaggo/swag/cmd/swag@v1.8.1 fmt
```

## 查看当前目录下所有的包

```shell
# cd ProjectRoot

go list ./...
```

<details>
<summary>展开/收起输出内容</summary>

```text
ProjectName
ProjectName/assets
ProjectName/config
ProjectName/database
ProjectName/initialization
ProjectName/middleware
```

</details>

## 查看 GO 程序文件的编译信息

```shell
# go install github.com/google/gops@latest
# cd %GOROOT%/bin

go version -m gops.exe
```

<details>
<summary>展开/收起输出内容</summary>

```text
gops.exe: go1.19
        path    github.com/google/gops
        mod     github.com/google/gops  v0.3.25 h1:Pf6uw+cO6pDhc7HJ71NiG0x8dyQTeQcmg3HQFF39qVw=
        dep     github.com/go-ole/go-ole        v1.2.6  h1:/Fpf6oFPoeFik9ty7siob0G6Ke8QvQEuVcuChpwXzpY=
        dep     github.com/keybase/go-ps        v0.0.0-20190827175125-91aafc93ba19      h1:WjT3fLi9n8YWh/Ih8Q1LHAPsTqGddPcHqscN+PJ3i68=
        dep     github.com/shirou/gopsutil/v3   v3.22.4 h1:srAQaiX6jX/cYL6q29aE0m8lOskT9CurZ9N61YR3yoI=
        dep     github.com/xlab/treeprint       v1.1.0  h1:G/1DjNkPpfZCFt9CSh6b5/nY4VimlbHF3Rh4obvtzDk=
        dep     github.com/yusufpapurcu/wmi     v1.2.2  h1:KBNDSne4vP5mbSWnJbO+51IMOXJB67QiYCSBrubbPRg=
        dep     golang.org/x/sys        v0.0.0-20220520151302-bc2c85ada10a      h1:dGzPydgVsqGcTRVwiLJ1jVbufYwmzD3LfVPLKsKg+0k=
        build   -compiler=gc
        build   CGO_ENABLED=0
        build   GOARCH=amd64
        build   GOOS=windows
        build   GOAMD64=v1
```

</details>

## 静态检查

```shell
# cd ProjectRoot

go run honnef.co/go/tools/cmd/staticcheck@latest -f stylish ./...
```

<details>
<summary>展开/收起输出内容</summary>

```text
✖ 0 problems (0 errors, 0 warnings, 0 ignored)
```

</details>

### 另一个静态检查命令

```shell
go run github.com/mgechev/revive@latest -exclude ./vendor/... -formatter stylish ./...
```

此命令默认行为对命名检查比较严格，比如 `Api` 必须写为 `API`、`Http` 必须写为 `HTTP`、`Id` 必须写为 `ID` 和 `Sql` 必须写为 `SQL` 等等，
可以在配置文件中配置 [`[rule.var-naming]`](https://revive.run/r#var-naming) 白名单以便排除相关命名检查，如：

```toml
# revive.toml

[rule.var-naming]
  arguments = [["API", "SQL"], ["VM"]]
```

配置项 [`[rule.var-naming]`](https://revive.run/r#var-naming) 的参数类型为 `[2][]string`，第一个子切片为白名单，第二个子切片为黑名单。使用示例：

```shell
go run github.com/mgechev/revive@latest -config ./revive.toml -exclude ./vendor/... -formatter stylish ./...
```

## 漏洞检查

```shell
# 在项目根目录执行：
go run golang.org/x/vuln/cmd/govulncheck@latest ./...
```

## GO 文档服务

```shell
# cd ProjectRoot

go run golang.org/x/tools/cmd/godoc@latest -http=:6060 -index

# start http://127.0.0.1:6060/pkg/
```

## GO 模块

### 初始化 GO 模块

```shell
# mkdir ProjectName & cd ProjectName

go mod init ProjectName
```

### 下载 GO 模块依赖

```shell
go mod download
```

### 整理 GO 模块依赖

```shell
go mod tidy
```

### 添加 GO 模块依赖

```shell
go get github.com/godoes/go-figure
```

### 更新指定 GO 模块依赖

```shell
go get -d -u github.com/godoes/go-figure
```

### 更新全部 GO 模块依赖

```shell
go get -d -u
```

### 导入模块依赖到 vendor 目录

```shell
go mod vendor
```

## 使用批处理命令判断 GO 版本

```bat
rem 获取 go 版本
set gv=99999999999999999999
for /f "tokens=*" %%i in ('go version') do (
    set gv=%%i
)
set ver=%gv:~13,5%
:del-right
if "%ver:~-1%" equ "." set ver=%ver:~0,-1%&&goto del-right
if "%ver:~-1%" equ " " set ver=%ver:~0,-1%&&goto del-right
:goon
rem go 版本不能小于 1.18
if %ver% leq 1.17 (
  color 04
  echo. & echo 请使用 go1.18 或以上版本！ & echo.
  pause & exit
)

rem TODO more things...
go version
pause
```

## 使用批处理命令和链接目录动态修改 GO 版本

将以下代码保存为 `GOROOT.bat`，双击运行，输入本地已安装或解压的 go 版本，可以在保持 `GOROOT` 不变的前提下来动态切换 GO 版本：

```bat
@echo off
title 修改 GOROOT 链接路径

rem 如果是 setx "GOROOT" "D:\Dev\Go\SDK\go" /m 需要使用管理员权限运行
setx "GOROOT" "D:\Dev\Go\SDK\go"
go version
echo.

set /p ver=请输入 GO 版本（如 1.17.13）：
echo.

echo 开始切换 [go%ver%] 根路径：
echo.

rem 删除旧链接路径
rmdir %GOROOT%
rem 关联新链接路径
mklink /J "%GOROOT%" "D:\Dev\Go\SDK\versions\go%ver%"
echo.

go version
echo.

pause
```

比如 `GOROOT` 路径固定为 `D:\Dev\Go\SDK\go`，安装的多个 go 版本路径分别为：

- D:\Dev\Go\SDK\versions\go1.17.13
- D:\Dev\Go\SDK\versions\go1.18.5
- D:\Dev\Go\SDK\versions\go1.19.1

运行 `GOROOT.bat` 输入 `1.18.5` 即可切换到 `go1.18.5`，输入 `1.19.1` 即可切换到 `go1.19.1`：

```
成功: 指定的值已得到保存。
go version go1.17.13 windows/amd64

请输入 GO 版本（如 1.17.13）：1.18.5

开始切换 [go1.18.5] 根路径：

为 D:\Dev\Go\SDK\go <<===>> D:\Dev\Go\SDK\versions\go1.18.5 创建的联接

go version go1.18.5 windows/amd64

请按任意键继续. . .
```

```
成功: 指定的值已得到保存。
go version go1.18.5 windows/amd64

请输入 GO 版本（如 1.17.13）：1.19.1

开始切换 [go1.19.1] 根路径：

为 D:\Dev\Go\SDK\go <<===>> D:\Dev\Go\SDK\versions\go1.19.1 创建的联接

go version go1.19.1 windows/amd64

请按任意键继续. . .
```

## GO 版本管理工具命令

上述 `GOROOT.bat` 还是需要先手动下载安装或解压 GO 后才可以使用，如果有一个可以查看所有可安装的版本、自动下载安装或卸载、查看本地已安装的版本和切换到指定版本的 GO 版本管理工具，那就完美了。

这不，[https://github.com/voidint/g](https:%E2%80%B8github.com/voidint/g) 就是这样一个实用的工具：

```shell
go run github.com/voidint/g@latest -h

NAME:
  g - Golang Version Manager

 USAGE:
  g.exe  command [arguments...]

 VERSION:
  1.4.0

 AUTHOR:
  voidint <voidint@126.com>

 COMMANDS:
    ls         List installed versions
    ls-remote  List remote versions available for install
    use        Switch to specified version
    install    Download and install a version
    uninstall  Uninstall a version
    update     Fetch the newest version of g
    clean      Remove files from the package download directory
    help, h    Shows a list of commands or help for one command

 GLOBAL OPTIONS:
  --help, -h     show help (default: false)
  --version, -v  print the version (default: false)

 COPYRIGHT:
  Copyright (c) 2019-2022, voidint. All rights reserved.
```

在国内不 KXSW 的情况下，需要设置 `G_MIRROR` 环境变量为国内 GO 下载镜像地址：

```shell
G_MIRROR=https://golang.google.cn/dl/
```

如果需要自定义此 GO 版本管理工具的 GO 安装包下载和安装路径，需要设置以下环境变量：

```shell
G_EXPERIMENTAL=true
G_HOME=D:\Dev\Go\SDK
```

