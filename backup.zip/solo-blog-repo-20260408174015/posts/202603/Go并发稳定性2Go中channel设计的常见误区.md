title: Go 并发稳定性（2）：Go 中 channel 设计的常见误区
date: '2026-03-27 14:00:14'
updated: '2026-03-27 14:03:48'
tags: [Go, Golang, 并发, 协程]
permalink: /go-concurrency-stability-2-channel
---
![](https://b3logfile.com/bing/20230324.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

> 很多 Go 并发问题，并不是 goroutine 写错了，而是 channel 的设计从一开始就错了。

在实际项目中曾遇到过大量并发 bug：

* goroutine 泄露
* RT 抖动
* 队列堆积
* CPU 偶发飙升

最终根因往往不是 select，而是：

> channel 的语义设计不清晰。

这篇文章不讲 channel 的语法，而是讲 **生产环境中最常见的设计误区**。

---

## 一、先建立一个正确认知：channel 是通信协议，不是队列

很多开发者把 channel 当成 `线程安全队列`，这会直接导致设计方向错误。

channel 的本质是：

- 同步点（synchronization point）
- 通信协议（communication contract）
- 生命周期边界（lifecycle boundary）

它不是：

- 无限缓存队列
- 任务调度系统
- goroutine 管理器

一旦定位错，后面所有并发设计都会开始失控。

---

## 二、误区一：把 channel 当成任务队列

### 常见写法

```go
jobs := make(chan Job, 10000)

go producer(jobs)
go consumer(jobs)
```

看起来很合理，但真实系统中常见问题：

- `producer` 速度 > `consumer`
- channel 被塞满
- 请求阻塞在发送位置

最终表现：

- RT 变慢
- 上游超时
- 服务吞吐下降

---

### 问题本质

channel 提供的是 **背压机制**，而不是 *无限缓冲能力*。

---

### 正确思路

必须明确以下问题：

- 是否允许阻塞？
- 是否允许丢数据？
- 是否需要限流？

否则 channel 会变成隐藏的性能瓶颈。

---

## 三、误区二：滥用无缓冲 channel

无缓冲 channel 语义非常强:

- 发送必须等待接收

这意味着：

- 强同步
- 强耦合
- 延迟放大

---

### 典型问题场景

```go
func producer(ch chan Data) {
    for {
        data := generateData()
        ch <- data // 这里可能阻塞
    }
}

func consumer(ch chan Data) {
    for {
        data := <-ch
        process(data) // 假设这里比较慢
    }
}
```

如果接收端稍慢：

- producer 会频繁阻塞
- goroutine 堆积
- RT 开始抖动

> **无缓冲 channel 的发送操作是一个“同步阻塞点”，它会把上游速度强制绑定到下游。**

---

### 正确理解

无缓冲 channel 适合：

- 信号同步
- goroutine 交接控制权

不适合：

- 数据管道
- 异步任务

---

### 实战建议

默认优先考虑：

```go
make(chan T, N)
```

而不是：

```go
make(chan T)
```

除非你非常清楚自己在做同步设计。

---

## 四、误区三：控制信号和业务数据混用

这是一个非常隐蔽的设计问题。

### 反模式

```go
type Msg struct {
    Data string
    Stop bool
}
```

或者：

```go
chan interface{}
```

问题：

- 消息语义混乱
- 接收方需要解析逻辑
- 代码可读性下降

最终：

> 协议开始隐性化。

---

### 正确设计

控制信号与数据必须分离：

```go
dataCh := make(chan Data)
stopCh := make(chan struct{})
```

或者直接：

- context 负责控制
- channel 负责数据

这是生产级并发设计的重要分层。

---

## 五、误区四：close 语义不清晰

很多项目中，channel `close` 的责任是模糊的。

常见错误：

- 多方 `close`
- 接收方 `close`
- 不知道什么时候 `close`

最终导致：

```
panic: send on closed channel
```

---

### 正确规则（非常重要）

#### 规则一：

> 谁创建 channel，谁负责 `close`。

---

#### 规则二：

> 接收方永远不应该 `close`。

---

#### 规则三：

> 多生产者场景，通常不应该 `close`。

---

### 一个更稳定的方式

不要依赖 `close` 表达生命周期：

- 使用 context 控制退出

这会显著降低 panic 风险。

---

## 六、误区五：用 channel 管理 goroutine 生命周期

很多代码会这样写：

```go
done := make(chan bool)

go func() {
    <-done
    return
}()
```

问题在于：

- 控制信号缺乏层级
- 无法传播取消
- 无法统一管理

---

### 正确方式

统一使用：

```
context.Context
```

因为它提供：

- 级联取消
- 超时控制
- 统一入口

channel 只负责：

- 数据流

---

## 七、生产环境中的 channel 设计原则

总结几个非常实用的原则：

1. channel 是通信协议，不是任务队列
2. 默认使用带缓冲 channel
3. 控制信号与数据流分离
4. 谁创建 channel，谁关闭
5. 生命周期统一交给 context
6. 不要用 channel 模拟状态机

---

## 八、写在最后

Go 并发的稳定性，很多时候不是由高级技巧决定，而是由：

- 通信协议是否清晰
- 生命周期是否明确
- channel 语义是否单一

这些基础设计决定的。

如果 channel 的职责模糊，再多的优化都是在不稳定的基础上修补。

