title: CaddyServer 反向代理和 HTTPS 的相关使用介绍
date: '2019-04-12 10:20:02'
updated: '2019-04-15 19:38:53'
tags: [Caddy, Nginx, HTTPS, 反向代理]
permalink: /caddyserver-r-proxy-https
---
<details>
<summary>

![CaddyServer反向代理和HTTPS的相关使用介绍](https://res.zixizixi.cn/image/illust/caddyserver-r-proxy-https.png.coverimg)
</summary>

> 把 2 月份写的一个说明文档翻了出来，在博客上发表备份一下。
</details>

### 一、Caddy 基本信息介绍
 
#### 1. 官方介绍：

Caddy 是具有自动 HTTPS 的 [HTTP/2](https://www.baidu.com/s?ie=UTF-8&wd=HTTP/2)  Web服务器（使用 Golang  开发） 。

其他 Web 服务是专为 Web 设计的，但 Caddy 是专为人类设计的，并兼顾了当今的 Web。

#### 2. 特性说明：

<details>
<summary>✔ 静态文件</summary>

  默认情况下，Caddy 在当前工作目录中提供静态文件服务。它非常简单，工作速度快。

</details>

<details>
<summary>✔ 动态网站</summary>

  Caddy 还可用于通过模板、代理、FastCGI  和插件使用动态站点。

</details>

<details>
<summary>✔ 配置简单</summary>

  Caddyfile，一种简单，直观的配置站点的方法。它不是脚本，也不难记忆。

</details> 

<details>
<summary>✔ 零停机时间重载</summary>

  在进行配置更改后，使用 USR1 信号在 Unix 系统上正常重新加载 Caddy，停机时间为零。

</details>

<details>
<summary>✔ 可扩展核心</summary>

  可以通过插件扩展。所有服务器类型、指令、DNS 提供程序和更多功能都是插件！它们很容易编写并直接编译。

</details>

<details>
<summary>✔ 自动 TLS</summary>

  唯一默认使用 HTTPS 的 Web 服务器。具有现代协议的强化 TLS 堆栈可保护隐私并暴露 MITM 攻击。

</details>

<details>
<summary>✔ 跨平台使用</summary>
  支持 Windows、macOS、Linux、BSD、Android、Solaris、32-bit、x64、ARM、mips64 ......
</details>

<details>
<summary>✔ 使用多核 CPU</summary>

  当任务变得艰难时，Caddy 开始使用更多的 CPU。Go 的调度程序理解 Go 代码，而 goroutine  比系统线程更轻量级，所以它很快。

</details>

<details>
<summary>✔ 负载均衡</summary>

  使用您选择的负载平衡策略代理到多个后端：随机（默认）、最少连接、循环、IP 哈希或请求头等等。

</details>

#### 3. 下载 Caddy：
   
##### ① 直接下载：
通过浏览器访问 [`https://caddyserver.com/download`](https://caddyserver.com/download)  选择系统平台、插件等构建内容后直接点击下载按钮获取 Caddy 的二进制运行文件压缩包。

##### ② 一键安装：
Unix 系统通过终端运行命令 `curl https://getcaddy.com | bash -s personal`

> * macOS  中也可在终端中使用命令 `brew install caddy` 进行安装。

#### 4. 运行 Caddy：
   
Windows 系统下可直接双击 `caddy.exe` 运行，也可像 Unix 系统一样使用命令运行：
```shell
./caddy --conf  Caddyfile
```


### 二、Caddy 自动 HTTPS 的使用

#### 1. Caddyfile：
在这之前，首先需要了解一下 `Caddyfile`。
`Caddyfile`  是 Caddy 服务的配置文件，作用相当于 Nginx 的 `nginx.conf`，此文件一般放在 Caddy 二进制文件的同级目录，直接通过命令  ./caddy 即可运行，也可放于任意目录，但运行时需要通过参数 `--conf`  来设置文件的路径，如：
`./caddy --conf ../Caddyfile`

#### 2. 一个简单的 Caddyfile  示例：

```
example.com, www.example.com, 127.0.0.1 {
  gzip
  root /www/example.com
  log ../log/access.log
}
```

#### 3. 启用自动 HTTPS：
启用 HTTPS 的前提，首先是需要是有一台云服务器（IP 开放 80 端口），然后要确保系统的 80 和 443 端口未被其他程序占用。

以上述 Caddyfile  为基础，修改 Caddyfile  配置：
```
example.com, www.example.com, 127.0.0.1 {
  gzip
  root /www/example.com
  log ../log/access_tls.log

  tls  seves@cdyxsoft.com
}
```
以上配置通过 `tls`  命令 + `email` 启用自动 HTTPS，无需手动更新证书，此命令不是必须的。其中 `email` 用于生成具有可信 CA 的证书的电子邮件地址，这样就不用在启动时去输入了。

* 参考资料
> 1. https://dengxiaolong.com/caddy/zh/automatic-https.html
> 2. https://dengxiaolong.com/caddy/zh/tls.html

#### 4. 默认启用自动 HTTPS：
```
https://example.com, www.example.com, otherdomain.com {
  gzip
  root /www/example.com
  log ../log/access_https.log

  # 配置 301 重定向，访问顶级域名时自动跳转到 www 二级域名
  redir  301 {
    if {host} is example.com
    / https://www.{host}{uri}
  }

  header / {
    # 配置 HSTS（HTTP严格安全传输）
    Strict-Transport-Security "max-age=31536000;includeSubdomains;preload"
  }
}
```
在此处未使用 `tls`  命令，也是默认启用了 HTTPS 的，因为在开头的域名前指定了访问协议为 `https://`。
`redir` 命令用于配置重定向，后面的数字是返回给客户端的重定向 HTTP 状态码，如 `301`、`302` 等，相当于 Nginx 的 `redirect` 命令。
在这里还添加了一个响应头 `Strict-Transport-Security`，作用是如果浏览器是通过 HTTP 协议访问则自动转为用 HTTPS 协议进行访问，进一步增强安全性。

### 三、Caddy 反向代理服务的使用
<details>
<summary>反向代理</summary>
<blockquote>
在计算机网络中，反向代理是代理服务器的一种。服务器根据客户端的请求，从其关系的一组或多组后端服务器（如 Web 服务器）上获取资源，然后再将这些资源返回给客户端，客户端只会得知反向代理的 IP 地址，而不知道在代理服务器后面的服务器簇的存在。
</blockquote>
简单说明一下概念，内容来源于百度百科，更详细的内容请自行搜索了解。
</details>
<br>

<details>
<summary>负载均衡</summary>
反向代理可结合负载均衡使用，但负载均衡不是本次讲解的重点，简单说明一下策略，有以下几种负载均衡策略可用：
1. `random`(default)：随机选择一个后端地址
2. `least_conn`：选择活动连接最少的后端
3. `round_robin`：以循环方式选择后端
4. `first`：按照在 Caddyfile  中定义的顺序选择第一个可用后端
5. `ip_hash`：通过散列请求 IP 选择后端，根据后端总数在散列空间中均匀分布
6. `uri_hash`：通过散列请求 URI 选择后端，根据后端总数在散列空间中均匀分布
7. `header`：通过散列指定头的值（由策略名后面的 [value] 指定）进行选择，根据后端总数在散列空间中均匀分布

</details>

```mermaid
graph RL
    User1((客户端 1))
    User2((客户端 2))
    User3((客户端 3))

    User1 --请求 1--> CaddyServer
    User2 --请求 2--> CaddyServer
    User3 --请求 3--> CaddyServer

    CaddyServer -.响应 1.-> User1
    CaddyServer -.响应 2.-> User2
    CaddyServer -.响应 3.-> User3

    subgraph 反向代理 + 负载均衡
    CaddyServer
    end

    subgraph 后台服务
    WebServer1
    WebServer2
    WebServer3
    end
    WebServer1 --连接 1--- CaddyServer
    WebServer2 --连接 2--- CaddyServer
    WebServer3 --连接 3--- CaddyServer

   title>反向代理和负载均衡示意图]
```

#### 1. 反向代理相关配置：
```
https://example.com, https://www.example.com {
  gzip 
  log ../log/access_proxy.log
  header / {
      Strict-Transport-Security "max-age=31536000;includeSubdomains;preload"
  }
  ## HTTP 代理配置
  ### 此时访问 example.com，实际访问的是 127.0.0.1:8080/app/ 的内容
  proxy / 127.0.0.1:8080/app/

  ## WebSocket 代理配置
  ### 客户端请求的 wss://example.com/app/websocket, 实际为 wss://127.0.0.1:8080/app/websocket
  proxy /app/websocket 127.0.0.1:8080 {
      websocket
  }
}
```
此处第一个 `proxy` 命令的作用是，将 `127.0.0.1:8080/app/` 的内容反向代理到 `example.com`，这样客户端就可以通过 `HTTPS + 域名` 进行访问了。第二个 `proxy` 命令用于代理同站的 `websocket`，以启用 WebSocket 安全协议，因为反向代理启用 HTTPS 后，同源 WebSocket 必须使用 `wss` 协议，否则浏览器会拒绝连接到不安全的 WebSocket。

#### 2. 负载均衡简单配置（了解）：
```
proxy / web1.local:80 web2.local:90 web3.local:100 { 
  policy round_robin 
}
```
用反向代理命令 `proxy` 将请求循环转发到 80、90、100 三个后端服务，通过 `policy` 命令控制策略为 `round_robin`，以循环方式选择后端服务。


### 四、Caddy 与 Nginx 的简单对比

| 项目 | Caddy | Nginx |
| :---: | :------: | :------: |
| 入门难度 | 简单 | 较难 |
| 配置语法 | 简洁 | 复杂 |
| 功能扩展 | 支持，目前相对较少 | 支持，扩展较多且相对稳定 |
| 自动 HTTPS |  默认支持，配置简单 | 默认不支持，配置较难 |
| 多核 CPU | 支持 | 支持 |
| 跨平台使用 | 几乎支持市面上所有已知系统| 大多数操作系统 |
| 处理性能 | 性能较高，尤其是反向代理方面 | 性能高，系统资源占用率低 |
| 负载均衡 | 支持 | 支持 |

总而言之就是各有优缺，Nginx 强大而复杂，Caddy 先进而简约，但在某些方尚且面略逊一筹。由于 Nginx 起步较早且用 C 语言开发，故在底层上决定了其某些方面的性能比用 Go 语言开发的年轻 Caddy 相对更高一些，引用一句话就是：
> 如果说 Nginx 是成功中年人士，则 Caddy 是年轻高富帅。


### 参考资料：
> 1. 官方网站：https://caddyserver.com/
> 2. 第三方中文文档：https://dengxiaolong.com/caddy/zh/
