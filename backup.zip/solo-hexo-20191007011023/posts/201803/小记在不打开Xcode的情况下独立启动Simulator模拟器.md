title: 小记：在不打开 Xcode 的情况下独立启动 Simulator 模拟器
date: '2018-03-26 21:07:25'
updated: '2019-09-25 23:53:20'
tags: [Xcode, Mac, 工具, 笔记]
permalink: /not-open-xcode-standalone-simulator
---
![不打开 Xcode，独立启动 Simulator](//res.zixizixi.cn/image/illust/standalone-simulator.jpg.coverimg)

## 1. 显示 Xcode 包内容  

第一步：进入 <kbd>应用程序</kbd> 找到 `Xcode`，右键选择 `显示包内容`：
> ![显示 Xcode 包内容](//res.zixizixi.cn/image/illust/xcode1.jpg.zximg)

## 2. 进入 Applications 文件夹  

第二步：进入 `/Applications/Xcode.app/Contents/Developer/Applications` 目录：
> ![进入 Applications 文件夹](//res.zixizixi.cn/image/illust/xcode2.jpg.zximg)

## 3. 拷贝 Simulator.app 到应用程序  

第三步：选中 <kbd>Simulator.app</kbd>，拷贝此文件或选择`制作替身`（快捷方式）到 `Xcode.app` 所在的 `Applications`（应用程序） 目录：
> ![拷贝 Simulator.app 到应用程序](//res.zixizixi.cn/image/illust/xcode3.jpg.zximg)

然后就可以像其他应用程序一样可以在 __启动台__（_Launchpad_）或 __程序坞__（_Dock_）中启动 __模拟器__（_Simulator_）了。

> ![启动台图标](https://img.hacpai.com/file/2019/09/image-fdbedb26.png "Simulator快捷图标")  
> ![程序坞快捷图标](https://img.hacpai.com/file/2019/09/image-a2029ef4.png "Simulator快捷图标")  



