title: Wildfly 跨域相关响应头配置
date: '2019-02-13 13:15:21'
updated: '2019-10-10 23:05:56'
tags: [Java, Wildfly, JBoss]
permalink: /wildfly-cors-origin-config
---
![Wildfly 跨域相关响应头配置](https://res.zixizixi.cn/image/wildflycros.jpg.coverimg)

需要修改 Wildfly 对应的配置文件，如 `standalone.xml`、`standalone-full.xml` ：

### 1. 找到对应的 `subsystem` 节点
```xml
<subsystem xmlns="urn:jboss:domain:undertow:8.0" default-server="default-server">
  <!-- ...... -->
</subsystem>
```
不同版本的 Wildfly 此节点属性 `xmlns="urn:jboss:domain:undertow:8.0"` 的版本号可能有所不同。


### 2. 找到 `subsystem` 的子节点 `host`
```xml
<host name="default-host" alias="localhost">
  <!-- ...... -->
</host>
```

### 3. 在 `host` 节点下添加 `filter-ref`
```xml
<host name="default-host" alias="localhost">
  <filter-ref name="allow-origin-header"/><!-- 跨域 -->
  <filter-ref name="allow-headers-header"/><!-- 跨域 -->
</host>
```

### 4. 在 `filters` 节点中添加对应的节点
```xml
<filters>
	<response-header name="allow-origin-header" header-name="Access-Control-Allow-Origin" header-value="*"/><!-- 跨域 -->
	<response-header name="allow-headers-header" header-name="Access-Control-Allow-Headers" header-value="*"/><!-- 跨域 -->
</filters>
```
`filters` 子节点中的 `name` 属性必须与 `host` 字节点中的 `name` 属性值一一对应。

### 5. `subsystem` 节点详细配置
```xml
<subsystem xmlns="urn:jboss:domain:undertow:8.0" default-server="default-server" default-virtual-host="default-host" default-servlet-container="default" default-security-domain="other">
	<buffer-cache name="default"/>
	<server name="default-server">
		<http-listener name="default" socket-binding="http" redirect-socket="https" enable-http2="true"/>
		<https-listener name="https" socket-binding="https" security-realm="ApplicationRealm" enable-http2="true"/>
		<host name="default-host" alias="localhost">
			<location name="/" handler="welcome-content"/>
			<http-invoker security-realm="ApplicationRealm"/>
			<access-log pattern="combined" directory="${jboss.home.dir}/standalone/log" prefix="access."/>
			<filter-ref name="x-powered-by-header"/>
			<filter-ref name="allow-origin-header"/><!-- 跨域 -->
			<filter-ref name="allow-headers-header"/><!-- 跨域 -->
			<filter-ref name="server-header"/>
			<filter-ref name="not-found"/>
			<filter-ref name="static"/>
		</host>
	</server>
	<servlet-container name="default" default-encoding="UTF-8">
		<jsp-config development="true" x-powered-by="false"/>
		<websockets/>
	</servlet-container>
	<handlers>
		<file name="welcome-content" path="${jboss.home.dir}/welcome-content"/>
	</handlers>
	<filters>
		<response-header name="x-powered-by-header" header-name="X-Powered-By" header-value="zixizixi.com"/>
		<response-header name="allow-origin-header" header-name="Access-Control-Allow-Origin" header-value="*"/><!-- 跨域 -->
		<response-header name="allow-headers-header" header-name="Access-Control-Allow-Headers" header-value="*"/><!-- 跨域 -->
		<response-header name="server-header" header-name="Server" header-value="zixizixi.com"/>
		<error-page name="not-found" code="404" path="${jboss.home.dir}\welcome-content\404.html"/>
		<gzip name="static"/>
	</filters>
</subsystem>
```

#### 相关链接：
> https://developer.mozilla.org/zh-CN/docs/Web/HTTP/Headers/Access-Control-Allow-Origin
> https://developer.mozilla.org/zh-CN/docs/Web/HTTP/Headers/Access-Control-Allow-Methods
> https://developer.mozilla.org/zh-CN/docs/Web/HTTP/Headers/Access-Control-Allow-Headers
> https://developer.mozilla.org/zh-CN/docs/Web/HTTP/Headers/Access-Control-Allow-Credentials

