title: Golang 指针方法接收器是可以为 nil 的
date: '2022-08-03 15:32:32'
updated: '2022-09-22 11:23:29'
tags: [Go, Golang, 空指针]
permalink: /golang-methods-on-pointers-receiver-can-be-nil
---
```golang
package main

type NilReceiverStruct struct {
	Value string
}

func (n *NilReceiverStruct) String() string {
	if n == nil {
		return "I'm nil!"
	}
	return n.Value
}

func (n *NilReceiverStruct) PanicIfNil() string {
	return n.Value
}

func main() {
	var n *NilReceiverStruct = nil
	println("n.String() =", n.String())         // n.String() = I'm nil!
	println("n.PanicIfNil() =", n.PanicIfNil()) // panic: runtime error: invalid memory address or nil pointer dereference
}
```

如上代码所示，指针接收器是可以为 `nil` 的，所以为保证代码的稳定性，调用指针方法或方法内部需要注意判断接收器是否为 `nil`，否则可能会发生恐慌！

> panic: runtime error: invalid memory address or nil pointer dereference

