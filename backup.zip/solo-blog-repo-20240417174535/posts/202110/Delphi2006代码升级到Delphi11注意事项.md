title: Delphi 2006 代码升级到 Delphi 11 注意事项
date: '2021-10-21 13:30:26'
updated: '2021-10-21 13:30:26'
tags: [Delphi, SendMessage]
permalink: /articles/2021/10/21/1634794226331.html
---
![](https://b3logfile.com/bing/20171223.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## SendMessage 注意事项

### 设置消息长度区别

- Delphi 2006 设置消息长度：
  
  ```Pascal
  copyData.cbData := Length(msgStr) + 1;
  ```
- Delphi 11 设置消息长度：
  
  ```Pascal
  copyData.cbData := Length(TEncoding.ANSI.GetBytes(msgStr)) + 2;
  ```

**在 Delphi 11 中直接使用 `Length(msgStr)` 获取消息长度接收时消息内容会不完整！**

### 设置消息内容区别

- Delphi 2006 设置消息内容：
  
  ```Pascal
  StrCopy(copyData.lpData, PChar(msgStr));
  ```
- Delphi 11 设置消息内容：
  
  需要在 `uses` 代码块中引用 `System.AnsiStrings`。
  
  ```Pascal
  System.AnsiStrings.StrCopy(sdata.lpData, PAnsiChar(AnsiString(msgStr)));
  ```

## 接收消息注意事项

### 获取 `TWMCopyData` 字符串内容区别

- Delphi 2006 获取消息内容：
  
  ```Pascal
  InStr := StrPas(msg.CopyDataStruct^.lpData);
  ```
- Delphi 11 获取消息内容：
  
  需要在 `uses` 代码块中引用 `System.AnsiStrings`。
  
  ```Pascal
  InStr := String(System.AnsiStrings.StrPas(msg.CopyDataStruct^.lpData));
  ```
  
  或者直接使用 `PChar`：
  
  ```Pascal
  InStr := PChar(msg.CopyDataStruct^.lpData);
  ```

**在 Delphi 11 中接收消息直接使用 Delphi 2006 的代码会报以下错误：**

```log
[dcc32 Error] XXX.pas(999): E2251 Ambiguous overloaded call to 'StrPas'
  System.SysUtils.pas(12567): Related method: function StrPas(const PAnsiChar): AnsiString;
  System.SysUtils.pas(12573): Related method: function StrPas(const PWideChar): string;
```

或者：

```log
[dcc32 Error] XXX.pas(999): E2251 Ambiguous overloaded call to 'StrPas'
  System.AnsiStrings.pas(4122): Related method: function StrPas(const PAnsiChar): AnsiString;
  System.SysUtils.pas(12567): Related method: function StrPas(const PAnsiChar): AnsiString;
  System.SysUtils.pas(12573): Related method: function StrPas(const PWideChar): string;
```

