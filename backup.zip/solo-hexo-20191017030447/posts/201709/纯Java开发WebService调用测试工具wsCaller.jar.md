title: 纯 Java 开发 WebService 调用测试工具（wsCaller.jar）
date: '2017-09-03 16:13:45'
updated: '2018-01-29 14:19:41'
tags: [WebService, Java]
permalink: /articles/2017/09/03/1504426270766.html
---
基于 Java 开发的 WebService 测试工具，不像上文的 iWallpaper.jar 只能实现在 Windows 系统下的功能，此工具发挥了 Java 跨平台的优势，亲测可在 Windows、Mac OS 及 Linux 下运行及使用。简单易用的专门用于测试 WebService 的小工具，在 2003 版 wsCaller.jar 的基础上修改了一下 UI 风格、汉化及一些小 bug 的修复，版权归原作者所有。
## 主界面：
> ![main.jpg](//res.zixizixi.cn/file/2017/9/32dd4d24d20646ce9759444323f67310-201709033.50.39.jpg.zximg) 

## 关于：
> ![about.jpg](//res.zixizixi.cn/file/2017/9/b67f806aba364e98ac97a3e1001f82eb-201709033.53.45.jpg.zximg) 

## 调用：
> ![caller01.jpg](//res.zixizixi.cn/file/2017/9/4e6032e8947d4c55baa035b10bd34076-201709033.57.39.jpg.zximg) 
> 
> ![caller02.jpg](//res.zixizixi.cn/file/2017/9/e8d6d942971c4ed1b188482f22452d7c-201709034.01.31.jpg.zximg) 

## 2018-01-26 更新：添加快捷方式参数
> 通过在快捷方式后添加 `-wsdl` 或 `-w` 后跟 WSDL 地址，打开程序后直接填写到输入框中：
> ![ws-link](//res.zixizixi.cn/c073ba867b36486cbfcc6e89316a62df.png.zximg)
> ![ws](//res.zixizixi.cn/4d12746dd99a4589bf12355e08bf6f9b.png.zximg)

## 下载及源码：

> [WebServiceCaller.jar](https://github.com/iTanken/Projects/raw/master/iWebServiceCaller.jar) / [GitHub](https://github.com/iTanken/Projects/tree/master/WebServiceCaller)
