title: Solo 在线人数显示一直为 2 问题处理
date: '2017-03-30 12:53:22'
updated: '2018-12-27 11:13:02'
tags: [IP, Nginx, Solo]
permalink: /articles/2017/03/30/1490849602140.html
---

  闲来无事，记录一下昨天消灭的一个自己造成的BuG。
 
  众所周知，Solo 有显示浏览量和当前在线人数的统计功能，但一般也不会去注意这些小细节，不知道从什么时候开始在线人数就一直显示为 2，这被有完美主义强迫症的我看到了还了得，必须把这个问题处理一下。
 
  仔细一想，恍然大悟，不久前才刚刚处理了这个问题！！

### 同病相怜
  在我的另一个小网站上，有一个上传APK获取应用信息的工具，是根据访问的 IP 对上传次数做了限制的，有一段时间限制一直不起作用，查看日志后发现，请求的 IP 一直都是 `127.0.0.1` 和 `0:0:0:0:0:0:0:1` 这两个地址，这不都是本机的地址吗？！所以这就一定是 Solo 在线人数一直显示为 2 的原因。
> ![iApk-2017033012.21.33.jpg](//res.zixizixi.cn/file/2017/3/089fe3f2dded4b5998944087281909ab-2017033012.21.33.jpg.zximg) 

### 都是 Nginx 惹的祸
  因为我的 Solo 服务一直在用独立模式，还有一个 itanken.cn 的服务也在同一台服务器上，所以后来就用了 Nginx 做了反向代理，发现上传功能的 IP 限制失效并查看日志之后，感觉这一定就是 Nginx 惹的祸，所以机智的我立马就用度娘搜索了 [用Nginx反向代理后获取不到真实IP](https://www.baidu.com/s?wd=%E7%94%A8Nginx%E5%8F%8D%E5%90%91%E4%BB%A3%E7%90%86%E5%90%8E%E8%8E%B7%E5%8F%96%E4%B8%8D%E5%88%B0%E7%9C%9F%E5%AE%9EIP)，果不其然，需要在 Nginx 配置文件对应服务的 `location / {}` 中加上获取客户端真实 IP 地址的几个请求头的对应参数，在 Nginx 转发到的服务当中才可以获取到客户端请求的真实 IP，不然本机的 Nginx 转发到本机的 WEB 服务中，服务中获取到的 IP 只能是 Nginx 的 IP，就是那两个本机地址。配置参数：
```properties
  location / {
    # ...
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header REMOTE-HOST $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    # ...
  }
```

  这样在 Solo 对应的配置当中也加上这几条之后，重启 Nginx 之后 Solo 的在线人数果然就多了起来... 
 
 