title: Golang 和 Python 的 OCR 服务安装及使用
date: '2022-07-22 17:10:19'
updated: '2022-07-28 06:53:53'
tags: [Go, Python, OCR]
permalink: /golang-python-ocr
---
![](https://b3logfile.com/bing/20180314.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

> OCR （Optical Character Recognition，光学字符识别）是指电子设备（例如扫描仪或数码相机）检查纸上打印的字符，通过检测暗、亮的模式确定其形状，然后用字符识别方法将形状翻译成计算机文字的过程；即，针对印刷体字符，采用光学的方式将纸质文档中的文字转换成为黑白点阵的图像文件，并通过识别软件将图像中的文字转换成文本格式，供文字处理软件进一步编辑加工的技术。如何除错或利用辅助信息提高识别正确率，是OCR最重要的课题，ICR（Intelligent Character Recognition）的名词也因此而产生。衡量一个OCR系统性能好坏的主要指标有：拒识率、误识率、识别速度、用户界面的友好性，产品的稳定性，易用性及可行性等。

如果是要在生产中使用，推荐使用 Python 版本或选择收费 OCR 服务，也可以尝试一下 [飞桨 OCR](https://github.com/PaddlePaddle/PaddleOCR) 开源服务，但部署相对比较繁琐，本人目前还没有部署成功过。Go 版本仅用于学习、探索，效果非常赶人...

## Go 语言的 OCR 识别服务安装

- Go 依赖仓库地址：[https://github.com/otiai10/gosseract](https://github.com/otiai10/gosseract)
- Go 服务仓库地址：[https://github.com/otiai10/ocrserver](https://github.com/otiai10/ocrserver)

### Go OCR 服务安装前提条件

1. 推荐使用 Ubuntu 操作系统
2. 执行 `sudo apt update`
3. 安装 Go SDK

### 安装 GCC

```shell
sudo apt install build-essential
sudo apt-get install manpages-dev
gcc --version
```

### 安装 OCR

#### 安装依赖

```shell
sudo apt install tesseract-ocr
sudo apt install libleptonica-dev
sudo apt install libtesseract-dev
# 安装简体中文语言包
sudo apt install tesseract-ocr-chi-sim
```



```shell
# 查看包含的语言包
tesseract --list-langs
```

#### 安装 OCR 包

```shell
go get github.com/otiai10/gosseract
```

#### 安装 OCR 服务

```shell
go install github.com/otiai10/ocrserver@latest
```

#### 启动 OCR 服务

```shell
PORT=8080 ocrserver
```

```shell
# 如果是在 WSL2 中安装启动服务，需要执行此命令才能允许通过局域网 IP 进行访问
netsh interface portproxy add v4tov6 listenport=8080 listenaddress=0.0.0.0 connectport=8080 connectaddress=::1
# 查看端口代理列表
netsh interface portproxy show all
```

启动服务后访问上面指定的 8080 端口即可看到 OCR 服务页面，如下所示：
![image.png](https://b3logfile.com/file/2022/07/image-325b5aab.png)

## Python 版本 OCR 服务安装

- Python 项目仓库地址：[https://github.com/DayBreak-u/chineseocr_lite](https://github.com/DayBreak-u/chineseocr_lite)

### Python OCR 服务安装前提条件

1. 安装 Git
2. 项目要求使用 Python 3.6，亲测 Python 3.9 可用，Python 3.10 尚不能安装 `onnxruntime`，注意避坑

### pip 加速

```shell
pip install pytest -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
# pip -v config list
```

### 安装依赖

```shell
python -m pip install --upgrade pip
```

```shell
python -m pip install tornado
python -m pip install Pillow
python -m pip install numpy
python -m pip install opencv-python
python -m pip install onnxruntime
python -m pip install pyclipper
python -m pip install shapely
```

### 下载项目

```
git clone https://github.com/DayBreak-u/chineseocr_lite.git
```

### 启动服务

```shell
cd ./chineseocr_lite
python backend/main.py
```

