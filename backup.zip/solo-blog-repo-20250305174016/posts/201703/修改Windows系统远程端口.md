title: 修改Windows系统远程端口
date: '2017-03-26 18:56:32'
updated: '2019-12-05 09:06:13'
tags: [端口, 远程, Windows]
permalink: /articles/2017/03/26/1490525740291.html
---

### 事件起因

本站服务器是用的阿里云的 ECS，还是 Windows 系统的（Linuxer 勿喷），就在刚刚，阿里云安骑士给我发了一条登录警报：

> ![ecs-warn.jpg](https://b3logfile.com/file/2019/12/ecs-edfd6dcb.jpg)

！！！什么情况？！都用了这么久了，还是第一次遇到异地登录警报，竟然有人在南京要远程登录我的服务器，感觉世界瞬间就黑了 😂 

机智的我当然是要马上修改密码了，但是这还不够，它能登录我的服务器说明我现在用的远程端口已经泄露了，所以，还要修改远程连接所用的端口。

Windows 系统默认的远程端口是 `3389`，远程（mstsc）的时候一般直接输入服务器的 IP 就可以了，不用输入端口号，我觉得这样是很不安全的，如果修改成其他端口号，则在进行远程连接的时候必须同时输入 IP 地址和端口号，所以下面就记录一下修改远程端口的方法：

### 操作方法

1) 打开注册表编辑器（regedit）；

2) 定位注册表位置到： 

   ```
   HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\Wds\rdpwd\Tds\tcp
   ```

   找到右侧的 `PortNumber`，双击修改你要使用的端口号（十进制）；

3) 定位注册表位置到：

   ```
   HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp
   ```

   找到右侧的 `PortNumber`，双击修改你要使用的端口号（十进制，同第2步，两次修改成相同的端口号）；

4) 重启服务器并使用新端口号进行远程，如：`192.168.1.2:9833`：

   ![image.png](https://b3logfile.com/file/2019/08/image-dd8712c2.png)


### 删除远程记录

1) 打开注册表编辑器（regedit）：

   ![运行注册表](//res.zixizixi.cn/file/2018/3/35a28595a28946b3aaf5a9ab45ffa611-1.png.zximg "运行注册表") 

2) 定位注册表位置到：

   ```
   HKEY_CURRENT_USER\Software\Microsoft\Terminal Server Client\Default
   ```

   ![定位注册表](//res.zixizixi.cn/file/2018/3/bdbce3df3acf4eaf926187e16cb7f0bf-2.png.zximg "定位注册表") 

3) 在右侧根据数据值（IP）删除远程记录，最多保存 10 条记录。

   或者，可以直接在开始菜单中右键 “远程桌面连接” 图标，再右键要删除的记录，点击 “🗑 从此列表中删除” 即可：

   ![image.png](https://b3logfile.com/file/2019/08/image-cda55498.png)






