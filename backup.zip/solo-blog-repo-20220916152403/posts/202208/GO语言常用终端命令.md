title: GO 语言常用终端命令
date: '2022-08-05 17:32:26'
updated: '2022-09-13 14:16:21'
tags: [Go, Golang, bat, 命令行]
permalink: /go-command
---
## 环境

- 操作系统：windows
- GO 版本：1.19

## 本文占位符说明

- `ProjectRoot`：GO 项目源码根路径；
- `ProjectName`：GO 项目名称；
- `%GOROOT%`：GO SDK 安装目录环境变量，unix 中为 `$GOROOT`；

## 安装 GO 程序最新版到 `%GOPATH%/bin`

```shell
go install github.com/google/gops@latest
```

## 直接编译运行某 GO 程序的指定版本命令

```shell
go run github.com/swaggo/swag/cmd/swag@v1.8.1 fmt
```

## 查看当前目录下所有的包

```shell
# cd ProjectRoot

go list ./...
```

<details>
<summary>展开/收起输出内容</summary>

```text
ProjectName
ProjectName/assets
ProjectName/config
ProjectName/database
ProjectName/initialization
ProjectName/middleware
```

</details>

## 查看 GO 程序文件的编译信息

```shell
# go install github.com/google/gops@latest
# cd %GOROOT%/bin

go version -m gops.exe
```

<details>
<summary>展开/收起输出内容</summary>

```text
gops.exe: go1.19
        path    github.com/google/gops
        mod     github.com/google/gops  v0.3.25 h1:Pf6uw+cO6pDhc7HJ71NiG0x8dyQTeQcmg3HQFF39qVw=
        dep     github.com/go-ole/go-ole        v1.2.6  h1:/Fpf6oFPoeFik9ty7siob0G6Ke8QvQEuVcuChpwXzpY=
        dep     github.com/keybase/go-ps        v0.0.0-20190827175125-91aafc93ba19      h1:WjT3fLi9n8YWh/Ih8Q1LHAPsTqGddPcHqscN+PJ3i68=
        dep     github.com/shirou/gopsutil/v3   v3.22.4 h1:srAQaiX6jX/cYL6q29aE0m8lOskT9CurZ9N61YR3yoI=
        dep     github.com/xlab/treeprint       v1.1.0  h1:G/1DjNkPpfZCFt9CSh6b5/nY4VimlbHF3Rh4obvtzDk=
        dep     github.com/yusufpapurcu/wmi     v1.2.2  h1:KBNDSne4vP5mbSWnJbO+51IMOXJB67QiYCSBrubbPRg=
        dep     golang.org/x/sys        v0.0.0-20220520151302-bc2c85ada10a      h1:dGzPydgVsqGcTRVwiLJ1jVbufYwmzD3LfVPLKsKg+0k=
        build   -compiler=gc
        build   CGO_ENABLED=0
        build   GOARCH=amd64
        build   GOOS=windows
        build   GOAMD64=v1
```

</details>

## 静态检查

```shell
# cd ProjectRoot

go run honnef.co/go/tools/cmd/staticcheck@latest -f stylish ./...
```

<details>
<summary>展开/收起输出内容</summary>

```text
✖ 0 problems (0 errors, 0 warnings, 0 ignored)
```

</details>

### 另一个静态检查命令

```shell
go run github.com/mgechev/revive@latest -exclude ./vendor/... -formatter stylish ./...
```

此命令默认行为对命名检查比较严格，比如 `Api` 必须写为 `API`、`Http` 必须写为 `HTTP`、`Id` 必须写为 `ID` 和 `Sql` 必须写为 `SQL` 等等，
可以在配置文件中配置 [`[rule.var-naming]`](https://revive.run/r#var-naming) 白名单以便排除相关命名检查，如：

```toml
# revive.toml

[rule.var-naming]
  arguments = [["API", "SQL"], ["VM"]]
```

配置项 [`[rule.var-naming]`](https://revive.run/r#var-naming) 的参数类型为 `[2][]string`，第一个子切片为白名单，第二个子切片为黑名单。使用示例：

```shell
go run github.com/mgechev/revive@latest -config ./revive.toml -exclude ./vendor/... -formatter stylish ./...
```

## 漏洞检查

```shell
# 在项目根目录执行：
go run golang.org/x/vuln/cmd/govulncheck@latest ./...
```

## GO 文档服务

```shell
# cd ProjectRoot

go run golang.org/x/tools/cmd/godoc@latest -http=:6060 -index

# start http://127.0.0.1:6060/pkg/
```

## GO 模块

### 初始化 GO 模块

```shell
# mkdir ProjectName & cd ProjectName

go mod init ProjectName
```

### 下载 GO 模块依赖

```shell
go mod download
```

### 整理 GO 模块依赖

```shell
go mod tidy
```

### 添加 GO 模块依赖

```shell
go get github.com/godoes/go-figure
```

### 更新指定 GO 模块依赖

```shell
go get -d -u github.com/godoes/go-figure
```

### 更新全部 GO 模块依赖

```shell
go get -d -u
```

### 导入模块依赖到 vendor 目录

```shell
go mod vendor
```

## 使用批处理命令判断 GO 版本

```bat
rem 获取 go 版本
set gv=99999999999999999999
for /f "tokens=*" %%i in ('go version') do (
    set gv=%%i
)
set ver=%gv:~13,5%
:del-right
if "%ver:~-1%" equ "." set ver=%ver:~0,-1%&&goto del-right
if "%ver:~-1%" equ " " set ver=%ver:~0,-1%&&goto del-right
:goon
rem go 版本不能小于 1.18
if %ver% leq 1.17 (
  color 04
  echo. & echo 请使用 go1.18 或以上版本！ & echo.
  pause & exit
)

rem TODO more things...
go version
pause
```

