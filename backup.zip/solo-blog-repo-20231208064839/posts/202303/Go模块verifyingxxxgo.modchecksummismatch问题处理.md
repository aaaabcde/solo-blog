title: 'Go 模块 verifying xxx/go.mod: checksum mismatch 问题处理'
date: '2023-03-03 09:35:59'
updated: '2023-03-03 09:55:29'
tags: [Go, Golang, Modules]
permalink: /go-modules-verifying-checksum-mismatch
---
### 报错信息

```shell
verifying go.example.com/mod/name/v2@v2.0.0/go.mod: checksum mismatch
	downloaded: h1:NF7NWGQ3cnnqVcy0cwgKl9WmIeMDfMAU6Oqw6Ut9axQ=
	go.sum:     h1:aoQVIi7gI0jeqE49fFmOk7KzJDoQt8vpdFqZ6JUiRiA=
```

### 解决方法

1. 删除 `go.sum` 文件；
2. 清除 Go 模块缓存：
   
   ```shell
   go clean -modcache
   ```
3. 重新整理并下载模块依赖：
   
   ```shell
   go mod tidy
   ```

### 命令说明

#### go clean -modcache

`go clean -modcache` 是用来清理 Go 模块缓存的命令。在使用 Go 模块管理时，会在 `$GOPATH/pkg/mod` 目录下缓存所有的依赖包，这些包的版本信息等都会保存在缓存中，以便后续的构建操作使用。

`go clean -modcache` 命令会清理 `$GOPATH/pkg/mod/cache` 目录下的所有缓存内容，包括已经下载的源代码、压缩包、Git 子模块、二进制文件等。这样做的目的是为了释放磁盘空间，同时也可以强制重新下载所有依赖包，以确保使用的是最新的代码和版本信息。

需要注意的是，清理缓存可能会导致依赖包被重新下载，因此建议在确保不会影响项目构建和运行的情况下进行。同时，清理缓存也会导致重新下载依赖包，因此在网络环境较差或依赖包较多的情况下，可能会耗费较长时间。

#### go mod tidy

`go mod tidy` 是 Go modules 的一个命令，它的作用是整理项目的依赖，将依赖关系更新为最新版本，并删除不需要的依赖关系。具体来说，它有以下几个作用：

1. **识别和拉取缺失的模块或版本：**
   当我们在项目中添加或删除了一个依赖包，或者更改了版本号，可能会导致 Go modules 找不到对应的模块或版本，这时候使用 `go mod tidy` 可以自动下载缺失的模块或版本。
2. **识别和删除未使用的模块或版本：**
   当我们修改了项目的依赖关系后，有可能会出现一些不再使用的依赖关系，这时候使用 `go mod tidy` 可以自动删除这些未使用的依赖关系。
3. **更新依赖版本：**
   当我们想要使用最新版本的依赖包时，可以使用 go mod tidy 来更新依赖版本。
4. **生成 `go.mod` 和 `go.sum` 文件：**
   `go mod tidy` 会根据项目依赖生成 `go.mod` 文件，并更新 `go.sum` 文件中的哈希值。

总之，`go mod tidy` 可以帮助我们更好地管理 Go 项目的依赖关系，保证项目的正确性和稳定性。

