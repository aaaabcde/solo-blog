title: 使用 javap 命令查看 class 文件 JDK 编译版本，避免 Unsupported major.minor version 异常
date: '2017-09-13 14:57:09'
updated: '2018-12-27 11:16:51'
tags: [Java]
permalink: /articles/2017/09/13/1505285468516.html
---
## Unsupported major.minor version

之前遇到了同一 class 文件在不同 JRE 环境的 WEB 服务下运行报 ` Unsupported major.minor version ` 异常的问题，出现此问题的原因是编译环境 JDK 版本高于运行环境，所以使编译环境和运行环境的版本一致，可以避免很多不必要的错误。记录一下。
 
## 可以使用 javap 命令查看编译版本：
> javap -verbose ClassName.class
> ![javap-verbose.png](//res.zixizixi.cn/file/2017/9/684ca78e58aa49a1b00e39ea69416707.png.zximg?imageView2/0/interlace/1/q/90) 
> 
> 可以看出 ` major version: 52 ` 对应 `java 1.8.0`
> ![java-version.png](//res.zixizixi.cn/file/2017/9/9cf263cab0df481c8db46a49460fd735.png.zximg?imageView2/0/interlace/1/q/90) 
> ![十六进制.png](//res.zixizixi.cn/file/2017/9/9c7ad1f9957143c884117b502c0e2bb2.png.zximg?imageView2/0/interlace/1/q/90) 


## major.minor version 版本对照表

| 编译版本 | target 参数 | 十六进制 major.minor | 十进制 major.minor |
| :-----:| :------------- |:-------------:| :---------:|
| jdk1.1.8 | 不能带 target 参数 | 00 03   00 2D | 45.3 |
| jdk1.2.2 | 不带(默认为 -target 1.1) | 00 03   00 2D | 45.3 |
| jdk1.2.2 | -target 1.2 | 00 00   00 2E | 46.0 |
| jdk1.3.1_19 | 不带(默认为 -target 1.1) | 00 03   00 2D | 45.3 |
| jdk1.3.1_19 | -target 1.3 | 00 00   00 2F | 47.0 |
| j2sdk1.4.2_10 | 不带(默认为 -target 1.2) | 00 00   00 2E | 46.0 |
| j2sdk1.4.2_10 | -target 1.4 | 00 00   00 30 | 48.0 |
| jdk1.5.0_11 | 不带(默认为 -target 1.5) | 00 00   00 31 | 49.0 |
| jdk1.5.0_11 | -target 1.4 -source 1.4 | 00 00   00 30 | 48.0 |
| jdk1.6.0_01 | 不带(默认为 -target 1.6) | 00 00   00 32 | 50.0 |
| jdk1.6.0_01 | -target 1.5 | 00 00   00 31 | 49.0 |
| jdk1.6.0_01 | -target 1.4 -source 1.4 | 00 00   00 30 | 48.0 |
| jdk1.7.0 | 不带(默认为 -target 1.6) | 00 00   00 32 | 50.0 |
| jdk1.7.0 | -target 1.7 | 00 00   00 33 | 51.0 |
| jdk1.7.0 | -target 1.4 -source 1.4 | 00 00   00 30 | 48.0 |
| jdk1.8.0 | -target 1.8 | 00 00   00 34 | 52.0 |
| Apache Harmony 5.0M3 | 不带(默认为 -target 1.2) | 00 00   00 2E | 46.0 |
| Apache Harmony 5.0M3 | -target 1.4 | 00 00   00 30 | 48.0 |

> END.