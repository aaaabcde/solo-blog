title: Android Studio 提示 Unable to access Android SDK add-on list 问题处理
date: '2017-01-17 22:56:58'
updated: '2018-01-29 14:23:08'
tags: [安装, Android]
permalink: /articles/2017/01/17/1484665018593.html
---

第一次安装 Android Studio，由于电脑没有 android-sdk，安装的又是没有自带 SDK 的 Android Studio，所以可能会提示 `Unable to access Android SDK add-on list`。

### 解决方法
解决方法是在安装目录中找到 `bin` 目录下的 `idea.properties` 文件，打开文件后在末尾添加一行内容：
> ```properties
disable.android.first.run=true
```

如果是 MacOS，需要在 Finder 中的 `应用程序` 中找到 `Android Studio.app`，然后右键选择 `显示包内容`，进入 `Contents` 文件夹，即可看到 `bin` 目录。
> ### 第一步：进入程序根目录
> ![AS1.jpg](https://res.zixizixi.cn/801f6865b8364903a5ad92f2707adc90.jpg.zximg)
>
> ### 第二步：找到配置文件
> ![AS2.jpg](https://res.zixizixi.cn/26aaf90ed5764bce9b074d130dd5eeae.jpg.zximg)
>
> ### 第三步：修改配置文件
> ![AS3.jpg](https://res.zixizixi.cn/3b805a21c3b74a629c23730efff1f1ac.jpg.zximg)

### Android Studio 常用快捷键

| 功能 | MacOS | Windows | 备注 |
| --- | --- | --- | --- |
| 1. 转换大小写 | Command + Shift + U | Ctrl + Shift + U |  |
| 2. 整理包引用 | Option + Control + O | Ctrl + Alt + O | Ctrl + Shift + O |
| 3. 代码格式化 | Option + Cmmand + L | Ctrl + Alt + L | Ctrl + Shift + F |
| 4. 包裹选中区 | Option + Cmmand + T | Ctrl + Alt + T | Alt + Shift + Z |
| 5. 删除当前行 | Command + X / delete | Ctrl + Y | Ctrl + D |
 
 
### 用华为手机调试 logcat 不显示日志

在 Android Studio 中使用华为手机调试应用，在 logcat 可能会出现不显示日志的情况，在这里将自己的解决方法记录一下：

1. 在拨号中输入 `*#*#2846579#*#*` 进入工程菜单：
> ![HW-拨号键盘](https://res.zixizixi.cn/646ab685a9a94821adf9bea8777f8859.png.zximg)
 
2. 选择工程菜单中 `1.后台设置` 下面的 `3.LOG设置`：
> ![HW-后台设置](https://res.zixizixi.cn/8f65c3c5c7d444bcb7b1a4c35d01f7cf.png.zximg) ![HW-LOG设置](https://res.zixizixi.cn/d7951bb96cb44fd5b3975bd39f5311ad.png.zximg)

3. 选中 `AP 日志`，选中后会提示`此操作会影响手机性能`，点击关闭后再进入可发现会自动选中`充电日志`和`休眠日志`，可在调试完毕后取消此设置。
> ![HW-AP日志](https://res.zixizixi.cn/18fe0267753645fdb24abec9310a7fec.png.zximg)

设置完毕后一般无需其他操作，进入 Android Studio 运行应用可直接看到在 logcat 中输出了日志：
> ![AS-LOGCAT](https://res.zixizixi.cn/e5b383be7fe547a88a30b8d15f78d1e6.jpg.zximg)

### Android 编程权威指南（第二版）

Android 编程权威指南（第二版）是基于 Android Studio 进行讲解 Android 开发的书籍，本书主要以美国一家专业的移动开发技术培训机构的 Android 训练营教学课程为基础，融合了几位作者多年的心得体会，是一本完全面向实战的 Android 编程权威指南。全书共 34 章，详细介绍了 8 个 Android 应用。通过这些精心设计的应用，读者可掌握很多重要的理论知识和开发技巧，获得最前沿的开发经验。如果你熟悉 Java 语言，或者了解面向对象编程，那就立刻开始 Android 编程之旅吧!

> 中文原版 PDF 下载地址：[Android编程权威指南（第2版）.pdf](//res.zixizixi.cn/doc/android/Android编程权威指南（第2版）.pdf)
> 本书版权归原作者所有，仅供交流分享使用，禁止用于商业用途，如您觉得本书对你有所帮助，请通过正规渠道购买正版书籍支持作者。
> 
