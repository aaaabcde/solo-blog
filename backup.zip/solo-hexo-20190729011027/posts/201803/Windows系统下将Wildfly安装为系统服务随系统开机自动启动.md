title: Windows 系统下将 Wildfly 安装为系统服务，随系统开机自动启动
date: '2018-03-21 17:38:39'
updated: '2019-04-07 00:35:10'
tags: [Windows, 服务, Wildfly]
permalink: /windows-wildfly-service-auto-start
---
![windows-wildfly-service-auto-start](//res.zixizixi.cn/image/wildfly.jpg.coverimg "Wildfly开机自动启动")

平时工作中开发的 JavaWeb 项目后台服务用的一般都是 Wildfly(JBoss)，系统使用 Windows Server。由于某些原因需要让 Wildfly 在系统开机或重启后自动启动，这样就需要将 Wildfly 安装为系统服务，通过设置为自动启动的服务来实现 Wildfly 随系统开机启动（将启动文件的快捷方式放在系统 `启动` 目录中的方式，必须进入桌面后才会启动，并非真正意义的自动启动）。使用服务模式相对来说会更稳定一些，配置步骤：

` 以下所有 cmd 命令的执行都是基于管理员权限的。`

## 1、编辑 service.bat 

 **1.1、 进入 `Wildfly 根目录\bin\service` 目录，编辑 service.bat，修改以下三项，若只有一个 Wildfly，可使用默认值：**
> 较新版本的 Wildfly（比如 12.0.0.Final）安装为系统服务的 service 文件位于 `%Wildfly_HOME%\docs\contrib\scripts\service` 目录中。

| 序号 | 项目 | 默认值 | 说明 |
| :---: | ------ | ------ | ------ |
| 1 | SHORTNAME | Wildfly | 服务名称 |
| 2 | DISPLAYNAME | Wildfly | 显示名称 |
| 3 | DESCRIPTION | Wildfly Application Server | 描述信息 |

> ![WildflyService0.png](//res.zixizixi.cn/image/illust/WildflyService0.png) 
> &nbsp;
> service.bat 的文件编码一般默认为 UTF-8，若修改的描述信息中包含中文，需用记事本将 service.bat 保存为 ANSI 编码格式的文件。
> ![WildflyService3.png](//res.zixizixi.cn/image/illust/WildflyService3.png.zximg) 

 **1.2、 修改 %JBOSS_HOME%**

确保环境变量中的 `JBOSS_HOME` 为 当前 Wildfly 的根目录，或者在环境变量中重新添加一个 `Wildfly_HOME`，将 `service.bat` 文件中的 `%JBOSS_HOME%` 全部替换为新加的 `%Wildfly_HOME%`。
`建议使用默认的 JBOSS_HOME，否则 standalone.bat/domain.bat 等文件中的 %JBOSS_HOME% 可能也需要修改`

> ![WildflyService1.png](//res.zixizixi.cn/image/illust/WildflyService1.png.zximg) 
> &nbsp;
> ![WildflyService2.png](//res.zixizixi.cn/image/illust/WildflyService2.png.zximg) 

## 2、安装系统服务

 **2.1、在 `%Wildfly_WX_HOME%\bin\service` 目录中按住 `Shift` 键并的同时点击鼠标右键，在右键菜单中选择 `在此处打开命令窗口(W)`，在打开的命令行窗口中输入并执行 `service install` ，输出 Success 则服务安装成功，如下图：**

> ![WildflyService4.png](//res.zixizixi.cn/image/illust/WildflyService4.png.zximg) 
> &nbsp;
> ![WildflyService5.png](//res.zixizixi.cn/image/illust/WildflyService5.png.zximg) 

此时运行 `services.msc` 在服务中可找到名称为 `Wildfly (wildfly-8.2.1.Final)` 的系统服务：

> ![WildflyService6.png](//res.zixizixi.cn/image/illust/WildflyService6.png.zximg) 
> &nbsp;
> ![WildflyService7.png](//res.zixizixi.cn/image/illust/WildflyService7.png.zximg) 

 **2.2、设置自动启动**

> ![WildflyService8.png](//res.zixizixi.cn/image/illust/WildflyService8.png.zximg) 

设置完成后可通过启动、关闭此系统服务来控制 Wildfly 的运行，并在电脑重启后可随系统自动启动 Wildfly。
> 服务模式下 Wildfly 会在后台静默运行，不会显示运行窗口，以前在命令窗口打印的信息需要到日志文件去查看，如：
> `service.2018-03-21.log`、`wildfly8-stderr.2018-03-21.log`、`wildfly8-stdout.2018-03-21.log`

## 3、其他

 **3.1、通过在 `%Wildfly_HOME%\bin\service` 目录执行 `service install` 命令卸载已安装的 Wildfly 服务。**

> ![WildflyService9.png](//res.zixizixi.cn/image/illust/WildflyService9.png.zximg) 

 **3.2、Wildfly 服务运行管理**
在 `%Wildfly_HOME%\bin\service` 目录下执行以下命令：
> 启动服务：service start 
> 停止服务：service stop 
> 重启服务：service restart 

`也可直接在命令行或运行窗口中执行系统的 net start 服务名、net stop 服务名来启动停止服务。`

## 4、附件
> Wildfly服务管理工具： [WildflyServiceManager.bat](https://www.itanken.cn/download?dir=docs/bat/&name=Wildfly服务管理工具.rar)
> ![WildflyService10.png](//res.zixizixi.cn/image/illust/WildflyService10.png.zximg) 

``` bat
@echo off 
color 07
title Wildfly Service Manager ★ Tanken·L
rem Powered by https://zixizixi.cn/

:home
color 0f
@echo.
@echo Wildfly Service Shortcut Management Tools
@echo 请通过右键选择“以管理员身份运行”
@echo 【 快捷管理 Wildfly 服务 】

rem 设置服务名称
if /I "x%1" == "x" (
  set sName=Wildfly
) else (
  set sName="%1"
)
set sHome=%JBoss_HOME%

rem 判断 Wildfly 服务是否存在
sc query %sName% > nul
if errorlevel 1060 (
  @echo 指定的 Wildfly 不存在！请检查服务名及是否已经安装对应的 Wildfly 服务。
  goto end
) else (
  goto begin
)
@echo.

:begin
for /f "skip=3 tokens=4" %%i in ('sc query %sName%') do set "zt=%%i" &goto next

:next
@echo.  服务 %sName% 当前状态 [ %zt% ]
@echo  ┏━━━━━━━━━━━━━━━━━━┓
@echo  ┃★ 本工具用于快捷管理 Wildfly 服务：┃
@echo  ┃★     0. 查看日志                  ┃
@echo  ┃★     1. 启动服务                  ┃
@echo  ┃★     2. 关闭服务                  ┃
@echo  ┃★     3. 重启服务（慎用）          ┃
@echo  ┃★     4. 重载管理脚本              ┃
@echo  ┃★     5. 关闭管理脚本              ┃
@echo  ┗━━━━━━━━━━━━━━━━━━┛
@echo                                        *

set input=
set /p "input=* 请输入功能序号并回车："
if %input%input==input goto home
if not '%input%'=='' set input=%input:~0,1%
if /I '%input%'=='0' goto logview
if /I '%input%'=='1' goto start
if /I '%input%'=='2' goto stop
if /I '%input%'=='3' goto restart
if /I '%input%'=='4' goto reload
if /I '%input%'=='5' EXIT
if /I '%input%'=='nul' cls goto home
if /I '%input%'!='0' pause

:logview
@echo.
explorer %sHome%\standalone\log
goto reload

:start
@echo.
net start %sName%
goto reload

:stop
@echo.
rem net stop %sName%
start %sHome%\bin\jboss-cli.bat --connect --command=:shutdown
goto reload

:restart
@echo.
start %sHome%\bin\service\service restart
goto reload

rem 重新运行脚本
:reload
color 09
@echo.
pause
cls
goto home

rem 结束运行脚本
:end
@echo.
@echo.按任意键结束...
pause > nul
exit

```

> 本文地址：[https://zixizixi.cn/windows-wildfly-service-auto-start](https://zixizixi.cn/windows-wildfly-service-auto-start)

