title: 【笔记】HTTP 状态码说明
date: '2017-01-04 20:00:23'
updated: '2017-01-04 20:00:23'
tags: [HTTP]
permalink: /articles/2017/01/04/1483529323782.html
---
HTTP 状态码（响应码）用来表明 HTTP 请求是否已经成功完成。HTTP 响应类型一共分五大类：消息响应，成功响应，重定向，客户端错误，服务器端错误。

下表列出了所有HTTP状态码，以及他们各自所代表的含义：

<table class="tbl" cellspacing="0" cellpadding="0">
	<thead>
	<tr>
		<th width="10%">状态码</th>
		<th width="20%">原因短语</th>
		<th width="50%">代表含义</th>
		<th width="20%">HTTP 版本</th>
	</tr>
	</thead>
	<tbody>
	<tr>
		<th colspan="4">消息响应</th>
	</tr>
	<tr>
		<td id="100">100</td>
		<td>Continue<br> (继续)</td>
		<td>
			客户端应当继续发送请求。这个临时响应是用来通知客户端它的部分请求已经被服务器接收，且仍未被拒绝。客户端应当继续发送请求的剩余部分，或者如果请求已经完成，忽略这个响应。服务器必须在请求完成后向客户端发送一个最终响应。
		</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td id="101">101</td>
		<td>Switching Protocol<br> (切换协议)</td>
		<td>服务器已经理解了客户端的请求，并将通过Upgrade消息头通知客户端采用不同的协议来完成这个请求。在发送完这个响应最后的空行后，服务器将会切换到在Upgrade消息头中定义的那些协议。只有在切换新的协议更有好处的时候才应该采取类似措施。例如，切换到新的HTTP版本比旧版本更有优势，或者切换到一个实时且同步的协议以传送利用此类特性的资源。
		</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<th colspan="4">成功响应</th>
	</tr>
	<tr>
		<td id="200">200</td>
		<td>OK<br> (成功)</td>
		<td>请求成功.成功的意义根据请求所使用的方法不同而不同.
			<ul>
				<li>GET: 资源已被提取,并作为响应体传回客户端.</li>
				<li>HEAD: <span><span>实体</span><span>头</span><span>已作为响应头传回客户端</span></span></li>
				<li>POST: 经过服务器处理客户端传来的数据,适合的资源作为响应体传回客户端.</li>
				<li>TRACE: <span><span>服务器</span><span>收到</span><span>请求消息</span></span>作为响应体传回客户端.</li>
			</ul>
			PUT, DELETE, 和 OPTIONS 方法永远不会返回 200 状态码.
		</td>
		<td>HTTP/0.9 可用</td>
	</tr>
	<tr>
		<td id="201">201</td>
		<td>Created<br> (已创建)</td>
		<td>请求成功，而且有一个新的资源已经依据请求的需要而建立，通常这是 PUT 方法得到的响应码.</td>
		<td>HTTP/0.9 可用</td>
	</tr>
	<tr>
		<td id="202">202</td>
		<td>Accepted<br> (已创建)</td>
		<td>
			服务器已接受请求，但尚未处理。正如它可能被拒绝一样，最终该请求可能会也可能不会被执行。在异步操作的场合下，没有比发送这个状态码更方便的做法了。:返回202状态码的响应的目的是允许服务器接受其他过程的请求（例如某个每天只执行一次的基于批处理的操作），而不必让客户端一直保持与服务器的连接直到批处理操作全部完成。在接受请求处理并返回202状态码的响应应当在返回的实体中包含一些指示处理当前状态的信息，以及指向处理状态监视器或状态预测的指针，以便用户能够估计操作是否已经完成。
		</td>
		<td>HTTP/0.9 可用</td>
	</tr>
	<tr>
		<td id="203">203</td>
		<td>Non-Authoritative Information<br> (未授权信息)</td>
		<td><p>服务器已成功处理了请求,但返回的实体头部元信息不是在原始服务器上有效的确定集合，而是来自本地或者第三方的拷贝,如果不是上述情况,使用200状态码才是最合适的.</p></td>
		<td>HTTP/0.9 and 1.1</td>
	</tr>
	<tr>
		<td id="204">204</td>
		<td>No Content<br> (无内容)</td>
		<td>该响应没有响应内容,只有响应头,响应头也可能是有用的.用户代理可以根据新的响应头来更新对应资源的缓存信息.</td>
		<td>HTTP/0.9 可用</td>
	</tr>
	<tr>
		<td id="205">205</td>
		<td>Reset Content<br> (重置内容)</td>
		<td>告诉用户代理去重置发送该请求的窗口的文档视图.</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td id="206">206</td>
		<td>Partial Content<br> (部分内容)</td>
		<td>当客户端通过使用range头字段进行文件分段下载时使用该状态码</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<th colspan="4">重定向</th>
	</tr>
	<tr>
		<td id="300">300</td>
		<td>Multiple Choice<br> (多种选择)</td>
		<td>该请求有多种可能的响应,用户代理或者用户必须选择它们其中的一个.服务器没有任何标准可以遵循去代替用户来进行选择.</td>
		<td>HTTP/1.0 and later</td>
	</tr>
	<tr>
		<td id="301">301</td>
		<td>Moved Permanently<br> (永久移动)</td>
		<td>该状态码表示所请求的URI资源路径已经改变,新的URL会在响应的<code>Location</code>:头字段里找到.</td>
		<td>HTTP/0.9 可用</td>
	</tr>
	<tr>
		<td id="302">302</td>
		<td>Found<br> (临时移动)</td>
		<td>该状态码表示所请求的URI资源路径临时改变,并且还可能继续改变.因此客户端在以后访问时还得继续使用该URI.新的URL会在响应的<code>Location:</code>头字段里找到.</td>
		<td>HTTP/0.9 可用</td>
	</tr>
	<tr>
		<td id="303">303</td>
		<td>See Other<br> (查看其他位置)</td>
		<td>服务器发送该响应用来引导客户端使用GET方法访问另外一个URI.</td>
		<td>HTTP/0.9 and 1.1</td>
	</tr>
	<tr>
		<td id="304">304</td>
		<td>Not Modified<br> (未修改)</td>
		<td>告诉客户端,所请求的内容距离上次访问并没有变化. 客户端可以直接从浏览器缓存里获取该资源.</td>
		<td>HTTP/0.9 可用</td>
	</tr>
	<tr>
		<td id="305">305</td>
		<td>Use Proxy<br> (使用代理)</td>
		<td>所请求的资源必须统过代理才能访问到.由于安全原因,该状态码并未受到广泛支持.</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td id="306">306</td>
		<td><em>unused</em><br> (未使用)</td>
		<td>
			<span><span>这个</span><span>状态码</span><span>已经不再被使用</span><span>,</span><span>当初它被用</span><span>在</span><span>HTTP 1.1规范</span><span>的</span><span>旧版本</span><span>中.</span></span>
		</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td id="307">307</td>
		<td>Temporary Redirect<br> (临时重定向)</td>
		<td><p>服务器发送该响应用来引导客户端使用相同的方法访问另外一个URI来获取想要获取的资源.新的URL会在响应的<code>Location:</code>头字段里找到.与302状态码有相同的语义,且前后两次访问必须使用相同的方法(GET
				POST).</p></td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td>308</td>
		<td>Permanent Redirect<br> (永久重定向)</td>
		<td><p>所请求的资源将永久的位于另外一个URI上.新的URL会在响应的<code>Location:</code>头字段里找到.与301状态码有相同的语义,且前后两次访问必须使用相同的方法(GET
				POST).</p></td>
		<td><p>HTTPbis <br> (试验草案)</p></td>
	</tr>
	<tr>
		<th colspan="4">客户端错误</th>
	</tr>
	<tr>
		<td id="400">400</td>
		<td>Bad Request<br> (错误请求)</td>
		<td>因发送的请求语法错误,服务器无法正常读取.</td>
		<td>HTTP/0.9 可用</td>
	</tr>
	<tr>
		<td id="401">401</td>
		<td>Unauthorized<br> (未授权)</td>
		<td>需要身份验证后才能获取所请求的内容,类似于403错误.不同点是.401错误后,只要正确输入帐号密码,验证即可通过.</td>
		<td>HTTP/0.9 可用</td>
	</tr>
	<tr>
		<td id="402">402</td>
		<td>Payment Required<br> (需要付款)</td>
		<td><span><span>该状态</span><span>码</span><span>被保留以</span><span>供将来使用.</span><span>创建此代码</span><span>最初的目的是</span><span>为</span><span>数字</span><span>支付系统而用</span><span>,</span><span>然而,到现在也没投入使用</span><span>.</span></span>
		</td>
		<td>HTTP/0.9 and 1.1</td>
	</tr>
	<tr>
		<td id="403">403</td>
		<td>Forbidden<br> (禁止访问)</td>
		<td>客户端没有权利访问所请求内容,服务器拒绝本次请求.</td>
		<td>HTTP/0.9 可用</td>
	</tr>
	<tr>
		<td id="404">404</td>
		<td>Not Found<br> (未找到)</td>
		<td>服务器找不到所请求的资源.由于经常发生此种情况,所以该状态码在上网时是非常常见的.</td>
		<td>HTTP/0.9 可用</td>
	</tr>
	<tr>
		<td id="405">405</td>
		<td>Method Not Allowed<br> (不允许使用该方法)</td>
		<td>该请求使用的方法被服务器端禁止使用,RFC2616中规定, <code>GET</code> 和 <code>HEAD</code> 方法不能被禁止.</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td id="406">406</td>
		<td>Not Acceptable<br> (无法接受)</td>
		<td>在进行<span>服务器驱动内容协商</span>后,没有发现合适的内容传回给客户端.</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td id="407">407</td>
		<td>Proxy Authentication Required<br> (要求代理身份验证)</td>
		<td><p>类似于状态码 401,不过需要通过代理才能进行验证.</p></td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td id="408">408</td>
		<td>Request Timeout<br> (请求超时)</td>
		<td>客户端没有在服务器预备等待的时间内完成一个请求的发送.这意味着服务器将会切断和客户端的连接. 在其他浏览器中,这种响应更常见一些, 例如Chrome 和 IE9, 目的是为了使用HTTP
			预连机制<span><span>加快浏览速度</span></span>. 同时注意,一些服务器不发送此种响应就直接切断连接.
		</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td id="409">409</td>
		<td>Conflict<br> (冲突)</td>
		<td>该请求与服务器的当前状态所冲突.</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td id="410">410</td>
		<td>Gone<br> (已失效)</td>
		<td>所请求的资源已经被删除.</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td id="411">411</td>
		<td>Length Required<br> (需要内容长度头)</td>
		<td>因服务器在本次请求中需要 <code>Content-Length</code> 头字段,而客户端没有发送.所以,服务器拒绝了该请求.</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td id="412">412</td>
		<td>Precondition Failed<br> (预处理失败)</td>
		<td>服务器没能满足客户端在获取资源时在请求头字段中设置的先决条件.</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td id="413">413</td>
		<td>Request Entity Too Large<br> (请求实体过长)</td>
		<td>请求实体大小超过服务器的设置的最大限制,服务器可能会关闭HTTP链接并返回<code>Retry-After</code> 头字段.</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td id="414">414</td>
		<td>Request-URI Too Long<br> (请求网址过长)</td>
		<td>客户端请求所包含的URI地址太长,以至于服务器无法处理.</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td id="415">415</td>
		<td>Unsupported Media Type<br> (媒体类型不支持)</td>
		<td>服务器不支持客户端所请求的媒体类型,因此拒绝该请求.</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td id="416">416</td>
		<td>Requested Range Not Satisfiable<br> (请求范围不合要求)</td>
		<td>请求中包含的<code>Range</code>头字段无法被满足,通常是因为<code>Range</code>中的数字范围超出所请求资源的大小.</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td id="417">417</td>
		<td>Expectation Failed<br> (预期结果失败)</td>
		<td>在请求头<code> Expect</code> 中指定的预期内容无法被服务器满足.</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<th colspan="4">服务器端错误</th>
	</tr>
	<tr>
		<td id="500">500</td>
		<td>Internal Server Error<br> (内部服务器错误)</td>
		<td>服务器遇到未知的无法解决的问题.</td>
		<td>HTTP/0.9 可用</td>
	</tr>
	<tr>
		<td id="501">501</td>
		<td>Implemented<br> (未实现)</td>
		<td>服务器不支持该请求中使用的方法,比如<code>POST</code> 和 <code>PUT.只有</code><code>GET</code> 和 <code>HEAD</code>
			是RFC2616规范中规定服务器必须实现的方法.
		</td>
		<td>HTTP/0.9 可用</td>
	</tr>
	<tr>
		<td id="502">502</td>
		<td>Bad Gateway<br> (网关错误)</td>
		<td>服务器作为网关且从上游<span>服务器获取到了一个无效的HTTP响应</span>.</td>
		<td>HTTP/0.9 可用</td>
	</tr>
	<tr>
		<td id="503">503</td>
		<td>Service Unavailable<br> (服务不可用)</td>
		<td>由于临时的服务器维护或者过载,服务器当前无法处理请求.这个状况是临时的,并且将在一段时间以后恢复.如果能够预计延迟时间,那么响应中可以包含一个<code>Retry-After:</code>头用以标明这个延迟时间.如果没有给出这个<code>Retry-After:</code>信息，那么客户端应当以处理500响应的方式处理它.同时,这种情况下,一个友好的用于解释服务器出现问题的页面应当被返回,并且,缓存相关的HTTP头信息也应该包含,因为通常这种错误提示网页不应当被客户端缓存.
		</td>
		<td>HTTP/0.9 可用</td>
	</tr>
	<tr>
		<td id="504">504</td>
		<td>Gateway Timeout <br> (网关超时)</td>
		<td>服务器作为网关且不能从上游<span>服务器</span>及时的得到响应返回给客户端.</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	<tr>
		<td id="505">505</td>
		<td>HTTP Version Not Supported<br> (HTTP版本不受支持)</td>
		<td>服务器不支持客户端发送的HTTP请求中所使用的HTTP协议版本.</td>
		<td>HTTP/1.1 可用</td>
	</tr>
	</tbody>
</table>

