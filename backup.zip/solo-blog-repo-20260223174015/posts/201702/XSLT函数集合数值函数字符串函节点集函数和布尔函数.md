title: XSLT函数集合：数值函数、字符串函、节点集函数和布尔函数
date: '2017-02-13 15:56:17'
updated: '2017-02-13 15:56:17'
tags: [XSLT, XPath, XML]
permalink: /xsltfunctionset
---
任何的编程语言或者是SQL语句都有内置的函数或方法，而强大灵活的xslt技术也是如此。熟练掌握XSLT的常用函数的用法，XSLT的应用将变得如此轻松，你会发现XSLT比想象中还要牛！以下是xslt数值的函数与xslt字符串函数的说明与参考示例。

## __1、__ XSLT数值的函数：
__（1）__ fn:number(arg) 返回参数的数值。参数可以是布尔值、字符串或节点集。
_示例：_`<xsl:value-of select="number('100')"/>` 返回 100

__（2）__ fn:abs(num) 返回参数的绝对值。
_示例：_`<xsl:value-of select="abs(-3.14)"/>` 返回 3.14

__（3）__ fn:ceiling(num) 返回大于 num 参数的最小整数。（注：这里有些文章是写错了的，将大于写成了小于）
_示例：_`<xsl:value-of select="ceiling(3.14)"/>` 返回 4

__（4）__ fn:floor(num) 返回小于等于 num 参数的最大整数。
_示例：_`<xsl:value-of select="floor(3.14)"/>` 返回 3

__（5）__ fn:round(num) 把 num 参数舍入为最接近的整数。
_示例：_`<xsl:value-of select="round(3.14)"/>` 返回 3

__（6）__round-half-to-even(num) 返回距 num 最近的偶数。
_示例：_`<xsl:value-of select="round-half-to-even(0.5)"/>` 返回 0
_示例：_`<xsl:value-of select="round-half-to-even(1.5)"/>` 返回 2
_示例：_`<xsl:value-of select="round-half-to-even(2.5)"/>` 返回 2


## __2、__ XSLT字符串函数
__（1）__ fn:string(arg) 返回参数的字符串值。参数可以是数字、逻辑值或节点集。
_示例：_`<xsl:value-of select="string(314)"/>` 返回 “314”

__（2）__ fn:codepoints-to-string(int,int,…) 根据代码点序列返回字符串。
_示例：_`<xsl:value-of select="codepoints-to-string(84, 104, 233, 114, 232, 115, 101)"/>` 返回 ‘Thérèse’

__（3）__ fn:string-to-codepoints(string) 根据字符串返回代码点序列。
_示例：_`<xsl:value-of select="string-to-codepoints("Thérèse")"/>` 返回 84, 104, 233, 114, 232, 115, 101

__（4）__ fn:codepoint-equal(comp1,comp2) 根据 Unicode 代码点对照，如果 comp1 的值等于 comp2 的值，则返回 true。([http://www.w3.org/2005/02/xpath-functions/collation/codepoint](http://www.w3.org/2005/02/xpath-functions/collation/codepoint))，否则返回 false。
_示例：_`<xsl:value-of select="compare('ghi', 'ghi')"/>` 返回 true

fn:compare(comp1,comp2)
fn:compare(comp1,comp2,collation) 如果 comp1 小于 comp2，则返回 -1。如果 comp1 等于 comp2，则返回 0。如果 comp1 大于 comp2，则返回 1。（根据所用的对照规则）。
_示例：_`<xsl:value-of select="compare('ghi', 'ghi')"/>` 返回 0

__（5）__ fn:concat(string,string,…) 返回字符串的拼接。
_示例：_`<xsl:value-of select="concat('XPath ','is ','FUN!')"/>` 返回 ‘XPath is FUN!’

__（6）__ fn:string-join((string,string,…),sep) 使用 sep 参数作为分隔符，来返回 string 参数拼接后的字符串。
_示例：_`<xsl:value-of select="string-join(('Www.', 'mobansheji', '.', 'com'), '')"/>` 返回 ‘www.mobansheji.com’

__（7）__ fn:substring(string,start,len)
fn:substring(string,start) 返回从start位置开始的指定长度的子字符串。第一个字符的下标是 1。如果省略 len 参数，则返回从位置 start 到字符串末尾的子字符串。
_示例：_`<xsl:value-of select="substring('www.mobansheji.com',1,4)"/>` 返回 ‘www.’
`<xsl:value-of select="substring('www.mobansheji.com',4)"/>` 返回 ‘mobansheji.com’

__（8）__ fn:string-length(string) fn:string-length() 返回指定字符串的长度。如果没有 string 参数，则返回当前节点的字符串值的长度。
_示例：_`<xsl:value-of select="string-length('www.mobansheji.com')"/>` 返回 18

__（9）__ fn:normalize-space(string) fn:normalize-space() 删除指定字符串的开头和结尾的空白，并把内部的所有空白序列替换为一个，然后返回结果。如果没有 string 参数，则处理当前节点。。
_示例：_`<xsl:value-of select="normalize-space(' www.    mobansheji . com ')"/>` 返回 ‘www.mobansheji.com’

__（10）__ fn:upper-case(string) 把 string 参数转换为大写。
_示例：_`<xsl:value-of select="upper-case('The Xpath')"/>` 返回 ‘THE XPATH’

__（11）__ fn:lower-case(string) 把 string 参数转换为小写。
_示例：_`<xsl:value-of select="lower-case('The XML')"/>` 返回 ‘the xml’

__（12）__ fn:translate(string1,string2,string3) 把 string1 中的 string2 替换为 string3。
示例：`<xsl:value-of select="translate('Do you know xml and xpath?','xml','xslt')"/>` 返回 ‘Do you know xslt and xpath?’
_示例：_`<xsl:value-of select="translate('12:30','03','54')"/>` 返回 ’12:45′

__（13）__ fn:escape-uri(stringURI,esc-res) 编码链接地址
_示例：_`<xsl:value-of select="escape-uri("[http://example.com/test#car](http://example.com/test#car)", true())"/>` 返回 “http%3A%2F%2Fexample.com%2Ftest#car”
_示例：_`<xsl:value-of select="escape-uri("[http://example.com/test#car](http://example.com/test#car)", false())"/>` 返回 “[http://example.com/test#car](http://example.com/test#car)”

__（14）__ fn:contains(string1,string2) 如果 string1 包含 string2，则返回 true，否则返回 false。
_示例：_`<xsl:value-of select="contains('XML','XM')"/>` 返回 true

__（15）__ fn:starts-with(string1,string2) 如果 string1 以 string2 开始，则返回 true，否则返回 false。
_示例：_`<xsl:value-of select="starts-with('XML','X')"/>` 返回 true

__（16）__ fn:ends-with(string1,string2) 如果 string1 以 string2 结尾，则返回 true，否则返回 false。
_示例：_`<xsl:value-of select="ends-with('XML','X')"/>` 返回 false

__（17）__ fn:substring-before(string1,string2) 返回 string2 在 string1 中出现之前的子字符串。
_示例：_`<xsl:value-of select="substring-before('www.mobansheji.com','.')"/>` 返回 ‘www’

__（18）__ fn:substring-after(string1,string2) 返回 string2 在 string1 中出现之后的子字符串。
_示例：_`<xsl:value-of select="substring-before('www.mobansheji.com','.')"/>` 返回 ‘mobansheji.com’

__（19）__ fn:matches(string,pattern) 如果 string 参数匹配指定的模式，则返回 true，否则返回 false。
_示例：_`<xsl:value-of select="matches("Merano", "ran")"/>` 返回 true

__（20）__ fn:replace(string,pattern,replace) 把指定的模式替换为 replace 参数，并返回结果。
_示例：_`<xsl:value-of select="replace("The password is admin888", "8", "*")"/>` 返回 ‘The password is admin__*’

__（21）__ fn:tokenize(string,pattern)
_示例：_`<xsl:value-of select="tokenize("XPath is fun", "\s+")"/>` 返回 (“XPath”, “is”, “fun”)


## __3、__ 节点集函数
__（1）__ last()――返回一个称为上下文大小的数字，即给定上下文中的节点数，不同于最后一个节点。

__（2）__ position()――返回一个称为上下文位置的数字，集当前节点在给上下文节点集（列表）中的位置。比如，可以用表达式 position()=last() 测试处理的是否是集合中的最后一个节点。

__（3）__ count(node-set)――返回实参节点集中的节点数。比如，在 AuctionItemList.xml 文档的上下文中，count(//item) 返回 item 元素的个数，即 7。

__（4）__ id(object)――返回一个节点集，根据在 DTD 中声明为 ID 类型的唯一标识符选择元素。因为在 AuctionItemList.xml 中没有使用 DTD，这个例子中得到的节点集总是空集。Id(“ItemId0001”) 返回一个空节点集。
XPath 还定义了和节点名及名称空间有关的其他三个函数：
local-name()
namespace-uri()
name()

## __4、__ 布尔函数
布尔函数用于把一个对象或字符串转化成 true 或者 false，或者直接获得真或假的值。布尔函数有：
__（1）__ boolean()――根据以下规则返回作为参数传递的对象转换成布尔值的结果：不同于 0 或者 NaN 的数字为 true；非空的节点集或者字符串为 true。其他类型的对象已不可预料的方式转换。

__（2）__ not()――如果作为参数传递的布尔值为 false 返回 true，否则返回 false。

__（3）__ true() 和 false()――分别返回 true 或 false。这些函数很有用，因为在 XPath 中 true 和 false 被看作是普通的字符串而不是真和假的值。

__（4）__ lang ()――如果上下文节点的语言和字符串参数中指定的语言相同，或者是它的一种子语言返回 true，否则返回 false。上下文节点的语言通过 xml:lang 属性的值定义。比如，lang(“en”) 对于 AuctionItemList.xml 树中的任何节点都返回 false，因为没有指定 xml:lang 属性。

通过以上xslt数值的函数与xslt字符串函数，我想各位朋友都已经知道了如何用xslt来处理各种数值和字符串了。在实际的应用中可能比示例代码要复杂得多，只有熟练掌握才能应用自如。

>　来源：[http://www.cnblogs.com/iTanken/](http://www.cnblogs.com/iTanken/)
