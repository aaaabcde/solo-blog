title: Wildfly/JBoss EAP 高可用负载均衡配置
date: '2019-07-29 22:41:04'
updated: '2021-12-25 21:48:37'
tags: [Wildfly, JBoss, 高可用, 负载均衡]
permalink: /wildfly-jboss-eap-ha-load-balance
---
![](https://b3logfile.com/bing/20191102.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

基于 [`Wildfly`](https://wildfly.org/) 托管域运行模式，在已配置好集群的前提下，使用 [`Undertow`](http://undertow.io/) 子系统配置负载均衡。

### 集群拓扑：

![Topology](https://img.hacpai.com/file/2019/07/image-02977392.png)

如上图所示，已组成一个由 2 个主机（__master__、__slave__）共 4 个节点（__server-one__、__server-two__、__server-one-slave__ 和 __server-two-slave__）组成的服务器集群（__main-server-group__），将通过 __Undertow__ 子系统配置负载均衡。

### 主机概况

![Hosts](https://img.hacpai.com/file/2019/07/image-fcd603f1.png)

在当前集群中，__master__ `主机控制器`同时充当`域控制器`，来统一配置管理服务器组的配置和部署。

### 集群概况

![Server Groups](https://img.hacpai.com/file/2019/07/image-5ccd7455.png)

高可用集群必须使用 ha 或 full-ha 配置文件启动，当前服务器组使用 __`ha`__ 配置。

__ha__ 与 __full-ha__ 区别是不包含 `jsr77`、`activemq` 和 `iiop-openjdk` 子系统，根据是否需要相关子系统来选择使用 ha 还是 full-ha 配置文件，一般使用 ha 即可。

### 负载均衡

Wildfly 支持多种方式的负载均衡实现，此处仅对使用 Undertow 实现负载均衡进行说明。
从 Wildfly 10 开始支持使用 Undertow 子系统作为前端负载均衡器使用，从 Wildfly 11 开始提供了负载平衡器的配置文件，独立模式为 `standalone-load-balancer.xml`，域模式在 `domain.xml` 的 `<profile  name="load-balancer">` 节点中。
当前最新 Wildfly 版本为 `17.0.1.Final`，最新 JBoss EAP 7.2 基于 Wildfly 14，都支持使用 Undertow 作为负载均衡器。
![load-balancer](https://img.hacpai.com/file/2019/07/image-e2ad4d7e.png)

#### 使用 Undertow 作为负载均衡器概述

> Undertow 代理使用异步 IO，请求中涉及的唯一线程是负责连接的 IO 线程。 与后端服务器的连接是由同一个线程完成的，这样就不需要任何线程安全结构。
> 如果前端和后端服务器都支持服务器推送，并且正在使用 HTTP2，则代理也支持向客户端推送响应。如果代理和后端能够推送服务器，但客户端不支持，服务器将发送一个“X-Disable-Push”头，让后端知道它不应该尝试推送该请求。

#### 将 Undertow 配置为静态负载均衡器

要使用 Undertow 配置静态负载均衡器，需要在 `Undertow` 子系统中配置代理处理程序（Proxy Handler）。 要在 Undertow 中配置代理处理程序，需要在将用作静态负载均衡器的 Wildfly 实例上执行以下操作：

1. 添加反向代理处理程序（Reverse Proxy Handler）：
   
   ```sh
   /profile=load-balancer/subsystem=undertow/configuration=handler/reverse-proxy=my-handler:add
   ```
   
   ![Reverse Proxy Handler](https://img.hacpai.com/file/2019/07/image-cbf76f26.png)
2. 为每个远程主机定义出站套接字绑定（Outbound Socket Binding）：
   
   ```sh
   /socket-binding-group=standard-sockets/remote-destination-outbound-socket-binding=remote-host1/:add(host=server1.example.com, port=8009)
   
   /socket-binding-group=standard-sockets/remote-destination-outbound-socket-binding=remote-host2/:add(host=server2.example.com, port=8009)
   ```
   
   ![image.png](https://img.hacpai.com/file/2019/07/image-e833da35.png)
3. 将每个远程主机添加到反向代理处理程序中：
   
   ```sh
   /profile=load-balancer/subsystem=undertow/configuration=handler/reverse-proxy=my-handler/host=host1:add(outbound-socket-binding=remote-host1, scheme=ajp, instance-id=myroute, path=/test)
   
   /profile=load-balancer/subsystem=undertow/configuration=handler/reverse-proxy=my-handler/host=host2:add(outbound-socket-binding=remote-host2, scheme=ajp, instance-id=myroute, path=/test)
   ```
4. 添加反向代理位置：

.

> 参考资料：
> 
> 1. [https://access.redhat.com/documentation/en-us/red_hat_jboss_enterprise_application_platform/7.2/html/configuration_guide/configuring_high_availability](https://access.redhat.com/documentation/en-us/red_hat_jboss_enterprise_application_platform/7.2/html/configuration_guide/configuring_high_availability)
> 2. [https://docs.wildfly.org/17/Admin_Guide.html](https://docs.wildfly.org/17/Admin_Guide.html)

