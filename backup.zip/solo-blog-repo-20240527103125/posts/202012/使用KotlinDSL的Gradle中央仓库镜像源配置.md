title: 使用 Kotlin DSL 的 Gradle 中央仓库镜像源配置
date: '2020-12-18 15:43:49'
updated: '2020-12-21 17:16:45'
tags: [Kotlin, Groovy, Gradle, Maven]
permalink: /gradle-maven-kotlin-groovy-config
---
![](https://b3logfile.com/bing/20181118.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

使用 Gradle 构建和管理项目，已支持使用 Groovy 和 Kotlin 这两种语言进行配置。使用 IDEA 创建 Kotlin 项目，将默认使用通过 Kotlin DSL 配置的 Gradle 来构建项目。使用这两种语言配置 Maven 镜像源的主要区别是 Groovy 使用 `url` 配置中央仓库地址，而 Kotlin 使用 `setUrl()` 进行配置，详见下文。

### Kotlin DSL

#### 使用 Kotlin DSL 配置普通依赖镜像源

修改 `build.gradle.kts` 文件加入以下内容：

```kts
repositories {
    // 依赖使用阿里云 maven 源
    maven {
        setUrl("https://maven.aliyun.com/repository/public/")
    }
    maven {
        setUrl("https://maven.aliyun.com/repository/spring/")
    }
    mavenLocal()
    mavenCentral()
}
```

#### 使用 Kotlin DSL 配置插件依赖镜像源

修改 `settings.gradle.kts` 文件加入以下内容：

```kts
pluginManagement {
    repositories {
        // 插件使用阿里云 maven 源
        maven {
         setUrl("https://maven.aliyun.com/repository/gradle-plugin")
        }
    }
}
```

#### 简写

以上 `maven { setUrl(url) }` 部分可简写为 `maven(url)`：

```kts
maven("https://maven.aliyun.com/repository/public/")
```

### Groovy DSL

#### 使用 Groovy DSL 配置普通依赖镜像源

修改 `build.gradle` 文件：

```groovy
allProjects {
  repositories {
    maven {
      url 'https://maven.aliyun.com/repository/public/'
    }
    maven {
        url 'https://maven.aliyun.com/repository/spring/'
    }
    mavenLocal()
    mavenCentral()
  }
}
```

#### 使用 Groovy DSL 配置插件依赖镜像源

修改 `settings.gradle` 文件加入以下内容：

```groovy
pluginManagement {
    repositories {
        // 插件使用阿里云 maven 源
        maven {
            url 'https://maven.aliyun.com/repository/gradle-plugin'
        }
    }
}
```

### 参考资料

https://maven.aliyun.com/mvn/guide

