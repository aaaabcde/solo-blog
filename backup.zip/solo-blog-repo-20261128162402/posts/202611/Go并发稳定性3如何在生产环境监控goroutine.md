title: Go 并发稳定性（3）：如何在生产环境监控 goroutine
date: '2026-11-17 15:42:45'
updated: '2026-11-17 16:23:39'
tags: [Go, Golang, 协程, 并发]
permalink: /go-concurrency-stability-3-goroutine
---
![](https://b3logfile.com/bing/20231120.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> goroutine 的创建很容易，但如何确保它们按照预期运行、及时退出，并且不会在系统中无限积累，才是真正考验 Go 工程能力的地方。

Go 语言最大的优势之一就是轻量级并发。开发者可以通过 `go` 关键字轻松启动一个 goroutine，而不必像传统线程模型那样承担较高的创建和切换成本。

但这也带来了一个容易被忽视的问题：**goroutine 很容易被创建，却不一定能够按照预期退出。**

在实际项目中，并发问题通常不会立即表现为程序崩溃，而可能逐渐表现为：

- goroutine 数量持续增长；
- 某些请求处理时间越来越长；
- channel、mutex 等同步操作出现大量等待；
- 堆内存和 GC 开销逐渐增加；
- 服务运行一段时间后出现响应延迟或资源异常。

如果没有建立完善的监控体系，这些问题很难在早期被发现。

本文以 Go 1.26 为基础，从运行时指标、pprof 性能分析、Prometheus 监控和生产环境排查几个方面，介绍如何建立一套实用的 goroutine 可观测体系。

---

## 一、为什么需要监控 goroutine？

首先需要明确一个概念：

**goroutine 数量多，不代表一定存在问题；goroutine 数量持续增长，也不代表一定发生了泄露。**

例如，一个 HTTP 服务在高并发期间会创建大量用于处理请求的 goroutine。当请求结束后，这些 goroutine 正常退出，数量也会随之下降。

因此，单纯观察 goroutine 数量没有太大意义，更重要的是观察它的变化趋势，以及 goroutine 当前处于什么状态。

### 1. goroutine 泄露的典型表现

goroutine 泄露通常是指：某些 goroutine 已经失去了实际业务价值，却由于阻塞、缺少退出条件或者生命周期管理不当，无法正常结束。

常见原因包括：

| 问题类型 | 典型表现 |
| --- | --- |
| `channel` 阻塞 | 发送或接收操作一直等待 |
| `context` 使用不当 | 子任务没有响应取消信号 |
| 网络请求缺少超时 | goroutine 长时间等待 I/O |
| `mutex` 锁竞争 | 大量 goroutine 等待同一把锁 |
| 后台任务缺少退出机制 | 无限循环无法正常终止 |
| `WaitGroup` 使用不当 | 部分任务无法完成，导致一直等待 |

需要注意，长时间等待并不一定意味着泄露。例如，正常运行的 worker 可能一直阻塞在 channel 接收操作上，等待下一条任务。

判断是否泄露，需要结合业务预期、调用栈和生命周期进行分析。

### 2. goroutine 泄露可能造成什么影响？

goroutine 泄露的直接影响包括：

- goroutine 栈内存占用增加；
- goroutine 持有的对象无法被垃圾回收；
- channel、mutex 等同步资源可能长期处于异常状态；
- 额外的调度和运行时管理开销。

当这些问题持续积累时，可能进一步影响服务性能。

例如：

```mermaid
flowchart TD
    A[goroutine 泄露] --> B[goroutine 数量持续增加]
    B --> C[栈内存及关联对象占用增加]
    C --> D[内存与运行时管理开销可能增加]
    D --> E[服务资源利用率和响应延迟可能受到影响]
```

这是一种可能的演化路径，并不是每次 goroutine 泄露都会导致 GC 压力或 RT 上升。实际影响取决于泄露数量、栈大小、引用对象以及系统负载。

---

## 二、建立 goroutine 监控指标体系

要发现 goroutine 泄露，首先需要建立基础监控指标。

Go 标准库提供了两个非常实用的工具：

- `runtime`：获取运行时基础信息；
- `runtime/metrics`：获取更丰富的运行时指标。

### 1. 监控 goroutine 总数

最简单的方式是使用：

```go
runtime.NumGoroutine()
```

示例：

```go
package main

import (
    "log"
    "runtime"
    "time"
)

func monitorGoroutines() {
    ticker := time.NewTicker(10 * time.Second)
    defer ticker.Stop()

    for range ticker.C {
        log.Printf(
            "当前 goroutine 数量: %d",
            runtime.NumGoroutine(),
        )
    }
}
```

在服务启动时运行：

```go
go monitorGoroutines()
```

这样就可以定期获取当前 goroutine 数量。

不过，这种方式只能获得一个总量，无法判断 goroutine 为什么增加，也无法知道它们具体阻塞在哪里。

因此，它更适合作为基础监控指标，而不是独立的故障诊断工具。

### 2. 使用 runtime/metrics 获取运行时指标

Go 1.26 对运行时指标提供了进一步增强。

通过 `runtime/metrics`，可以获取比 `runtime.NumGoroutine()` 更丰富的调度器状态信息。

其中与 goroutine 相关的重要指标包括：

| 指标名称 | 含义 |
| --- | --- |
| `/sched/goroutines:goroutines` | 当前存活的 goroutine 数量 |
| `/sched/goroutines-created:goroutines` | 程序启动以来累计创建的 goroutine 数量 |
| `/sched/goroutines/runnable:goroutines` | 已准备好运行、但尚未获得执行机会的 goroutine 数量 |
| `/sched/goroutines/running:goroutines` | 当前正在执行的 goroutine 数量 |
| `/sched/goroutines/waiting:goroutines` | 正在等待资源的 goroutine 数量 |
| `/sched/goroutines/not-in-go:goroutines` | 正在系统调用或 cgo 调用中运行或阻塞的 goroutine 数量 |
| `/sched/threads:threads` | Go runtime 当前管理的操作系统线程数量 |

其中，最值得关注的是：

- `goroutines`：判断 goroutine 总量是否异常；
- `goroutines/waiting`：观察等待资源的 goroutine 数量；
- `goroutines/runnable`：观察等待调度执行的 goroutine 数量；
- `goroutines-created`：观察 goroutine 的累计创建趋势。

需要注意，`runnable`、`running`、`waiting` 等指标是近似统计值，不能简单相加得到 goroutine 总数。

另外，累计创建数量本身持续增长是正常现象，不能直接用于判断泄露。它更适合与存活数量结合分析。

### 3. 使用 runtime/metrics 采集指标

下面实现一个通用的运行时指标采集函数：

```go
package monitor

import (
    "runtime/metrics"
)

type GoroutineMetrics struct {
    Total   uint64
    Created uint64
    Runnable uint64
    Running uint64
    Waiting uint64
}

func ReadGoroutineMetrics() GoroutineMetrics {
    samples := []metrics.Sample{
        {Name: "/sched/goroutines:goroutines"},
        {Name: "/sched/goroutines-created:goroutines"},
        {Name: "/sched/goroutines/runnable:goroutines"},
        {Name: "/sched/goroutines/running:goroutines"},
        {Name: "/sched/goroutines/waiting:goroutines"},
    }

    metrics.Read(samples)

    return GoroutineMetrics{
        Total:    samples[0].Value.Uint64(),
        Created:  samples[1].Value.Uint64(),
        Runnable: samples[2].Value.Uint64(),
        Running:  samples[3].Value.Uint64(),
        Waiting:  samples[4].Value.Uint64(),
    }
}
```

调用示例：

```go
func main() {
    m := monitor.ReadGoroutineMetrics()

    log.Printf(
        "goroutines total=%d created=%d runnable=%d running=%d waiting=%d",
        m.Total,
        m.Created,
        m.Runnable,
        m.Running,
        m.Waiting,
    )
}
```

实际项目中，可以将这些指标定期采集，并接入 Prometheus、Grafana 等监控系统。

如果需要兼容不同 Go 版本，还应通过 `metrics.All()` 检查指标是否存在，再决定是否读取，避免对不支持的指标直接调用 `Uint64()`。

---

## 三、pprof：定位 goroutine 异常的核心工具

前面的运行时指标可以帮助我们发现异常，但无法回答一个关键问题：

**到底是哪段代码创建了这些 goroutine？它们为什么没有退出？**

这就需要使用 pprof。

pprof 是 Go 官方提供的性能分析工具，可以分析 CPU、内存、goroutine、锁竞争和阻塞等问题。

其中与并发问题最相关的有：

- goroutine profile；
- block profile；
- mutex profile；
- CPU profile；
- heap profile。

### 1. 在服务中开启 pprof

Go 标准库提供了 `net/http/pprof` 包。

最简单的方式：

```go
import (
    _ "net/http/pprof"
    "net/http"
)

func startPprof() {
    go func() {
        if err := http.ListenAndServe(
            "127.0.0.1:6060",
            nil,
        ); err != nil {
            log.Printf("pprof server stopped: %v", err)
        }
    }()
}
```

在服务启动时调用：

```go
startPprof()
```

启动后，可以通过以下地址访问：

```text
http://127.0.0.1:6060/debug/pprof/
```

这里有一个生产环境需要特别注意的问题：

**不要直接将 pprof 接口暴露到公网。**

pprof 可能暴露：

- 内部函数调用栈；
- 项目包名和代码结构；
- 运行时资源信息；
- 部分业务调用上下文。

生产环境建议使用独立的管理端口，并通过内网、VPN、防火墙或身份认证进行访问控制。

如果项目使用 Gin、Echo 等框架，或者没有使用默认的 `http.DefaultServeMux`，需要显式注册对应的 pprof Handler。

### 2. 查看 goroutine 调用栈

执行：

```bash
curl "http://127.0.0.1:6060/debug/pprof/goroutine?debug=2"
```

也可以使用：

```bash
go tool pprof \
  http://127.0.0.1:6060/debug/pprof/goroutine
```

goroutine profile 会展示当前 goroutine 的调用栈。

例如：

```shell
goroutine 1024 [chan send]:
main.asyncNotify.func1()
    /app/service/notify.go:35

goroutine 1025 [chan send]:
main.asyncNotify.func1()
    /app/service/notify.go:35

goroutine 1026 [chan send]:
main.asyncNotify.func1()
    /app/service/notify.go:35
```

如果发现大量 goroutine 具有相同的调用栈，并且集中在某个 channel 发送操作上，就值得进一步排查。

例如：

```go
func asyncNotify(data Data) {
    ch := make(chan Result)

    go func() {
        result := doRequest(data)
        ch <- result
    }()

    select {
    case result := <-ch:
        handle(result)
    case <-time.After(time.Second):
        return
    }
}
```

当外层函数超时返回后，如果内部 goroutine 完成 `doRequest`，就可能永久阻塞在 `ch <- result`。

这种情况在 goroutine profile 中可能表现为大量相同的 `chan send` 调用栈。

需要强调的是：

- `chan send` 不一定是泄露；
- `chan receive` 不一定是泄露；
- `sync.Mutex.Lock` 不一定是死锁。

这些状态只能说明 goroutine 当前正在等待某种操作，必须结合业务逻辑和调用关系进一步判断。

### 3. 使用 block profile 分析阻塞

goroutine profile 能看到当前 goroutine 在哪里等待。

但如果希望进一步分析程序在哪些同步操作上累计花费了大量阻塞时间，可以使用 block profile。

开启方式：

```go
runtime.SetBlockProfileRate(1)
```

参数 `1` 表示尽可能记录所有阻塞事件，适合测试和问题排查，但会带来额外开销。

生产环境建议根据性能开销选择合适的采样率，不建议未经评估就长期全量采集。

获取分析数据：

```bash
go tool pprof \
    http://127.0.0.1:6060/debug/pprof/block
```

block profile 主要关注：

- channel 发送和接收；
- Mutex / RWMutex；
- WaitGroup；
- Cond。

它可以帮助我们定位程序中累计阻塞时间较长的位置。

### 4. 使用 mutex profile 分析锁竞争

如果怀疑 goroutine 大量阻塞在锁上，可以开启 mutex profile：

```go
runtime.SetMutexProfileFraction(1)
```

参数 `1` 表示记录每一次锁竞争事件，适合短时间问题排查，同样需要评估开销。

获取分析数据：

```bash
go tool pprof \
    http://127.0.0.1:6060/debug/pprof/mutex
```

需要注意一个容易混淆的地方：

**mutex profile 展示的是导致其他 goroutine 等待的锁持有位置，而不是简单地展示所有等待获取锁的代码位置。**

例如，某个函数持有全局锁执行了耗时的数据库查询，那么其他 goroutine 就可能长时间等待这把锁。

通过 mutex profile，可以帮助我们定位造成竞争的临界区。

### 5. 使用 CPU profile 和 heap profile 辅助分析

goroutine 数量异常不一定是唯一问题。

有时候服务 RT 上升，真正原因可能是 CPU 消耗过高或者内存分配过于频繁。

CPU profile：

```bash
go tool pprof \
    http://127.0.0.1:6060/debug/pprof/profile?seconds=30
```

Heap profile：

```bash
go tool pprof \
    http://127.0.0.1:6060/debug/pprof/heap
```

在 pprof 交互界面中，可以使用：

```text
top
list
web
```

查看热点函数、源码位置和调用关系。

不同 profile 的定位范围如下：

| Profile | 主要解决的问题 |
| --- | --- |
| goroutine | 当前 goroutine 在做什么 |
| block | 哪些同步操作累计阻塞时间较长 |
| mutex | 哪些临界区导致锁竞争 |
| CPU | 哪些函数消耗了大量 CPU |
| heap | 哪些对象占用了大量内存 |

实际排查时，不应该只依赖某一种 profile，而应该结合多个维度分析。

---

## 四、Go 1.26 的新能力：goroutineleak profile

这是 Go 1.26 值得关注的一项运行时实验特性。

过去，我们主要依赖 goroutine profile 人工判断是否存在泄露。

但 goroutine profile 只会展示当前存活的 goroutine，无法直接区分哪些是正常等待，哪些已经永久无法恢复。

Go 1.26 引入了实验性的 `goroutineleak` profile，可以尝试识别一类已经永久阻塞的 goroutine。

### 1. 它是如何工作的？

简单来说，运行时会结合垃圾回收器的可达性分析，判断某些阻塞中的 goroutine 是否已经不可能被唤醒。

例如：

```go
func processWorkItems(items []WorkItem) error {
    ch := make(chan error)

    for _, item := range items {
        go func() {
            ch <- process(item)
        }()
    }

    for range items {
        if err := <-ch; err != nil {
            return err
        }
    }

    return nil
}
```

这里存在一个问题：

如果某个任务返回错误，主 goroutine 就会提前退出。

但其他任务仍然可能执行：

```go
ch <- process(item)
```

由于没有接收者，且 channel 没有其他可达的接收方，这些 goroutine 可能永久阻塞。

在满足运行时检测条件时，`goroutineleak` profile 可以识别这类问题。

### 2. 如何启用？

Go 1.26 中，这项能力仍然属于实验特性，需要在构建时启用：

```bash
GOEXPERIMENT=goroutineleakprofile go build
```

Windows PowerShell：

```powershell
$env:GOEXPERIMENT="goroutineleakprofile"
go build
```

启用后，可以通过以下接口获取数据：

```text
/debug/pprof/goroutineleak
```

也可以使用：

```bash
go tool pprof \
    http://127.0.0.1:6060/debug/pprof/goroutineleak
```

### 3. 它能代替普通 goroutine profile 吗？

不能。需要注意：

- 它只能识别符合特定条件的一类 goroutine 泄露；
- 依赖运行时的可达性分析；
- 通过全局变量或其他仍然可达对象维持的阻塞关系，可能无法被识别；
- 正常等待资源的 goroutine 不应该被误认为泄露。

因此，生产环境仍然需要保留普通 goroutine profile。

这项实验特性更适合作为额外的辅助诊断能力，而不是唯一的泄露检测手段。

---

## 五、使用 Prometheus 建立生产监控

前面介绍的运行时指标和 pprof，解决的是数据采集和问题诊断。

但如果希望在生产环境中提前发现问题，还需要建立持续监控和告警机制。

Prometheus 是 Go 服务中比较常见的监控方案。

### 1. 建议采集哪些指标？

可以将监控指标分为四类。

#### 第一类：goroutine 指标

| 指标 | 监控目的 |
| --- | --- |
| goroutines_total | 当前存活数量 |
| goroutines_created_total | 累计创建数量 |
| goroutines_waiting | 等待资源数量 |
| goroutines_runnable | 等待调度数量 |
| goroutines_running | 正在运行数量 |

#### 第二类：内存和 GC 指标

| 指标 | 监控目的 |
| --- | --- |
| heap_alloc_bytes | 当前堆分配量 |
| heap_inuse_bytes | 当前堆使用量 |
| stack_inuse_bytes | goroutine 栈使用量 |
| gc_cycles_total | GC 次数 |
| gc_pause_seconds | GC 停顿时间 |

#### 第三类：接口性能指标

| 指标 | 监控目的 |
| --- | --- |
| http_requests_total | 请求总量 |
| http_request_duration_seconds | 请求耗时 |
| HTTP 5xx 比例 | 服务错误率 |
| p95 / p99 | 尾延迟变化 |

#### 第四类：系统资源指标

- CPU 使用率；
- 进程 RSS；
- 操作系统线程数量；
- 文件描述符数量；
- 网络连接数量。

这些指标需要结合起来观察，才能判断服务是否存在资源异常。

### 2. goroutine 指标如何接入 Prometheus？

以 `github.com/prometheus/client_golang` 为例，可以使用 Gauge 采集当前运行时状态。

```go
package monitor

import (
    "runtime/metrics"

    "github.com/prometheus/client_golang/prometheus"
)

var (
    goroutinesTotal = prometheus.NewGauge(
        prometheus.GaugeOpts{
            Name: "app_goroutines",
            Help: "当前活跃 goroutine 的数量。",
        },
    )

    goroutinesWaiting = prometheus.NewGauge(
        prometheus.GaugeOpts{
            Name: "app_goroutines_waiting",
            Help: "等待中 goroutine 的大致数量。",
        },
    )

    goroutinesRunnable = prometheus.NewGauge(
        prometheus.GaugeOpts{
            Name: "app_goroutines_runnable",
            Help: "可运行 goroutine 的大致数量。",
        },
    )
)

func Register() {
    prometheus.MustRegister(
        goroutinesTotal,
        goroutinesWaiting,
        goroutinesRunnable,
    )
}

func Collect() {
    samples := []metrics.Sample{
        {Name: "/sched/goroutines:goroutines"},
        {Name: "/sched/goroutines/waiting:goroutines"},
        {Name: "/sched/goroutines/runnable:goroutines"},
    }

    metrics.Read(samples)

    goroutinesTotal.Set(float64(samples[0].Value.Uint64()))
    goroutinesWaiting.Set(float64(samples[1].Value.Uint64()))
    goroutinesRunnable.Set(float64(samples[2].Value.Uint64()))
}
```

在服务启动时：

```go
monitor.Register()
monitor.Collect()
```

然后通过定时任务周期性调用：

```go
monitor.Collect()
```

最后通过 Prometheus HTTP Handler 暴露指标。

例如：

```go
http.Handle(
    "/metrics",
    promhttp.Handler(),
)
```

注意：

- `Register()` 只需要执行一次；
- `Collect()` 需要定期执行；
- 实际项目应使用独立的管理端口或已有的监控 HTTP 服务；
- 如果要兼容多个 Go 版本，需要先检查指标是否存在。

对于生产环境，更推荐将这些采集逻辑封装成独立的监控模块，避免业务代码直接依赖具体的指标采集实现。

### 3. 为什么还要监控 p95 / p99？

只监控 goroutine 数量是不够的。

例如：

```text
goroutine 数量：200 -> 200 -> 200 -> 200
```

看起来完全正常。

但如果：

```text
接口 p99：100ms -> 150ms -> 500ms -> 2000ms
```

说明系统可能已经出现了性能问题。

p95 和 p99 分别表示 95% 和 99% 的请求耗时不超过对应的统计值。

建议使用 Histogram 记录请求耗时，再由 Prometheus 计算分位数。

例如：

```promql
histogram_quantile(
    0.95,
    sum by (le) (
        rate(http_request_duration_seconds_bucket[5m])
    )
)
```

计算 p95。

```promql
histogram_quantile(
    0.99,
    sum by (le) (
        rate(http_request_duration_seconds_bucket[5m])
    )
)
```

计算 p99。

需要注意，Histogram 的 bucket 边界会影响分位数估算精度，应根据实际接口耗时分布合理设置。

另外，p99 需要有足够的请求样本量才能具有参考价值，低流量接口不适合仅凭短时间内的 p99 波动进行故障判断。

---

## 六、如何设计 goroutine 异常告警？

监控数据采集完成后，接下来就是告警设计。

这里有一个非常重要的原则：

**不要使用一个固定的 goroutine 数量阈值，判断所有 Go 服务是否存在泄露。**

例如：

```text
goroutine > 1000
```

对于一个每秒处理数千个请求的服务，这个数量可能很正常。

但对于一个低流量的定时任务服务，持续增长到 1000 就值得关注。

因此，告警应该结合服务自身的运行特征。

### 1. 建立正常运行基线

首先观察服务在正常状态下的 goroutine 数量。

例如：

```text
服务启动：       20
正常运行：       80
业务高峰：      150
高峰结束：       85
```

这就是服务的正常运行基线。

如果后续出现：

```text
服务启动：       20
正常运行：      100
业务高峰：      200
高峰结束：      180
持续运行：      300
持续运行：      500
持续运行：      800
```

那么就应该开始排查。

### 2. 关注 goroutine 增长速率

相比固定数量，更值得关注的是 goroutine 数量的变化趋势。

例如：

```promql
deriv(app_goroutines[10m])
```

该表达式用于观察过去 10 分钟内 goroutine 数量的线性变化趋势。

如果增长速率长期为正，并且没有随着请求量下降而回落，就需要进一步分析。

也可以结合请求量进行判断：

```mermaid
flowchart TD
    A[QPS 基本稳定] --> D[综合观察指标]
    B[goroutine 持续增长] --> D
    C[waiting 数量持续增长] --> D
    D --> E[可能存在 goroutine 堆积或泄露]
```

需要注意，这只是排查信号，不是泄露的直接证明。

### 3. 建议建立三类告警

| 告警类型 | 触发条件 | 处理建议 |
| --- | --- | --- |
| 数量异常 | goroutine 超出自身历史基线 | 检查流量和任务并发 |
| 持续增长 | 长时间持续增长且没有回落 | 抓取 goroutine profile |
| 性能异常 | goroutine 增长伴随 p99、内存异常 | 联合分析 block、mutex、heap profile |

告警条件应结合历史数据、业务峰值和服务容量进行调整，不建议直接套用统一阈值。

---

## 七、生产环境 goroutine 泄露排查实战

假设某个 Go 服务运行一段时间后，出现以下现象：

```text
运行时间：        8 小时
goroutine 数量：  150 -> 1200
CPU 使用率：      基本正常
内存使用量：      持续增长
接口 p99：        明显上升
```

应该如何排查？

建议按照以下步骤进行。

### 第一步：确认异常是否真实存在

首先观察：

- goroutine 数量是否持续增长；
- 流量是否同步增长；
- 业务高峰结束后数量是否回落；
- 服务重启后是否恢复。

不要因为某个时间点 goroutine 数量较高，就直接判定发生泄露。

### 第二步：获取 goroutine profile

执行：

```bash
curl -o goroutine.out \
    http://127.0.0.1:6060/debug/pprof/goroutine
```

使用 pprof 分析：

```bash
go tool pprof goroutine.out
```

或者直接查看完整调用栈：

```bash
curl \
    "http://127.0.0.1:6060/debug/pprof/goroutine?debug=2" \
    > goroutine.txt
```

重点观察：

- 是否存在大量相同调用栈；
- 是否集中在某个业务函数；
- 是否存在大量 channel send / receive；
- 是否存在大量 Mutex.Lock；
- 是否存在长时间等待的网络请求。

### 第三步：分析异常调用栈

假设发现大量 goroutine 阻塞在：

```text
goroutine 1024 [chan send]:
main.asyncNotify.func1()
    /app/service/notify.go:35
```

结合业务代码：

```go
func asyncNotify(data Data) {
    ch := make(chan Result)

    go func() {
        result := doRequest(data)
        ch <- result
    }()

    select {
    case result := <-ch:
        handle(result)
    case <-time.After(time.Second):
        return
    }
}
```

就可以发现：

超时后外层函数已经退出，但内部 goroutine 仍然可能阻塞在 channel 发送操作。

这就是一个典型的 goroutine 泄露场景。

### 第四步：修复问题

可以使用带缓冲的 channel：

```go
ch := make(chan Result, 1)
```

也可以通过 context 统一控制任务生命周期，并确保底层请求支持取消。

例如：

```go
func asyncNotify(ctx context.Context, data Data) error {
    ctx, cancel := context.WithTimeout(
        ctx,
        time.Second,
    )
    defer cancel()

    result, err := doRequest(ctx, data)
    if err != nil {
        return err
    }

    handle(result)
    return nil
}
```

如果 `doRequest` 本身支持 context 取消，这种同步调用方式通常更简单，也避免了不必要的 goroutine。

### 第五步：验证修复效果

修复后，不应该只验证接口是否正常，还需要观察：

- goroutine 数量是否恢复稳定；
- 异常调用栈是否消失；
- 内存使用量是否趋于稳定；
- p95 / p99 是否改善；
- 长时间运行后是否再次出现相同问题。

**一次完整的故障修复，应该包含问题定位、代码修复和运行时验证。**

---

## 八、生产环境监控实践建议

结合前面的内容，我认为一个 Go 服务至少应该具备以下能力：

### 基础监控

- [x] 定期采集 goroutine 总数；
- [x] 采集运行时调度指标；
- [x] 采集堆内存和 GC 指标；
- [x] 采集 HTTP 请求耗时；
- [x] 监控 p95 / p99。

### 问题诊断

- [x] 提供受保护的 pprof 访问入口；
- [x] 能够获取 goroutine profile；
- [x] 能够分析 block profile；
- [x] 能够分析 mutex profile；
- [x] 必要时采集 CPU 和 heap profile。

### 并发稳定性

- [x] 后台 goroutine 有明确的退出条件；
- [x] 定时任务能够正常停止；
- [x] channel 发送和接收有明确的生命周期约束；
- [x] 网络请求设置合理的超时；
- [x] 并发任务能够响应 context 取消；
- [x] 长时间运行的服务经过稳定性测试。

---

## 九、写在最后

Go 的并发能力非常强大，但 goroutine 的轻量级特性并不意味着可以忽略它们的生命周期管理。

在生产环境中，真正重要的不是 goroutine 数量有多少，而是：

- 创建的 goroutine 是否有明确的用途；
- 运行中的 goroutine 是否处于合理状态；
- 阻塞的 goroutine 是否仍然有机会被唤醒；
- 不再需要的 goroutine 是否能够及时退出。

从 `runtime.NumGoroutine()` 到 `runtime/metrics`，再到 pprof 和 Prometheus，Go 已经提供了相当完善的运行时观测能力。

**监控负责发现异常，pprof 负责定位问题，代码设计负责从根本上避免问题。**

这三者结合起来，才能真正建立一套可靠的 Go 并发稳定性保障体系。

---

## 参考资料

1. [Go 1.26 Release Notes](https://go.dev/doc/go1.26)
2. [runtime/metrics 官方文档](https://pkg.go.dev/runtime/metrics)
3. [net/http/pprof 官方文档](https://pkg.go.dev/net/http/pprof)
4. [Go Diagnostics 官方指南](https://go.dev/doc/diagnostics)
5. [Prometheus Histograms and Summaries](https://prometheus.io/docs/practices/histograms/)

