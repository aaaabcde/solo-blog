title: 阿里巴巴 Android 开发手册分享
date: '2018-02-28 15:29:06'
updated: '2019-04-21 23:35:53'
tags: [Android, 文档, 阿里巴巴]
permalink: /alibaba-android-development-manual
---
继《阿里巴巴Java开发手册》修订完善并趋于稳定之后，阿里技术团队的又一走心之作《阿里巴巴Android开发手册》也发布了正式版（首次公开），本手册以开发者为中心视角分为 Java 语言规范（遵循《阿里巴巴Java开发手册》），Android 资源文件命名与使用，Android 基本组件，UI 与布局，进程、线程与消息通信，文件与数据库，Bitmap、Drawable 与动画，安全，其他等九大部分。

同 [阿里巴巴 Java 开发规范手册分享](https://zixizixi.cn/articles/2017/01/17/1484623303271.html) 这篇文章一样，本文将记录此手册的所有版本记录，并将一直保持更新。

## 2017-03-05 更新 1.0.1 版(正式版)

| 版本号 | 制定团队 | 更新日期 | 备注 |
| :-----:| :------------- |:-------------:| :---------:|
| 1.0.1 | 淘宝技术团队等 | **2018.03.05** | 修正部分示例和说明... |

> 1. [阿里巴巴Android开发规范手册（1.0.1）.pdf](https://www.itanken.cn/download?dir=docs/android/&name=阿里巴巴Android开发规范手册（1.0.1）.pdf)
> 2. [v1.0.1 版阿里云下载](https://102.alibaba.com/downloadFile.do?file=1520478361732/Android_v9.pdf)
> 
>> **`更新说明：`** 
>> 1) 修正部分示例和说明；
>> 2) 补充汇总参考文献到附录；
>> 3) 修正排版问题。
>> ![手册钉钉交流群](//res.zixizixi.cn/file/2018/3/1da41f0bbfb848c6b1aaca6138d66259-201803086.28.58.jpg.zximg) 

### 参考文献
> [1] [Google. Developer Guides [EB/OL]. ](https://developer.android.com/guide/index.html) 
> [2] [Google. Class Index [EB/OL]. ](https://developer.android.com/reference/classes.html) 
> [3] [Alex Lockwood. Android Design Patterns [EB/OL]. ](https://www.androiddesignpatterns.com/) 
> [4] [O'Reilly. High Performance Android Apps by Doug Sillars [EB/OL]. ](https://www.safaribooksonline.com/library/view/high-performance-android/9781491913994/ch04.html#figure-story_tree) 
> [5] [Takeshi Terada. Whitepaper – Attacking Android browsers via intent scheme URLs [EB/OL]. ](https://www.mbsd.jp/Whitepaper/IntentScheme.pdf) 
> [6] [张明云. Android 开发中，有哪些坑需要注意？ [EB/OL]. ](https://zhuanlan.zhihu.com/p/20309921) 
> [7] [MegatronKing. Android 多个 Fragment 嵌套导致的三大 BUG [EB/OL]. ](http://blog.csdn.net/megatronkings/article/details/51417510) 
> [8] [Nfrolov. Android: SQLiteDatabase locking and multi-threading [EB/OL]. ](https://nfrolov.wordpress.com/2014/08/16/android-sqlitedatabase-locking-and-multi-threading) 
> [9] [gcoder_io. Android 数据库模块搭建方案 [EB/OL]. ](https://www.jianshu.com/p/57eb08fe071d)

## 2017-02-28 发布 1.0.0 版(正式版)

| 版本号 | 制定团队 | 更新日期 | 备注 |
| :-----:| :------------- |:-------------:| :---------:|
| 1.0.0 | 淘宝技术团队等 | **2018.02.28** | 正式版，首次公开 |

> 1. [阿里巴巴Android开发规范手册（1.0.0）.pdf](https://www.itanken.cn/download?dir=docs/android/&name=阿里巴巴Android开发规范手册（1.0.0）.pdf)
> 2. [v1.0.0 版阿里云下载](https://102.alibaba.com/downloadFile.do?file=1519806643286/Android1_0_0.pdf)
> 
>> **`发布说明：`** 
>> 2017年天猫双11，成交额再创新高达到1682亿元，其中无线交易额占比90%；2017年12月，钉钉在诞生1075天后，注册用户突破1亿；而在同期，闲鱼用户也突破了2亿……面对如此大的用户量和流量，这些App依然可以做到“丝般顺滑”。
>> 在这背后，是阿里巴巴移动开发团队的不断探索和优化，久而久之，这些经验汇总成了一套完善的开发规范，指导工程师开发出体验好、性能优、稳定性佳、安全性高的App。
>> 该开发规范在阿里内部经过了不断完善，现在整理成册，并向业界Android开发者开放，希望能够帮助企业和开发者少走弯路，提升Android开发的质量和效率。

> 编码规范考试认证：[https://edu.aliyun.com/certification/cldt04](https://edu.aliyun.com/certification/cldt04)
>> **`关于认证考试：`**
>> 手册发布之际，「阿里巴巴Android开发规范」认证考试也同步上线，通过在线考试，检测你对手册中开发规范的掌握程度，并发放官方认证证书。

[来源](https://yq.aliyun.com/articles/499254?spm=a2c4e.11163080.searchblog.9.3e5f2ec1YDdcu2)


### 手册前言
> 车同轨，书同文，《阿里巴巴 Android 开发手册》既是高效合作的基础，也是深度 创新的开始。 ——淘宝技术负责人 庄卓然
《阿里巴巴 Android 开发手册》是阿里巴巴集团各大 Android 开发团队的集体智慧 结晶和经验总结，将淘宝、天猫、闲鱼、钉钉等 App 长期开发迭代和优化经验系统地整 理成册，以指导 Android 开发者更加高效、高质量地进行 App 开发，呈现给用户体验好、 性能优、稳定性佳、安全性高的产品。
《阿里巴巴 Android 开发手册》作为阿里巴巴开发规约重要的一环，我们的目标是: 防患未然，提升质量意识，降低故障率和维护成本;
标准统一，提升协作效率;
追求卓越的工匠精神，打磨精品代码。
本手册以开发者为中心视角分为 Java 语言规范(遵循《阿里巴巴 Java 开发手册》)， Android 资源文件命名与使用，Android 基本组件，UI 与布局，进程、线程与消息通信， 文件与数据库，Bitmap、Drawable 与动画，安全，其他等九大部分，根据约束力强弱， 规约依次分为强制、推荐、参考三大类:
> 
 * 【强制】必须遵守，违反本约定或将会引起严重的后果;
 * 【推荐】尽量遵守，长期遵守有助于系统稳定性和合作效率的提升;
 * 【参考】充分理解，技术意识的引导，是个人学习、团队沟通、项目合作的方 向。
> 
> 对于规约条目的延伸信息中，“说明”对内容做了适当扩展和解释;“正例”提倡 什么样的编码和实现方式;“反例”说明需要提防的雷区，以及错误案例。
> 另外，「阿里巴巴 Android 开发规范」认证考试同步上线，详情请访问: https://edu.aliyun.com/certification/cldt04
> 《阿里巴巴 Android 开发手册》项目组成员，排名不分先后:芸墨(淘宝技术部)、 矢亮(智能场景事业部)、游僧(淘宝技术部)、景宝(淘宝技术部)、邻云(闲鱼技 术部)、尚节(猫客技术部)等，还有很多阿里巴巴移动端工程师参与，在此一并表示 感谢，感谢孤尽(《阿里巴巴 Java 开发手册》主要作者)对手册的指导。

![封面图片](//res.zixizixi.cn/file/2018/2/87ddfbadc9a645f3a8b53f69b69354a4-image.png "封面图片") 

![目录图片](//res.zixizixi.cn/file/2018/2/e6b07e417285475e8cbcf0c2e17d9f8b-image.png "目录图片") 






