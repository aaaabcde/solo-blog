title: Windows 下 VSCode 使用 SSH 连接报 Bad owner or permissions on C:\\Users\\Administrator/.ssh/config
  错误问题解决
date: '2019-09-12 09:19:08'
updated: '2022-09-21 10:47:50'
tags: [Windows, SSH, VSCode, PowerShell]
permalink: /windows_vscode_ssh_error_bad-owner-or-permissions
---
## 问题描述

在 Windows 系统下的 VSCode 安装 __Remote - SSH__ 扩展后，使用扩展配置 SSH 并进行远程连接，可能会发生 __Bad owner or permissions on C:\\Users\\Administrator/.ssh/config__ 错误，造成无法进行 SSH 远程连接的问题。

原因是由于使用 __Remote - SSH__ 扩展所依赖的 __Remote - SSH: Editing Configuration Files__ 扩展编辑了 __C:\Users\Administrator\.ssh\config__ 文件后，此文件的权限发生了改变：
![image.png](https://b3logfile.com/file/2019/09/image-2fd80730.png)

如上图所示，编辑了 __%USER_HOME%\\.ssh\config__ 文件后，不但在 VSCode 中由于配置文件权限问题而无法进行 SSH 远程连接，就连使用系统的 __PowerShell__ 进行 SSH 连接时也会报此错误，而把此配置文件删除后，使用  __PowerShell__ 即可正常进行远程连接。但 VSCode 的 SSH 连接又依赖此配置文件，所以就产生了冲突，要么只有 __PowerShell__ 能用，要么就都不能用。

实测 Windows Server 2019 和 Windows 10 企业版 1903 中都存在此问题，不知道是系统的原因、VSCode 的原因还是人为操作问题。

## 解决方法

1. 在 GitHub 上下载 [__openssh-portable__](https://github.com/PowerShell/openssh-portable) 项目，其 Git 命令如下：
   
   ```shell script
   git clone https://github.com/PowerShell/openssh-portable.git
   ```
2. 下载完成后进入 __openssh-portable__ 项目中的 [`contrib\win32\openssh`](https://github.com/PowerShell/openssh-portable/tree/latestw_all/contrib/win32/openssh) 目录，在此目录中打开 PowerShell 命令行，执行以下命令：
   
   ```shell script
   .\FixUserFilePermissions.ps1 -Confirm:$false
   ```
   
   - 执行此命令时若提示 `无法加载文件 FixUserFil ePermissions.ps1，因为在此系统上禁止运行脚本` 错误，则先执行以下命令，然后输入 `Y` 回车确认后再重新执行（执行完毕后可以再执行以下命令输入 `N` 恢复默认配置）：
     ```
     Set-ExecutionPolicy RemoteSigned
     ```
3. 操作完成后，在 VSCode 中编辑 __C:\Users\Administrator\.ssh\config__ 文件将不会影响此文件的权限，在 VSCode 和 PowerShell 中均可正常进行 SSH 远程连接：
   
   - 在 VSCode 中通过 Remote - SSH 进行 SSH 远程连接：
     ![image.png](https://b3logfile.com/file/2019/09/image-c923ced8.png)
   - 在 PowerShell 中进行 SSH 远程连接：
     ![93310FA6D4F64FA7BF7BEBE7357A79E6.jpeg](https://b3logfile.com/file/2019/09/93310FA6D4F64FA7BF7BEBE7357A79E6-cf86116a.jpeg)

## 相关连接

> [https://stackoverflow.com/questions/49926386/openssh-windows-bad-owner-or-permissions](https://stackoverflow.com/questions/49926386/openssh-windows-bad-owner-or-permissions)
> [https://github.com/PowerShell/openssh-portable](https://github.com/PowerShell/openssh-portable)
> [https:/go.microsoft.com/fwlink/?LinkID=135170](https:/go.microsoft.com/fwlink/?LinkID=135170)

