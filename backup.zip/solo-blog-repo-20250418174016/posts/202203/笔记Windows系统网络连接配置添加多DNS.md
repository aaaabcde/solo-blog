title: 【笔记】Windows 系统网络连接配置添加多 DNS
date: '2022-03-03 11:29:21'
updated: '2022-04-13 12:49:00'
tags: [Windows, IP, DNS]
permalink: /windows-tcp-ip-multiple-dns
---
![image.png](https://b3logfile.com/file/2022/03/image-9b1ca896.png)

1. 打开 **控制面板**，进入 **控制面板\网络和 Internet\网络连接**；
2. 在网络连接列表中选中要配置的网络连接；
3. 点击 <kbd>更改此连接的设置</kbd> 按钮打开网络连接属性窗口；
4. 在属性窗口双击要配置的 **TCP/IP** 协议，打开网络协议属性窗口；
5. 在网络协议属性窗口点击 <kbd>高级</kbd> 按钮打开 **高级 TCP/IP 设置**；
6. 在高级 TCP/IP 设置窗口选中 **DNS** 标签页；
7. 点击 **DNS 服务器地址** 列表下面的 <kbd>添加</kbd> 按钮；
8. 在弹出的 **DNS 服务器** 输入框中输入要添加的 DNS 服务器地址，点击 <kbd>添加</kbd> 按钮；
9. 点击 <kbd>确定</kbd> 按钮保存高级 TCP/IP 设置。

