title: Ubuntu/CentOS 安装配置 GitLab 命令行操作步骤
date: '2019-09-09 09:39:01'
updated: '2022-04-01 09:22:48'
tags: [Gitlab, 命令行, Linux, 安装]
permalink: /ubuntu-centos-linux-install-gitlab
---
## 特别说明

如果要在 WSL （适用于 Linux 的 Windows 子系统）中安装 GitLab，则必须使用内部版本号为 18917 或更高版本的 Windows 系统，并将 WSL 升级到 WSL 2（也支持安装 Docker）。

> 参考链接：[https://docs.microsoft.com/zh-cn/windows/wsl/wsl2-install](https://docs.microsoft.com/zh-cn/windows/wsl/wsl2-install)

在以下命令中，以安装社区版为例，如果使用企业版则需将 `gitlab-ce` 替换为 `gitlab-ee`。

## 安装和配置必要的依赖项

* Ubuntu
  
  ```shell script
  sudo apt-get update
  ```
  
  ```shell script
  sudo apt-get install -y curl openssh-server ca-certificates
  ```
* CentOS
  
  ```shell script
  sudo yum install -y curl policycoreutils-python openssh-server
  sudo systemctl enable sshd
  sudo systemctl start sshd
  sudo firewall-cmd --permanent --add-service=http
  sudo firewall-cmd --permanent --add-service=https
  sudo systemctl reload firewalld
  ```

### CentOS 修改 IP 地址

```bash
vim /etc/sysconfig/network-scripts/ifcfg-eth0
```

* 按 i 编辑以下内容：
  
  ```bash
  IPADDR=IP 地址
  GETEWAY=网关
  NETMASK=子网掩码
  DNS1=主 DNS，内网留空
  DNS2=备 DNS，内网留空
  ```
  
  按 esc 退出编辑状态，输入 `:wq` 回车保存并退出 vim
* 重启网络服务：
  
  ```bash
  systemctl restart network.service
  ```
* 查看网络服务状态：
  
  ```bash
  systemctl status network.service
  ```
* 查看网卡 IP 配置：
  
  ```bash
  ip addr
  ```

### 安装 Postfix 用于发送通知邮件

* Ubuntu
  
  ```shell script
  sudo apt-get install -y postfix
  ```
* CentOS
  
  ```shell script
  sudo yum install postfix
  sudo systemctl enable postfix
  sudo systemctl start postfix
  ```

安装 `Postfix` 过程中选择 `Internet Site` 并回车，然后输入要发送邮件的邮箱地址域。
如发送方邮件地址为 `username@example.com`，则输入 `example.com`，然后回车。

## 添加 GitLab 包存储库并安装

### 添加 GitLab 包存储库

* Ubuntu
  
  ```shell script
  curl https://packages.gitlab.com/install/repositories/gitlab/gitlab-ce/script.deb.sh | sudo bash
  ```
* CentOS
  
  ```shell script
  curl https://packages.gitlab.com/install/repositories/gitlab/gitlab-ce/script.rpm.sh | sudo bash
  ```

### 安装 GitLab

* Ubuntu
  
  ```shell script
  sudo apt-get install gitlab-ce
  ```
* CentOS
  
  ```shell script
  sudo yum install -y gitlab-ce
  ```

## 配置 GitLab

安装完成后，执行以下命令编辑配置文件中的访问地址 `external_url` 和邮箱等设置：

```shell script
sudo vim /etc/gitlab/gitlab.rb
```

如：

```
external_url 'http://192.168.1.6:666'
```

## 启动 GitLab

配置完成后，执行以下命令启动 GitLab 实例：

```shell script
sudo gitlab-ctl reconfigure
```

启用 GitLab 开机自动启动：

```shell script
sudo systemctl enable gitlab-runsvdir.service
```

禁用 GitLab 开机自动启动：

```shell script
sudo systemctl disable gitlab-runsvdir.service
```

## 登录

使用配置好的 `external_url` 地址进行访问，第一次访问将被重定向到一个密码重置页面。密码重置完成后将被重定向到登录页面，使用默认管理帐户的用户名 `root` 及刚刚重置的密码进行登录。

## 更新版本

### 备份配置（可选）

```shell script
sudo gitlab-rake gitlab:backup:create STRATEGY=copy
```

### 更新 GitLab

* Ubuntu
  
  ```shell script
  sudo apt-get update && sudo apt-get install gitlab-ce
  ```
* CentOS
  
  ```shell script
  sudo yum install -y gitlab-ce
  ```
  
  - CentOS 下配置阿里云 yum 源，使用 `yum update` 命令会同时更新 GitLab CE。

## 跨版本升级 GitLab

1. 备份：
   
   ```bash
   sudo gitlab-rake gitlab:backup:create STRATEGY=copy
   ```
2. 停止组件：
   
   ```bash
   gitlab-ctl stop unicorn
   gitlab-ctl stop sidekiq
   gitlab-ctl stop nginx
   ```
3. 依次安装（从 v1 升级到 v2）：
   
   ```bash
   # v1 的最后一个版本
   rpm -Uvh gitlab-ce-1.9.*.x86_64.rpm
   # v2 的第一个版本
   rpm -Uvh gitlab-ce-2.0.*.x86_64.rpm
   # v2 的最后一个版本
   rpm -Uvh gitlab-ce-2.1.*.x86_64.rpm
   ```
4. 查看版本：
   
   ```bash
   cat /opt/gitlab/embedded/service/gitlab-rails/VERSION
   ```
5. 重启服务：
   
   ```bash
   gitlab-ctl restart
   ```

## 其他常用命令

### 停止

```shell script
sudo gitlab-ctl stop
```

### 启动

```shell script
sudo gitlab-ctl start
```

### 重启

```shell script
sudo gitlab-ctl restart
```

### 状态

```shell script
sudo gitlab-ctl status
```

### 日志

```shell script
sudo gitlab-ctl tail
```

## 相关链接

> [https://about.gitlab.com/install/#ubuntu](https://about.gitlab.com/install/#ubuntu)
> [https://about.gitlab.com/update/#ubuntu](https://about.gitlab.com/update/#ubuntu)
> [https://about.gitlab.com/install/#centos-7](https://about.gitlab.com/install/#centos-7)
> [https://about.gitlab.com/update/#centos-7](https://about.gitlab.com/update/#centos-7)

