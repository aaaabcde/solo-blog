title: JetBrains 系列 IDE 实用插件
date: '2022-09-24 11:13:31'
updated: '2022-09-24 11:13:45'
tags: [DataURL, Emoji, Git, GoLand]
permalink: /jetbrains-ide-plugins
---
### 基础插件

* [Chinese (Simplified) Language Pack](https://plugins.jetbrains.com/plugin/13710-chinese-simplified-language-pack----/) - 简体中文语言包

### 辅助工具

* [GitHub Copilot](https://plugins.jetbrains.com/plugin/17718-github-copilot) - AI 自动编码辅助
* [Translation](https://plugins.jetbrains.com/plugin/8579-translation) - 语言翻译
* [Statistic](https://plugins.jetbrains.com/plugin/4509-statistic) - 代码统计
* [Code Screenshots](https://plugins.jetbrains.com/plugin/9406-code-screenshots) - 代码截图

### Git 相关插件

* [GitToolBox](https://plugins.jetbrains.com/plugin/7499-gittoolbox) - Git 工具箱
* [Gitmoji Plus: Commit Button](https://plugins.jetbrains.com/plugin/12383-gitmoji-plus-commit-button) - 提交消息的 Emoji 表情符号快捷选择插件
* [.ignore](https://plugins.jetbrains.com/plugin/7495--ignore) - 版本控制器忽略配置工具

### 字符串相关插件

* [String Manipulation](https://plugins.jetbrains.com/plugin/2162-string-manipulation) - 字符串处理工具，如拼写格式转换、编码解码等
* [Randomness](https://plugins.jetbrains.com/plugin/9836-randomness) - 插入随机数、字符串和 UUID
* [Base64 Helper](https://plugins.jetbrains.com/plugin/7372-base64-helper) - 字符串 Base64 编解码工具
* [Base64 image encoder](https://plugins.jetbrains.com/plugin/8263-base64-image-encoder) - 图片转 Base64 DataURL 工具

### 文件相关插件

* [Ini](https://plugins.jetbrains.com/plugin/6981-ini) - ini 配置文件代码高亮、语法检查等工具
* [CSV](https://plugins.jetbrains.com/plugin/10037-csv) - CSV/TSV/PSV 文件代码高亮、语法检查等工具
* [Batch Scripts Support](https://plugins.jetbrains.com/plugin/265-batch-scripts-support) - Windows 系统批处理脚本支持工具

### 代码视图相关插件

* [CodeGlance Pro](https://plugins.jetbrains.com/plugin/18824-codeglance-pro) - 代码侧边小地图
* [Indent Rainbow](https://plugins.jetbrains.com/plugin/13308-indent-rainbow) - 代码缩进着色
* [Rainbow Brackets](https://plugins.jetbrains.com/plugin/10080-rainbow-brackets) - 代码括号着色

