title: Git 项目成员数量、提交次数、代码行数信息统计命令
date: '2022-04-13 18:57:05'
updated: '2022-04-13 18:58:34'
tags: [Git, Linux, 命令行, 终端]
permalink: /git-code-user-commit-line-count-stats
---
![](https://b3logfile.com/bing/20191127.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 1. 统计项目成员数量

```shell
printf "\n1. 项目成员数量："; git log --pretty='%aN' | sort -u | wc -l
```

- 打印结果：
  
  ```shell
  1. 项目成员数量：3
  ```

## 2. 按用户名统计代码提交次数

```shell
printf "\n\n2. 按用户名统计代码提交次数：\n\n"
printf "%10s  %s\n" "次数" "用户名"
git log --pretty='%aN' | sort | uniq -c | sort -k1 -n -r | head -n 5
printf "\n%10s" "合计";
printf "\n%5s" ""; git log --oneline | wc -l
```

- 打印结果：
  
  ```shell
  2. 按用户名统计代码提交次数：
  
    次数  用户名
     50 zhangsan
     20 lisi
     12 wangwu
  
    合计
     82
  ```

## 3. 按用户名统计代码提交行数

```shell
printf "\n3. 按用户名统计代码提交行数：\n\n"
printf "%25s +s = +s - %18s\n" "用户名" "总行数" "添加行数" "删除行数"
git log --format='%aN' | sort -u -r | while read name; do printf "%25s" "$name"; \
git log --author="$name" --pretty=tformat: --numstat | \
awk '{ add += $1; subs += $2; loc += $1 - $2 } END { printf "%15s %15s %15s \n", loc, add, subs }' \
-; done

printf "\n%25s   " "总计："; git log --pretty=tformat: --numstat | \
awk '{ add += $1; subs += $2; loc += $1 - $2 } END { printf "%15s %15s %15s \n", loc, add, subs }'
```

- 打印结果：
  
  ```shell
  3. 按用户名统计代码提交行数：
  
                用户名            总行数 =         添加行数 -       删除行数
                zhangsan          17589           20825            3236
                    lisi           1541            2125             584
                  wangwu            895            1018             123
  
                总计：             20025           23968            3943
  ```

## 完整脚本

脚本文件名为 `git-code-user-commit-stats.sh`，请在 unix 终端或 git-bash 中打开：

```shell
#!/bin/sh

# 请在 unix 终端或 git-bash 中运行此脚本

printf "\n1. 项目成员数量："; git log --pretty='%aN' | sort -u | wc -l

printf "\n\n2. 按用户名统计代码提交次数：\n\n"
printf "%10s  %s\n" "次数" "用户名"
git log --pretty='%aN' | sort | uniq -c | sort -k1 -n -r | head -n 5
printf "\n%10s" "合计";
printf "\n%5s" ""; git log --oneline | wc -l

printf "\n3. 按用户名统计代码提交行数：\n\n"
printf "%25s +s = +s - %18s\n" "用户名" "总行数" "添加行数" "删除行数"
git log --format='%aN' | sort -u -r | while read name; do printf "%25s" "$name"; \
git log --author="$name" --pretty=tformat: --numstat | \
awk '{ add += $1; subs += $2; loc += $1 - $2 } END { printf "%15s %15s %15s \n", loc, add, subs }' \
-; done

printf "\n%25s   " "总计："; git log --pretty=tformat: --numstat | \
awk '{ add += $1; subs += $2; loc += $1 - $2 } END { printf "%15s %15s %15s \n", loc, add, subs }'

echo ""
# shellcheck disable=SC2162
read -n 1 -p "请按任意键继续..."
```

