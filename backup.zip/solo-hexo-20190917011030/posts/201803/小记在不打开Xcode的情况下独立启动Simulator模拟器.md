title: 小记：在不打开 Xcode 的情况下独立启动 Simulator 模拟器
date: '2018-03-26 21:07:25'
updated: '2019-04-16 23:56:03'
tags: [mac, Xcode]
permalink: /not-open-xcode-standalone-simulator
---
![不打开 Xcode，独立启动 Simulator](//res.zixizixi.cn/image/illust/standalone-simulator.jpg.coverimg)

## 1. 显示 Xcode 包内容
> ![显示 Xcode 包内容](//res.zixizixi.cn/image/illust/xcode1.jpg.zximg)

第一步：进入 <kbd>应用程序</kbd> 找到 `Xcode`，右键选择 `显示包内容`；

## 2. 进入 Applications 文件夹
> ![进入 Applications 文件夹](//res.zixizixi.cn/image/illust/xcode2.jpg.zximg)

第二步：进入 `/Applications/Xcode.app/Contents/Developer/Applications` 目录；

## 3. 拷贝 Simulator.app 到应用程序
> ![拷贝 Simulator.app 到应用程序](//res.zixizixi.cn/image/illust/xcode3.jpg.zximg)

第三步：选中 <kbd>Simulator.app</kbd>，拷贝此文件或选择`制作替身`（快捷方式）到 `Xcode.app` 所在的 `Applications`（应用程序） 目录。

然后就可以像其他应用程序一样可以在 `Launchpad`（启动台）或程序坞中启动模拟器了。

> ![程序坞快捷图标](//res.zixizixi.cn/5e610c002109402d9191b2b35f169c46.jpg.zximg "快捷图标")