title: 从 JDK11 中提取 JRE
date: '2021-01-09 19:30:38'
updated: '2021-01-09 19:31:03'
tags: [Java]
permalink: /jlink-jdk11-extract-jre11
---
![](https://b3logfile.com/bing/20171205.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

之前开发项目一直都是用 Java8，开发环境用 JDK8，生成环境部署运行时用 JRE8。Oracle 官方提供 JRE8 的安装包，安装 JRE 也很方便。

最近开发 Kotlin 项目开始用 Java11，然而现在 Oracle 官方已经不提供 JRE11 的安装包了，但是可以通过 `jlink` 命令自行提取 JRE。

JDK11 的安装包有 150MB 左右，而完全提取的 JRE 打包成 rar 压缩文件后只有 40MB左右，足足小了 100 多 MB，解压后也比安装后的 JDK 占用空间小 120MB 左右。

如果服务器空间足够，用 JDK 还是 JRE 就看自己心情了，但如果服务器空间很紧张，还是很有必要用 JRE 的。

### 提取步骤

#### 首先通过命令行工具进入 JDK11 的安装目录

```
cd C:\java\jdk-11.0.9
```

#### 然后通过 jlink 命令从 JDK 中完整提取 JRE

```bash
bin\jlink.exe --module-path jmods --add-modules java.base,jdk.internal.le,java.compiler,jdk.internal.opt,java.datatransfer,jdk.internal.vm.ci,java.desktop,jdk.internal.vm.compiler,java.instrument,jdk.internal.vm.compiler.management,java.logging,jdk.jartool,java.management,jdk.javadoc,java.management.rmi,jdk.jcmd,java.naming,jdk.jconsole,java.net.http,jdk.jdeps,java.prefs,jdk.jdi,java.rmi,jdk.jdwp.agent,java.scripting,jdk.jfr,java.se,jdk.jlink,java.security.jgss,jdk.jshell,java.security.sasl,jdk.jsobject,java.smartcardio,jdk.jstatd,java.sql,jdk.localedata,java.sql.rowset,jdk.management,java.transaction.xa,jdk.management.agent,java.xml,jdk.management.jfr,java.xml.crypto,jdk.naming.dns,jdk.accessibility,jdk.naming.ldap,jdk.aot,jdk.naming.rmi,jdk.attach,jdk.net,jdk.charsets,jdk.pack,jdk.compiler,jdk.rmic,jdk.crypto.cryptoki,jdk.scripting.nashorn,jdk.crypto.ec,jdk.scripting.nashorn.shell,jdk.crypto.mscapi,jdk.sctp,jdk.dynalink,jdk.security.auth,jdk.editpad,jdk.security.jgss,jdk.hotspot.agent,jdk.unsupported,jdk.httpserver,jdk.unsupported.desktop,jdk.internal.ed,jdk.xml.dom,jdk.internal.jvmstat,jdk.zipfs --output jre
```

#### 提取说明

上述命令从 `--add-modules ` 后面到 `--output` 之前的部分全部是 Java11 的内置模块，多个模块名之间通过半角逗号 `,` 分隔，可按需删减不需要的模块，但为避免运行出错，一般不建议删减模块，除非服务器空间非常有限。

- `output` 参数用于指定提取 JRE 时的输出目录，可自定义为其他路径。提取成功后的 JRE 目录如下所示：
  ![JRE11](https://b3logfile.com/file/2021/01/image-ed74928c.png)
- JRE11 占用 158MB 磁盘空间：
  ![158MB](https://b3logfile.com/file/2021/01/image-3eb01cd9.png)
- 而 JDK11 占用 279MB 磁盘空间：
  ![279MB](https://b3logfile.com/file/2021/01/image-e316c589.png)
- 打包压缩后的 JRE11 仅占用 40.2MB 的磁盘空间：
  ![40.2MB](https://b3logfile.com/file/2021/01/image-6845e6f7.png)

