title: Go 语言面向对象编程特性的实现
date: '2023-03-05 23:54:36'
updated: '2023-03-05 23:54:36'
tags: [Go, Golang, OOP]
permalink: /golang-oop
---
![](https://b3logfile.com/bing/20230302.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> 面向对象编程（Object-Oriented Programming, OOP）是一种编程范式，它将现实世界中的对象以及它们的关系作为程序的基本组成部分，并通过封装、继承、多态等机制来实现程序的模块化、灵活性、可重用性和可扩展性。

Go 语言是一门静态类型编程语言，在保持简洁、高效的同时也提供了一些面向对象编程的特性。

下面来分别看一下 `OOP` 的三个主要特性 **封装**、**继承** 和 **多态** 在 Go 语言中的实现。

### 封装

**封装** 是指将 **数据** 和 **操作数据的方法** 放在一起，通过限制对数据的直接访问，保证数据的 **安全性** 和 **一致性**。在 Go 语言中，可以使用 `struct` 来定义一个自定义的数据类型，通过在 `struct` 中定义 **私有变量** 和 **公共方法** 实现封装。

例如，下面定义了一个 `Person` 结构体，其中 `name` 和 `age` 是私有变量，而 `Print` 方法是公共方法：

```go
type Person struct {
    name string
    age  int
}

func (p *Person) Print() {
    fmt.Println("name:", p.name)
    fmt.Println("age:", p.age)
}
```

在这个例子中，`Print` 方法可以访问私有变量 `name` 和 `age`，但是外部程序无法直接访问这些变量。如果要修改这些变量，必须通过方法提供的接口来进行操作。

### 继承

**继承** 是指一个类可以从另一个类中继承 **属性和方法** ，并且可以扩展自己的属性和方法。在 Go 语言中，可以通过 **匿名字段** 实现继承。

例如，下面定义了一个 `Student` 结构体，它继承了 `Person` 结构体：

```go
type Student struct {
    *Person
    grade int
}
```

在这个例子中，`Student` 结构体通过一个匿名的 `Person` 字段来继承了 `Person` 结构体的所有属性和方法。在实际使用中，我们可以通过以下方式来创建一个 `Student` 对象并调用其 `Print` 方法：

```go
s := &Student{
    &Person{"Tom", 20},
    3,
}
s.Print()
```

### 多态

**多态** 是指同一个方法可以 **被不同的对象调用，产生不同的行为**。在 Go 语言中，可以通过 **接口** 实现多态。

例如，下面定义了一个 `Animal` 接口，它包含一个 `Eat` 方法：

```go
type Animal interface {
    Eat()
}
```

然后，下面定义了一个 `Cat` 类型和一个 `Dog` 类型，它们都实现了 `Animal` 接口：

```go
type Cat struct {
}

func (c *Cat) Eat() {
    fmt.Println("Cat is eating.")
}

type Dog struct {
}

func (d *Dog) Eat() {
    fmt.Println("Dog is eating.")
}
```

最后，可以通过 `Animal` 接口来调用这两个类型的 `Eat` 方法，产生不同的行为：

```go
func feed(animal Animal) {
    animal.Eat()
}

func main() {
    cat := &Cat{}
    dog := &Dog{}
    feed(cat)
    feed(dog)
}
```

在这个例子中，我们定义了一个 `feed` 函数，它接受一个 `Animal` 类型的参数，并调用其 `Eat` 方法。在 `main` 函数中，我们创建了一个 `Cat` 对象和一个 `Dog` 对象，并通过 `feed` 函数来调用它们的 `Eat` 方法。由于 `Cat` 和 `Dog` 类型都实现了 `Animal` 接口，因此 `feed` 函数可以接受它们作为参数，并且在调用其 `Eat` 方法时会产生不同的行为。

综上所述，**封装**、**继承** 和 **多态** 是面向对象编程的三个主要特性，在 Go 语言中都有对应的实现方式：

- **封装** 通过 `struct` 的 **私有变量** 和 **公共方法** 实现；
- **继承** 通过 **匿名字段** 实现；
- **多态** 通过 **接口** 实现。

掌握这些特性可以帮助我们更好地设计和组织程序，并提高程序的 **可维护性** 和 **可扩展性**。

