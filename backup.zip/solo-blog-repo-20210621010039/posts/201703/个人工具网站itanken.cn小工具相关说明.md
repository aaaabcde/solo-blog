title: 个人工具网站 itanken.cn 小工具相关说明
date: '2017-03-12 16:52:41'
updated: '2018-12-27 16:38:44'
tags: [工具, iTanken]
permalink: /articles/2017/03/11/1489227107307.html
---
# [itanken.cn](https://www.itanken.cn) 站内相关工具说明

![首页](//res.zixizixi.cn/2ea0f1b85b6f451f99603cfa7c93810c.jpg.zximg?imageView/2/w/700/q/90 "首页")

由于网站主要是用于个人及面向开发人员的一些开发类工具，所以 UI 还比较粗糙。页面均可自适应显示，适配绝大多数 PC 和移动设备。首页是一个 HTML5 时钟，时钟下面显示详细时间和农历。

点击页面左下角的汉堡按钮，菜单显示的主要就是网站的一些工具：

## 1. [iTime](https://www.itanken.cn/) : 首页
> ![iTime](//res.zixizixi.cn/file/2017/3/9b2a07af52ea4d45a9c8cd9f28a233ce-201703122.37.56.jpg.zximg?imageView/2/w/700/q/90 "iTime") 
> 
> 首页显示效果。如果当天是节日，会在农历之后显示节日信息。

## 2. [jsonx](https://www.itanken.cn/iTools/jsonx/) : Json 和 Xml 互转工具（网络）
> ![jsonx](//res.zixizixi.cn/file/2017/3/c0b6e36468864901aa9d5ad2feba6c7d-201703123.53.04.jpg.zximg?imageView/2/w/700/q/90 "jsonx") 
> 
> 此工具来源于 json.cn ，用于 Json 数据在线解析和格式化，以及 Json 和 Xml 格式之间的相互转换。

## 3. [iQR](https://www.itanken.cn/qr/) : 二维码生成工具
> ![iQR](//res.zixizixi.cn/file/2017/3/42e2269b1c3f47b2adc6684fb84b6553-201703124.05.52.jpg.zximg?imageView/2/w/700/q/90 "iQR") 
> 
> 二维码生成工具，初指定二维码的内容之外，还可以设置二维码的容错率、大小及图标。可以直接通过地址栏中传值在页面中生成二维码：[https://www.itanken.cn/qr/?data=内容](https://www.itanken.cn/qr/?data=https://zixizixi.cn)

## 4. [iLock](https://www.itanken.cn/apps/lockscreen/) : 安卓一键锁屏
> ![iLock](//res.zixizixi.cn/file/2017/3/52dd70f8726248aeab5c12abaab352e9-201703124.12.37.jpg.zximg?imageView/2/w/700/q/90 "iLock") 
> 
> 页面内介绍：一款追求极致精简的安卓一键锁屏工具，最新版安装包大小仅6.2KB最大程度节省手机空间，无病毒，无广告，并且完全免费，请放心使用。 使用时需在“设置 - 安全 - 设备管理器”中激活“锁屏”（官方下载应用名为“锁屏”，百度和豌豆荚等应用市场下载的应用名为“i锁屏”）。

## 5. [iType](https://www.itanken.cn/games/iType/) : 打字练习游戏（网络）
> ![iType](//res.zixizixi.cn/file/2017/3/1ea45de7af1b4b638e1b0ce6c3fbbc1e-201703124.18.17.jpg.zximg?imageView/2/w/700/q/90 "iType") 
> 
> 一款在线打字练习游戏，自己无聊的时候打发时间用的。

## 6. [iRegex](https://www.itanken.cn/apps/iregex/) : 正则表达式测试工具
> ![iRegex](//res.zixizixi.cn/file/2017/3/1049e6f89e664f7d903e111827ba97c8-201703124.21.10.jpg.zximg?imageView/2/w/700/q/90 "iRegex") 
> 
> 页面内介绍：一款由Java语言开发的正则表达式测试工具，有 find()、split()、matches()、lookingAt()、replaceAll()、replaceFirst() 6种方法供测试正则表达式使用。 （此软件需要Java运行时环境，可在Windows、Linux、OS X等安装了 Java Runtime 环境的机器上使用）。

## 7. [iSource](http://www.itanken.cn/pan/) : 百度云资源搜索工具
> ![iSource-1](//res.zixizixi.cn/file/2017/3/de3d0e7a39db4de5be0c106b0ef47cc7-201703124.24.12.jpg.zximg?imageView/2/w/700/q/90 "iSource-1") 
> 
> ![iSource-2](//res.zixizixi.cn/file/2017/3/d3c47b9c61214427b31824396cbc2830-201703124.28.58.jpg.zximg?imageView/2/w/700/q/90 "iSource-2") 
> 
> 一款基于谷歌自定义搜索的百度网盘资源搜索引擎。

## 8. [iRenju](http://www.itanken.cn/games/iRenju/) : 五子棋游戏（网络）
> 
> 同样是自己在无聊的时候打发时间玩的游戏。

## 9. [iApk](http://www.itanken.cn/iTools/AppUpload/) : 上传安卓 apk 文件获取应用信息工具
> ![iApk](//res.zixizixi.cn/file/2017/3/c5ca04eabc03408abed00e23c4d8bd8d-201703124.36.28.jpg.zximg?imageView/2/w/700/q/90 "iApk") 
> 
> 页面内介绍：此工具用于上传安卓apk安装包后获取应用的名称、包名、版本、图标信息。[查看更多信息](http://www.zixizixi.com/2016/11/03/javagetapkinfo/)
> #### 说明信息：
> 1.  只能上传安卓应用 .apk 格式的文件；
> 2.  上传的应用文件大小最大不能超过 3M；
> 3.  每个 IP 每天最多只能上传 10 次，次日凌晨自动解封；
> 4.  此工具目前只在 Windows 系统下的 IE、Edge 和 Chrome 浏览器以及 macOS 下的 Safari和 Chrome 浏览器下调试通过，不能保证在其他系统和浏览器中可以正常使用。

## 10. [iTel](http://www.itanken.cn/iTools/GSD/) : 手机号码归属地查询工具
> ![iTel](//res.zixizixi.cn/file/2017/3/76ffcfc6990e420c9ae119c1d890bb5f-201703124.37.46.jpg.zximg?imageView/2/w/700/q/90 "iTel") 
> 
> 一个简单的手机号码归属地在线查询工具。

## 11. [iSMap](http://www.itanken.cn/sitemap.html) : 站点地图
> ![iSMap](//res.zixizixi.cn/file/2017/3/c84699d5abba409a8b7293218dc7da73-201703124.43.10.jpg.zximg?imageView/2/w/700/q/90 "iSMap")
> 
> itanken.cn 站内基本所有的页面链接都在这里，主要是为搜索引擎提供。

## 12. [Exit](#b3_solo_h2_12) : 退出
> 
> 退出网站或者后退，在浏览器中可用。

--- 
