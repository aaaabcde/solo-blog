title: Windows 系统打印机相关操作命令
date: '2022-12-08 14:24:22'
updated: '2022-12-08 20:47:14'
tags: [Windows, 命令行, 打印, PowerShell]
permalink: /windows-printer-printui-wmic-powershell
---
## 通过 printui 管理打印机

打印机 GUI 工具，可以通过此命令弹出打印队列窗口。

<details>
<summary>用法用例</summary>

```shell
用法: rundll32 printui.dll,PrintUIEntry [options] [@commandfile]
   /a[file] 二进制文件名
   /b[name] 基本打印机名
   /c[name] 如果操作在远程机器上，unc 机器名
   /dl 删除本地打印机
   /dn 删除网络打印机连接
   /dd 删除打印机驱动程序
   /e 显示打印首选项
   /f[file] inf 文件或输出文件
   /F[file] 使用 /f 指定的 INF 文件可能依赖的 INF 文件的位置
   /ga 添加每个机器打印机连接(用户登录时此连接将传播到用户)
   /ge 枚举每个机器打印机连接
   /gd 删除每个机器打印机连接(用户登录时此连接将被删除)
   /h[arch] 驱动程序体系结构，为下列之一: x86 或 x64 或 Itanium 
   /ia 用 INF 文件安装打印机驱动程序
   /id 用添加打印机驱动程序向导安装打印机驱动程序
   /if 用 INF 文件安装打印机
   /ii 用带 INF 文件的添加打印机向导安装打印机
   /il 用添加打印机向导安装打印机
   /im 使用添加打印机向导安装打印机(跳过网络列出的打印机)
   /in 添加网络打印机连接
   /ip 使用网络打印机安装向导安装打印机
   /j[provider] 打印提供程序名称
   /k 安装打印机时将测试页打印到指定打印机，不能与命令组合使用
   /l[path] 打印机驱动程序源路径
   /m[model] 打印机驱动程序型号名称
   /n[name] 打印机名称
   /o 显示打印机队列视图
   /p 显示打印机属性
   /q 安静模式，不显示错误消息
   /r[port] 端口名称
   /s 显示服务器属性
   /Ss 将打印机设置存储到文件
   /Sr 从文件还原打印机设置
   存储或还原必须放在命令末尾的打印机设置选项标志:
   2  PRINTER_INFO_2
   7  PRINTER_INFO_7
   c  颜色配置文件
   d  PrinterData
   s  安全描述符
   g  全局 DevMode
   m  最低设置
   u  用户 DevMode
   r  解决名称冲突
   f  强制使用名称
   p  解析端口
   i  驱动程序名称冲突
   /u 使用现有打印机驱动程序(如果已安装)
   /t[#] 起始的从零开始的索引页
   /v[version] 驱动程序版本，为下列之一:“类型 2 - 内核模式”或“类型 3 - 用户模式”
   /w 如果在 inf 中找不到指定的驱动程序，则提示用户找一个驱动程序
   /y 将打印机设置为默认打印机
   /Xg 获取打印机设置
   /Xs 设置打印机设置
   /z 不自动共享此打印机
   /Y 不自动生成打印机名称
   /K 更改 /h 的含义，使其接受 2、3、4 (分别代表 x86、x64 或 Itanium)，并更改 /v 的含义，使其接受 3 (代表“类型 3 - 用户模式”)
   /Z 共享此打印机，只能与 /if 选项一起使用
   /? 提供此消息的帮助
   @[file] 命令行参数文件
   /Mw[message] 提交命令之前显示警告消息
   /Mq[message] 提交命令之前显示确认消息
   /W[flags] 指定向导(用于 APW 和 APDW)的标志和开关
   r  使向导可以从上一页重新启动
   /G[flags] 指定全局标志和开关
   w  禁止显示安装驱动程序警告 UI (超安静模式)
   /R 强制使用所选驱动程序替换现有驱动程序

例如:
   运行服务器属性: 
rundll32 printui.dll,PrintUIEntry /s /t1 /c\\machine
   运行打印机属性: 
rundll32 printui.dll,PrintUIEntry /p /n\\machine\printer
   本地运行添加打印机向导: 
rundll32 printui.dll,PrintUIEntry /il 
   在 \\machine: 
rundll32 printui.dll,PrintUIEntry /im /c\\machine 上运行添加打印机向导
   运行队列查看: 
rundll32 printui.dll,PrintUIEntry /o /n\\machine\printer
   运行 INF 安装: 
rundll32 printui.dll,PrintUIEntry /if /b "Test Printer" /f c:\infpath\infFile.inf /r "lpt1:" /m "Brother DCP-128C"
   运行 INF 安装(具有 INF 依赖关系)。在此示例中，prnbr002.inf 依赖于 ntprint.inf
rundll32 printui.dll, PrintUIEntry /ia /m "Brother DCP-128C" /K /h x64 /v 3 /f "c:\infpath\prnbr002.inf" /F "c:\infpath\ntprint.inf"
   使用 INF 运行添加打印机向导: 
rundll32 printui.dll,PrintUIEntry /ii /f c:\infpath\infFile.inf
   使用内置打印机驱动程序添加打印机: 
rundll32 printui.dll,PrintUIEntry /if /b "Test Printer" /r "lpt1:" /m "Brother DCP-128C"
   添加每个机器打印机连接(用户登录时此连接将传播到用户): 
rundll32 printui.dll,PrintUIEntry /ga /c\\machine /n\\machine\printer /j"LanMan Print Services"
   删除每个机器打印机连接(用户登录时此连接将被删除): 
rundll32 printui.dll,PrintUIEntry /gd /c\\machine /n\\machine\printer
   枚举每个机器打印机连接: 
rundll32 printui.dll,PrintUIEntry /ge /c\\machine
   使用 INF 添加打印机驱动程序: 
rundll32 printui.dll,PrintUIEntry /ia /c\\machine /m "Brother DCP-128C" /h "x86" /v "Type 3 - User Mode" /f c:\infpath\infFile.inf
   使用 INF 添加打印机驱动程序: 
rundll32 printui.dll,PrintUIEntry /ia /K /c\\machine /m "Brother DCP-128C" /h "x86" /v 3
   添加内置打印机驱动程序: 
rundll32 printui.dll,PrintUIEntry /ia /c\\machine /m "Brother DCP-128C" /h "Intel" /v "Type 3 - Kernel Mode"
   删除打印机驱动程序: 
rundll32 printui.dll,PrintUIEntry /dd /c\\machine /m "Brother DCP-128C" /h "x86" /v "Type 3 - User Mode"
   删除打印机驱动程序: 
rundll32 printui.dll,PrintUIEntry /dd /K /c\\machine /m "Brother DCP-128C" /h "x86" /v 3
   将打印机设置为默认打印机: 
rundll32 printui.dll,PrintUIEntry /y /n "printer"
   设置打印机注解: 
rundll32 printui.dll,PrintUIEntry /Xs /n  "printer" comment "My Cool Printer"
   取得打印机设置: 
rundll32 printui.dll,PrintUIEntry /Xg /n "printer"
   取得文件中的打印机设置保存结果: 
rundll32 printui.dll,PrintUIEntry /f "results.txt" /Xg /n "printer"
   设置打印机设置命令使用:
rundll32 printui.dll,PrintUIEntry /Xs /n "printer" ?
   将所有打印机设置存入一个文件: 
rundll32 printui.dll,PrintUIEntry /Xs /n "printer" ?
   从一个文件还原所有打印机设置: 
rundll32 printui.dll,PrintUIEntry /Sr /n "printer" /a "file.dat"
   将二级打印机信息存入一个文件: 
rundll32 printui.dll,PrintUIEntry /Ss /n "printer" /a "file.dat" 2
   从一个文件还原打印机安全描述符: 
rundll32 printui.dll,PrintUIEntry /Sr /n "printer" /a "file.dat" s
   从一个文件还原打印机全局 devmode 和打印机数据: 
rundll32 printui.dll,PrintUIEntry /Sr /n "printer" /a "file.dat" g d
   从文件最少设置还原并分析端口名: 
rundll32 printui.dll,PrintUIEntry /Sr /n "printer" /a "file.dat" m p
   启用打印机的客户端呈现: 
rundll32 printui.dll,PrintUIEntry /Xs /n"printer" ClientSideRender enabled
   禁用打印机的客户端呈现: 
rundll32 printui.dll,PrintUIEntry /Xs /n"printer" ClientSideRender disabled
```

</details>

### 队列查看

```shell
rundll32 printui.dll,PrintUIEntry /o /n"Microsoft XPS Document Writer"
```

### 设置默认打印机-printui

```shell
rundll32 printui.dll,PrintUIEntry /y /n "Microsoft XPS Document Writer"
```

### 查看打印机属性信息

```shell
rundll32 printui.dll,PrintUIEntry /p /n\\machine\printer
```

## 通过 WMIC 管理打印机

- 参考资料：[https://learn.microsoft.com/zh-cn/windows/win32/cimwin32prov/win32-printer](https://learn.microsoft.com/zh-cn/windows/win32/cimwin32prov/win32-printer)

<details>
<summary>打印机属性</summary>

```ini
# 打印机的名称
Name=Microsoft XPS Document Writer
# 打印机的简短说明
Caption=Microsoft XPS Document Writer
# 系统上打印机的唯一标识符
DeviceID=Microsoft XPS Document Writer
# 打印队列的注释
Comment=26 楼软件部打印机
# 是否为默认打印机
Default=TRUE
# 直接连接到计算机
Local=FALSE
# 是否为网络打印机
Network=TRUE
# 如果为 TRUE，则打印机可以双向打印
EnableBIDI=TRUE
HorizontalResolution=600
VerticalResolution=600
# 打印速率（每分钟的平均页数）打印机可以生成输出。
AveragePagesPerMinute=0
# 打印机功能数组
Capabilities={4,2,3,5}
# 打印机功能数组中对应打印机功能的详细说明
CapabilityDescriptions={"Copies","Color","Duplex","Collate"}
# 打印机支持的纸张类型数组
PaperSizesSupported={7,8,1,22,23,11,1,1,1,1,55,1,1,1,1,1,1,1}
# 打印机支持的纸张大小数组
PrinterPaperNames={"Letter","Legal","Executive","A4","A5","10 号信封","DL 信封","C5 信封","B5 信封","Monarch 信封","B5 (JIS)","B5 (ISO)","A6","双面明信片","明信片","8.5x13","16K",""}
# 当前状态
# 正常  ("OK")
# 错误 ("Error")
# 降级 ("Degraded")
# 未知 ("Unknown")
# 预处理失败 ("Pred Fail")
# 开始 ("Starting")
# 停止 ("Stopping")
# 服务 ("Service")
# 压力 ("Stressed")
# 不恢复 ("NonRecover")
# 没有联络 ("No Contact")
# 失去通信 ("Lost Comm")
Status=Unknown
# 打印机的状态信息
# Other (1) - 其他
# Unknown (2) - 未知
# Idle (3) - 空闲，有关详细信息，请参阅下面的“备注”部分
# Printing (4) - 正在打印
# Warmup (5) - 准备中
# Stopped Printing (6) - 已停止打印
# Offline (7) - 脱机
PrinterStatus=3
# 打印机状态信息
#  1 (0x1) - 其他
#  2 (0x2) - 未知
#  3 (0x3) - 空闲
#  4 (0x4) - 打印
#  5 (0x5) - 热身
#  6 (0x6) - 已停止打印
#  7 - 脱机
#  8 (0x8) - 已暂停
#  9 (0x9) - 错误
# 10 (0xA) - 忙碌
# 11 (0xB) - 不可用
# 12 (0xC) - 等待
# 13 (0xD) - 正在处理
# 14 (0xE) - 初始化
# 15 - 省电
# 16 (0x10) - 挂起删除
# 17 (0x11) - I/O 活动
# 18 (0x12) - 手动送纸
ExtendedPrinterStatus=2
# 打印机错误信息
# Unknown (0) - 未知
# Other (1) - 其他
# No Error (2) - 无错误
# Low Paper (3) - 纸张不足
# No Paper (4) - 缺纸
# Low Toner (5) - 墨粉不足
# No Toner (6) - 无墨粉
# Door Open (7) - 机盖未关
# Jammed (8) - 塞纸
# Offline (9) - 脱机
# Service Requested (10) - 需要维修
# Output Bin Full (11) - 出纸盒已满
DetectedErrorState=0
# 报告标准错误信息
#  0 (0x0) - 未知
#  1 (0x1) - 其他
#  2 (0x2) - 无错误
#  3 (0x3) - 纸张不足
#  4 (0x4) - 缺纸
#  5 (0x5) - 墨粉不足
#  6 (0x6) - 无墨粉
#  7 (0x7) - 机盖未关
#  8 (0x8) - 塞纸
#  9 (0x9) - 需要维修
# 10 (0xA) - 出纸盒已满
# 11 (0xB) - 纸张问题
# 12 (0xC) - 无法打印页面
# 13 (0xD) - 需要用户干预
# 14 (0xE) - 内存不足
# 15 (0xF) - 服务器未知
ExtendedDetectedErrorState=0
```

</details>

### 设置默认打印机-WMIC

```shell
wmic printer where Name='Microsoft XPS Document Writer' call setDefaultPrinter
```

### 获取全部打印机信息

#### 获取全部打印机所有属性信息

```shell
wmic printer get /value
```

<details>
<summary>输出结果</summary>

```shell
Attributes=65
Availability=
AvailableJobSheets=
AveragePagesPerMinute=0
Capabilities={4,2,3,5}
CapabilityDescriptions={"Copies","Color","Duplex","Collate"}
Caption=导出为WPS PDF
CharSetsSupported=
Comment=
ConfigManagerErrorCode=
ConfigManagerUserConfig=
CreationClassName=Win32_Printer
CurrentCapabilities=
CurrentCharSet=
CurrentLanguage=
CurrentMimeType=
CurrentNaturalLanguage=
CurrentPaperType=
Default=FALSE
DefaultCapabilities=
DefaultCopies=
DefaultLanguage=
DefaultMimeType=
DefaultNumberUp=
DefaultPaperType=
DefaultPriority=0
Description=
DetectedErrorState=0
DeviceID=导出为WPS PDF
Direct=FALSE
DoCompleteFirst=FALSE
DriverName=Kingsoft Virtual Printer Driver
EnableBIDI=FALSE
EnableDevQueryPrint=FALSE
ErrorCleared=
ErrorDescription=
ErrorInformation=
ExtendedDetectedErrorState=0
ExtendedPrinterStatus=2
Hidden=FALSE
HorizontalResolution=600
InstallDate=
JobCountSinceLastReset=0
KeepPrintedJobs=FALSE
LanguagesSupported={2}
LastErrorCode=
Local=TRUE
Location=
MarkingTechnology=
MaxCopies=
MaxNumberUp=
MaxSizeSupported=
MimeTypesSupported=
Name=导出为WPS PDF
NaturalLanguagesSupported=
Network=FALSE
PaperSizesSupported={7,7,1,1,8,1,1,21,22,1,23,54,55,1,1,1,1,7,15,11,1,1,1,4,5,6,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,49,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
PaperTypesAvailable=
Parameters=
PNPDeviceID=
PortName=Kingsoft Virtual Printer Port
PowerManagementCapabilities=
PowerManagementSupported=
PrinterPaperNames={"信纸","小号信纸","Tabloid","Ledger","法律专用纸","Statement","Executive","A3","A4","A4 小号","A5","B4 (JIS)","B5 (JIS)","Folio","Quarto","10x14","11x17","便笺","信封 #9","信封 #10","信封 #11","信封 #12","信封 #14","C size sheet","D size sheet","E size sheet","信封 DL","信封 C5","信封 C3","信封 C4","信封 C6","信封 C65","信封 B4","信封 B5","信封 B6","信封","信封 Monarch","6 3/4 信封","美国标准 Fanfold","德国标准 Fanfold","德国法律专用纸 Fanfold","B4 (ISO)","日式明信片","9x11","10x11","15x11","信封邀请函","特大信纸","特大法律专用纸","Tabloid 特大","A4 特大","信纸横向","A4 横向","特大信纸横向","Super A","Super B","信纸加大","A4 加大","A5 横向","B5 (JIS) 横向","A3 特大","A5 特大","B5 (ISO) 特大","A2","A3 横向","A3 特大横向","日式往返明信片","A6","日式信封 Kaku #2","日式信封 Kaku #3","日式信封 Chou #3","日式信封 Chou #4","信纸旋转","A3 旋转","A4 旋转","A5 旋转","B4 (JIS) 旋转","B5 (JIS) 旋转","日式明信片旋转","双层日式明信片旋转","A6 旋转","日式信封 Kaku #2 旋转","日式信封 Kaku #3 旋转","日式信封 Chou #3 旋转","日式信封 Chou #4 旋转","B6 (JIS)","B6 (JIS) 旋转","12x11","日式信封 You #4","日式信封 You #4 旋转","PRC 16K","PRC 32K","PRC 32K(Big)","PRC 信封 #1","PRC 信封 #2","PRC 信封 #3","PRC 信封 #4","PRC 信封 #5","PRC 信封 #6","PRC 信封 #7","PRC 信封 #8","PRC 信封 #9","PRC 信封 #10","PRC 16K 旋转","PRC 32K 旋转","PRC 32K(大)旋转","PRC 信封 #1 旋转","PRC 信封 #2 旋转","PRC 信封 #3 旋转","PRC 信封 #4 旋转","PRC 信封 #5 旋转","PRC 信封 #6 旋转","PRC 信封 #7 旋转","PRC 信封 #8 旋转","PRC 信封 #9 旋转","PRC 信封 #10 旋转"}
PrinterState=0
PrinterStatus=3
PrintJobDataType=NT EMF 1.006
PrintProcessor=winprint
Priority=1
Published=FALSE
Queued=TRUE
RawOnly=FALSE
SeparatorFile=
ServerName=
Shared=FALSE
ShareName=
SpoolEnabled=TRUE
StartTime=
Status=Unknown
StatusInfo=
SystemCreationClassName=Win32_ComputerSystem
SystemName=YXKFDA8
TimeOfLastReset=
UntilTime=
VerticalResolution=600
WorkOffline=FALSE


Attributes=580
Availability=
AvailableJobSheets=
AveragePagesPerMinute=0
Capabilities={4,2,5}
CapabilityDescriptions={"Copies","Color","Collate"}
Caption=Microsoft XPS Document Writer
CharSetsSupported=
Comment=
ConfigManagerErrorCode=
ConfigManagerUserConfig=
CreationClassName=Win32_Printer
CurrentCapabilities=
CurrentCharSet=
CurrentLanguage=
CurrentMimeType=
CurrentNaturalLanguage=
CurrentPaperType=
Default=TRUE
DefaultCapabilities=
DefaultCopies=
DefaultLanguage=
DefaultMimeType=
DefaultNumberUp=
DefaultPaperType=
DefaultPriority=0
Description=
DetectedErrorState=0
DeviceID=Microsoft XPS Document Writer
Direct=FALSE
DoCompleteFirst=TRUE
DriverName=Microsoft XPS Document Writer v4
EnableBIDI=FALSE
EnableDevQueryPrint=FALSE
ErrorCleared=
ErrorDescription=
ErrorInformation=
ExtendedDetectedErrorState=0
ExtendedPrinterStatus=2
Hidden=FALSE
HorizontalResolution=600
InstallDate=
JobCountSinceLastReset=0
KeepPrintedJobs=FALSE
LanguagesSupported={48}
LastErrorCode=
Local=TRUE
Location=
MarkingTechnology=
MaxCopies=
MaxNumberUp=
MaxSizeSupported=
MimeTypesSupported=
Name=Microsoft XPS Document Writer
NaturalLanguagesSupported=
Network=FALSE
PaperSizesSupported={7,7,1,1,8,1,1,21,22,1,23,54,55,1,1,1,1,7,15,11,1,1,1,4,5,6,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,49,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
PaperTypesAvailable=
Parameters=
PNPDeviceID=
PortName=PORTPROMPT:
PowerManagementCapabilities=
PowerManagementSupported=
PrinterPaperNames={"Letter","Letter Small","Tabloid","Ledger","Legal","Statement","Executive","A3","A4","A4 Small","A5","B4 (JIS)","B5 (JIS)","Folio","Quarto","10×14","11×17","Note","Envelope #9","Envelope #10","Envelope #11","Envelope #12","Envelope #14","C size sheet","D size sheet","E size sheet","Envelope DL","Envelope C5","Envelope C3","Envelope C4","Envelope C6","Envelope C65","Envelope B4","Envelope B5","Envelope B6","Envelope","Envelope Monarch","6 3/4 Envelope","US Std Fanfold","German Std Fanfold","German Legal Fanfold","B4 (ISO)","Japanese Postcard","9×11","10×11","15×11","Envelope Invite","Letter Extra","Legal Extra","A4 Extra","Letter Transverse","A4 Transverse","Letter Extra Transverse","Super A","Super B","Letter Plus","A4 Plus","A5 Transverse","B5 (JIS) Transverse","A3 Extra","A5 Extra","B5 (ISO) Extra","A2","A3 Transverse","A3 Extra Transverse","Japanese Double Postcard","A6","Japanese Envelope Kaku #2","Japanese Envelope Kaku #3","Japanese Envelope Chou #3","Japanese Envelope Chou #4","Letter Rotated","A3 Rotated","A4 Rotated","A5 Rotated","B4 (JIS) Rotated","B5 (JIS) Rotated","Japanese Postcard Rotated","Double Japan Postcard Rotated","A6 Rotated","Japan Envelope Kaku #2 Rotated","Japan Envelope Kaku #3 Rotated","Japan Envelope Chou #3 Rotated","Japan Envelope Chou #4 Rotated","B6 (JIS)","B6 (JIS) Rotated","12×11","Japan Envelope You #4","Japan Envelope You #4 Rotated","PRC Envelope #1","PRC Envelope #3","PRC Envelope #4","PRC Envelope #5","PRC Envelope #6","PRC Envelope #7","PRC Envelope #8","PRC Envelope #9","PRC Envelope #10","PRC Envelope #1 Rotated","PRC Envelope #3 Rotated","PRC Envelope #4 Rotated","PRC Envelope #5 Rotated","PRC Envelope #6 Rotated","PRC Envelope #7 Rotated","PRC Envelope #8 Rotated","PRC Envelope #9 Rotated","User Defined Size"}
PrinterState=0
PrinterStatus=3
PrintJobDataType=RAW
PrintProcessor=winprint
Priority=1
Published=FALSE
Queued=FALSE
RawOnly=FALSE
SeparatorFile=
ServerName=
Shared=FALSE
ShareName=
SpoolEnabled=TRUE
StartTime=
Status=Unknown
StatusInfo=
SystemCreationClassName=Win32_ComputerSystem
SystemName=YXKFDA8
TimeOfLastReset=
UntilTime=
VerticalResolution=600
WorkOffline=FALSE


Attributes=576
Availability=
AvailableJobSheets=
AveragePagesPerMinute=0
Capabilities={4,2}
CapabilityDescriptions={"Copies","Color"}
Caption=Microsoft Print To PDF
CharSetsSupported=
Comment=
ConfigManagerErrorCode=
ConfigManagerUserConfig=
CreationClassName=Win32_Printer
CurrentCapabilities=
CurrentCharSet=
CurrentLanguage=
CurrentMimeType=
CurrentNaturalLanguage=
CurrentPaperType=
Default=FALSE
DefaultCapabilities=
DefaultCopies=
DefaultLanguage=
DefaultMimeType=
DefaultNumberUp=
DefaultPaperType=
DefaultPriority=0
Description=
DetectedErrorState=0
DeviceID=Microsoft Print To PDF
Direct=FALSE
DoCompleteFirst=TRUE
DriverName=Microsoft Print To PDF
EnableBIDI=FALSE
EnableDevQueryPrint=FALSE
ErrorCleared=
ErrorDescription=
ErrorInformation=
ExtendedDetectedErrorState=0
ExtendedPrinterStatus=2
Hidden=FALSE
HorizontalResolution=600
InstallDate=
JobCountSinceLastReset=0
KeepPrintedJobs=FALSE
LanguagesSupported={48}
LastErrorCode=
Local=TRUE
Location=
MarkingTechnology=
MaxCopies=
MaxNumberUp=
MaxSizeSupported=
MimeTypesSupported=
Name=Microsoft Print To PDF
NaturalLanguagesSupported=
Network=FALSE
PaperSizesSupported={7,1,8,1,1,21,22,23,54,55}
PaperTypesAvailable=
Parameters=
PNPDeviceID=
PortName=PORTPROMPT:
PowerManagementCapabilities=
PowerManagementSupported=
PrinterPaperNames={"Letter","Tabloid","Legal","Statement","Executive","A3","A4","A5","B4 (JIS)","B5 (JIS)"}
PrinterState=0
PrinterStatus=3
PrintJobDataType=RAW
PrintProcessor=winprint
Priority=1
Published=FALSE
Queued=FALSE
RawOnly=FALSE
SeparatorFile=
ServerName=
Shared=FALSE
ShareName=
SpoolEnabled=TRUE
StartTime=
Status=Unknown
StatusInfo=
SystemCreationClassName=Win32_ComputerSystem
SystemName=YXKFDA8
TimeOfLastReset=
UntilTime=
VerticalResolution=600
WorkOffline=FALSE


Attributes=16448
Availability=
AvailableJobSheets=
AveragePagesPerMinute=0
Capabilities={2,3}
CapabilityDescriptions={"Color","Duplex"}
Caption=Fax
CharSetsSupported=
Comment=
ConfigManagerErrorCode=
ConfigManagerUserConfig=
CreationClassName=Win32_Printer
CurrentCapabilities=
CurrentCharSet=
CurrentLanguage=
CurrentMimeType=
CurrentNaturalLanguage=
CurrentPaperType=
Default=FALSE
DefaultCapabilities=
DefaultCopies=
DefaultLanguage=
DefaultMimeType=
DefaultNumberUp=
DefaultPaperType=
DefaultPriority=0
Description=
DetectedErrorState=0
DeviceID=Fax
Direct=FALSE
DoCompleteFirst=FALSE
DriverName=Microsoft Shared Fax Driver
EnableBIDI=FALSE
EnableDevQueryPrint=FALSE
ErrorCleared=
ErrorDescription=
ErrorInformation=
ExtendedDetectedErrorState=0
ExtendedPrinterStatus=2
Hidden=FALSE
HorizontalResolution=200
InstallDate=
JobCountSinceLastReset=0
KeepPrintedJobs=FALSE
LanguagesSupported=
LastErrorCode=
Local=TRUE
Location=
MarkingTechnology=
MaxCopies=
MaxNumberUp=
MaxSizeSupported=
MimeTypesSupported=
Name=Fax
NaturalLanguagesSupported=
Network=FALSE
PaperSizesSupported={7,7,8,1,1,22,1,23,55,1,1,7,15,11,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
PaperTypesAvailable=
Parameters=
PNPDeviceID=
PortName=SHRFAX:
PowerManagementCapabilities=
PowerManagementSupported=
PrinterPaperNames={"信纸","小号信纸","法律专用纸","Statement","Executive","A4","A4 小号","A5","B5 (JIS)","Folio","Quarto","便笺","信封 #9","信封 #10","信封 #11","信封 #12","信封 #14","信封 DL","信封 C5","信封 C6","信封 C65","信封 B5","信封 B6","信封","信封 Monarch","6 3/4 信封","德国标准 Fanfold"," 德国法律专用纸 Fanfold","日式明信片","Reserved48","Reserved49","信纸横向","A4 横向","信纸加大","A4 加大","A5 横向","B5 (JIS) 横向","A5 特大","B5 (ISO) 特大","日式往返明信片","A6","日式信封 Kaku #3","日式信封 Chou #3","日式信封 Chou #4","A5 旋转","日式明信片旋转","双层日式明信片旋转","A6 旋转","日式 信封 Chou #4 旋转","B6 (JIS)","B6 (JIS) 旋转","日式信封 You #4","PRC 16K","PRC 32K","PRC 32K(Big)","PRC 信封 #1","PRC 信封 #2","PRC 信封 #3","PRC 信封 #4","PRC 信封 #5","PRC 信封 #6","PRC 信封 #7","PRC 信封 #8","PRC 32K 旋转","PRC 32K(大)旋转","PRC 信封 #1 旋转","PRC 信封 #2 旋转","PRC 信封 #3 旋转","PRC 信封 #4 旋转","对折纸","Envelope Monarch"}
PrinterState=0
PrinterStatus=3
PrintJobDataType=RAW
PrintProcessor=winprint
Priority=1
Published=FALSE
Queued=FALSE
RawOnly=FALSE
SeparatorFile=
ServerName=
Shared=FALSE
ShareName=
SpoolEnabled=TRUE
StartTime=
Status=Unknown
StatusInfo=
SystemCreationClassName=Win32_ComputerSystem
SystemName=YXKFDA8
TimeOfLastReset=
UntilTime=
VerticalResolution=200
WorkOffline=FALSE
```

</details>

#### 获取全部打印机指定属性信息

```shell
wmic printer get Name,Default,Local,Network,EnableBIDI,HorizontalResolution,VerticalResolution,CapabilityDescriptions,PrinterPaperNames /value
```

<details>
<summary>输出结果</summary>

```shell
CapabilityDescriptions={"Copies","Color","Duplex","Collate"}
Default=FALSE
EnableBIDI=FALSE
HorizontalResolution=600
Local=TRUE
Name=导出为WPS PDF
Network=FALSE
PrinterPaperNames={"信纸","小号信纸","Tabloid","Ledger","法律专用纸","Statement","Executive","A3","A4","A4 小号","A5","B4 (JIS)","B5 (JIS)","Folio","Quarto","10x14","11x17","便笺","信封 #9","信封 #10","信封 #11","信封 #12","信封 #14","C size sheet","D size sheet","E size sheet","信封 DL","信封 C5","信封 C3","信封 C4","信封 C6","信封 C65","信封 B4","信封 B5","信封 B6","信封","信封 Monarch","6 3/4 信封","美国标准 Fanfold","德国标准 Fanfold","德国法律专用纸 Fanfold","B4 (ISO)","日式明信片","9x11","10x11","15x11","信封邀请函","特大信纸","特大法律专用纸","Tabloid 特大","A4 特大","信纸横向","A4 横向","特大信纸横向","Super A","Super B","信纸加大","A4 加大","A5 横向","B5 (JIS) 横向","A3 特大","A5 特大","B5 (ISO) 特大","A2","A3 横向","A3 特大横向","日式往返明信片","A6","日式信封 Kaku #2","日式信封 Kaku #3","日式信封 Chou #3","日式信封 Chou #4","信纸旋转","A3 旋转","A4 旋转","A5 旋转","B4 (JIS) 旋转","B5 (JIS) 旋转","日式明信片旋转","双层日式明信片旋转","A6 旋转","日式信封 Kaku #2 旋转","日式信封 Kaku #3 旋转","日式信封 Chou #3 旋转","日式信封 Chou #4 旋转","B6 (JIS)","B6 (JIS) 旋转","12x11","日式信封 You #4","日式信封 You #4 旋转","PRC 16K","PRC 32K","PRC 32K(Big)","PRC 信封 #1","PRC 信封 #2","PRC 信封 #3","PRC 信封 #4","PRC 信封 #5","PRC 信封 #6","PRC 信封 #7","PRC 信封 #8","PRC 信封 #9","PRC 信封 #10","PRC 16K 旋转","PRC 32K 旋转","PRC 32K(大)旋转","PRC 信封 #1 旋转","PRC 信封 #2 旋转","PRC 信封 #3 旋转","PRC 信封 #4 旋转","PRC 信封 #5 旋转","PRC 信封 #6 旋转","PRC 信封 #7 旋转","PRC 信封 #8 旋转","PRC 信封 #9 旋转","PRC 信封 #10 旋转"}
VerticalResolution=600


CapabilityDescriptions={"Copies","Color","Collate"}
Default=TRUE
EnableBIDI=FALSE
HorizontalResolution=600
Local=TRUE
Name=Microsoft XPS Document Writer
Network=FALSE
PrinterPaperNames={"Letter","Letter Small","Tabloid","Ledger","Legal","Statement","Executive","A3","A4","A4 Small","A5","B4 (JIS)","B5 (JIS)","Folio","Quarto","10×14","11×17","Note","Envelope #9","Envelope #10","Envelope #11","Envelope #12","Envelope #14","C size sheet","D size sheet","E size sheet","Envelope DL","Envelope C5","Envelope C3","Envelope C4","Envelope C6","Envelope C65","Envelope B4","Envelope B5","Envelope B6","Envelope","Envelope Monarch","6 3/4 Envelope","US Std Fanfold","German Std Fanfold","German Legal Fanfold","B4 (ISO)","Japanese Postcard","9×11","10×11","15×11","Envelope Invite","Letter Extra","Legal Extra","A4 Extra","Letter Transverse","A4 Transverse","Letter Extra Transverse","Super A","Super B","Letter Plus","A4 Plus","A5 Transverse","B5 (JIS) Transverse","A3 Extra","A5 Extra","B5 (ISO) Extra","A2","A3 Transverse","A3 Extra Transverse","Japanese Double Postcard","A6","Japanese Envelope Kaku #2","Japanese Envelope Kaku #3","Japanese Envelope Chou #3","Japanese Envelope Chou #4","Letter Rotated","A3 Rotated","A4 Rotated","A5 Rotated","B4 (JIS) Rotated","B5 (JIS) Rotated","Japanese Postcard Rotated","Double Japan Postcard Rotated","A6 Rotated","Japan Envelope Kaku #2 Rotated","Japan Envelope Kaku #3 Rotated","Japan Envelope Chou #3 Rotated","Japan Envelope Chou #4 Rotated","B6 (JIS)","B6 (JIS) Rotated","12×11","Japan Envelope You #4","Japan Envelope You #4 Rotated","PRC Envelope #1","PRC Envelope #3","PRC Envelope #4","PRC Envelope #5","PRC Envelope #6","PRC Envelope #7","PRC Envelope #8","PRC Envelope #9","PRC Envelope #10","PRC Envelope #1 Rotated","PRC Envelope #3 Rotated","PRC Envelope #4 Rotated","PRC Envelope #5 Rotated","PRC Envelope #6 Rotated","PRC Envelope #7 Rotated","PRC Envelope #8 Rotated","PRC Envelope #9 Rotated","User Defined Size"}
VerticalResolution=600


CapabilityDescriptions={"Copies","Color"}
Default=FALSE
EnableBIDI=FALSE
HorizontalResolution=600
Local=TRUE
Name=Microsoft Print To PDF
Network=FALSE
PrinterPaperNames={"Letter","Tabloid","Legal","Statement","Executive","A3","A4","A5","B4 (JIS)","B5 (JIS)"}
VerticalResolution=600


CapabilityDescriptions={"Color","Duplex"}
Default=FALSE
EnableBIDI=FALSE
HorizontalResolution=200
Local=TRUE
Name=Fax
Network=FALSE
PrinterPaperNames={"信纸","小号信纸","法律专用纸","Statement","Executive","A4","A4 小号","A5","B5 (JIS)","Folio","Quarto","便笺","信封 #9","信封 #10","信封 #11","信封 #12","信封 #14","信封 DL","信封 C5","信封 C6","信封 C65","信封 B5","信封 B6","信封","信封 Monarch","6 3/4 信封","德国标准 Fanfold"," 德国法律专用纸 Fanfold","日式明信片","Reserved48","Reserved49","信纸横向","A4 横向","信纸加大","A4 加大","A5 横向","B5 (JIS) 横向","A5 特大","B5 (ISO) 特大","日式往返明信片","A6","日式信封 Kaku #3","日式信封 Chou #3","日式信封 Chou #4","A5 旋转","日式明信片旋转","双层日式明信片旋转","A6 旋转","日式 信封 Chou #4 旋转","B6 (JIS)","B6 (JIS) 旋转","日式信封 You #4","PRC 16K","PRC 32K","PRC 32K(Big)","PRC 信封 #1","PRC 信封 #2","PRC 信封 #3","PRC 信封 #4","PRC 信封 #5","PRC 信封 #6","PRC 信封 #7","PRC 信封 #8","PRC 32K 旋转","PRC 32K(大)旋转","PRC 信封 #1 旋转","PRC 信封 #2 旋转","PRC 信封 #3 旋转","PRC 信封 #4 旋转","对折纸","Envelope Monarch"}
VerticalResolution=200
```

</details>

### 获取默认打印机信息

#### 获取默认打印机所有属性信息

```shell
wmic printer where "Default=TRUE" get /value
```

<details>
<summary>输出结果</summary>

```shell
Attributes=580
Availability=
AvailableJobSheets=
AveragePagesPerMinute=0
Capabilities={4,2,5}
CapabilityDescriptions={"Copies","Color","Collate"}
Caption=Microsoft XPS Document Writer
CharSetsSupported=
Comment=
ConfigManagerErrorCode=
ConfigManagerUserConfig=
CreationClassName=Win32_Printer
CurrentCapabilities=
CurrentCharSet=
CurrentLanguage=
CurrentMimeType=
CurrentNaturalLanguage=
CurrentPaperType=
Default=TRUE
DefaultCapabilities=
DefaultCopies=
DefaultLanguage=
DefaultMimeType=
DefaultNumberUp=
DefaultPaperType=
DefaultPriority=0
Description=
DetectedErrorState=0
DeviceID=Microsoft XPS Document Writer
Direct=FALSE
DoCompleteFirst=TRUE
DriverName=Microsoft XPS Document Writer v4
EnableBIDI=FALSE
EnableDevQueryPrint=FALSE
ErrorCleared=
ErrorDescription=
ErrorInformation=
ExtendedDetectedErrorState=0
ExtendedPrinterStatus=2
Hidden=FALSE
HorizontalResolution=600
InstallDate=
JobCountSinceLastReset=0
KeepPrintedJobs=FALSE
LanguagesSupported={48}
LastErrorCode=
Local=TRUE
Location=
MarkingTechnology=
MaxCopies=
MaxNumberUp=
MaxSizeSupported=
MimeTypesSupported=
Name=Microsoft XPS Document Writer
NaturalLanguagesSupported=
Network=FALSE
PaperSizesSupported={7,7,1,1,8,1,1,21,22,1,23,54,55,1,1,1,1,7,15,11,1,1,1,4,5,6,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,49,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
PaperTypesAvailable=
Parameters=
PNPDeviceID=
PortName=PORTPROMPT:
PowerManagementCapabilities=
PowerManagementSupported=
PrinterPaperNames={"Letter","Letter Small","Tabloid","Ledger","Legal","Statement","Executive","A3","A4","A4 Small","A5","B4 (JIS)","B5 (JIS)","Folio","Quarto","10×14","11×17","Note","Envelope #9","Envelope #10","Envelope #11","Envelope #12","Envelope #14","C size sheet","D size sheet","E size sheet","Envelope DL","Envelope C5","Envelope C3","Envelope C4","Envelope C6","Envelope C65","Envelope B4","Envelope B5","Envelope B6","Envelope","Envelope Monarch","6 3/4 Envelope","US Std Fanfold","German Std Fanfold","German Legal Fanfold","B4 (ISO)","Japanese Postcard","9×11","10×11","15×11","Envelope Invite","Letter Extra","Legal Extra","A4 Extra","Letter Transverse","A4 Transverse","Letter Extra Transverse","Super A","Super B","Letter Plus","A4 Plus","A5 Transverse","B5 (JIS) Transverse","A3 Extra","A5 Extra","B5 (ISO) Extra","A2","A3 Transverse","A3 Extra Transverse","Japanese Double Postcard","A6","Japanese Envelope Kaku #2","Japanese Envelope Kaku #3","Japanese Envelope Chou #3","Japanese Envelope Chou #4","Letter Rotated","A3 Rotated","A4 Rotated","A5 Rotated","B4 (JIS) Rotated","B5 (JIS) Rotated","Japanese Postcard Rotated","Double Japan Postcard Rotated","A6 Rotated","Japan Envelope Kaku #2 Rotated","Japan Envelope Kaku #3 Rotated","Japan Envelope Chou #3 Rotated","Japan Envelope Chou #4 Rotated","B6 (JIS)","B6 (JIS) Rotated","12×11","Japan Envelope You #4","Japan Envelope You #4 Rotated","PRC Envelope #1","PRC Envelope #3","PRC Envelope #4","PRC Envelope #5","PRC Envelope #6","PRC Envelope #7","PRC Envelope #8","PRC Envelope #9","PRC Envelope #10","PRC Envelope #1 Rotated","PRC Envelope #3 Rotated","PRC Envelope #4 Rotated","PRC Envelope #5 Rotated","PRC Envelope #6 Rotated","PRC Envelope #7 Rotated","PRC Envelope #8 Rotated","PRC Envelope #9 Rotated","User Defined Size"}
PrinterState=0
PrinterStatus=3
PrintJobDataType=RAW
PrintProcessor=winprint
Priority=1
Published=FALSE
Queued=FALSE
RawOnly=FALSE
SeparatorFile=
ServerName=
Shared=FALSE
ShareName=
SpoolEnabled=TRUE
StartTime=
Status=Unknown
StatusInfo=
SystemCreationClassName=Win32_ComputerSystem
SystemName=YXKFDA8
TimeOfLastReset=
UntilTime=
VerticalResolution=600
WorkOffline=FALSE
```

</details>

#### 获取默认打印机指定属性信息

```shell
wmic printer where "Default=TRUE" get Name,Default,Local,Network,EnableBIDI,HorizontalResolution,VerticalResolution,CapabilityDescriptions,PrinterPaperNames /value
```

<details>
<summary>输出结果</summary>

```shell
CapabilityDescriptions={"Copies","Color","Collate"}
Default=TRUE
EnableBIDI=FALSE
HorizontalResolution=600
Local=TRUE
Name=Microsoft XPS Document Writer
Network=FALSE
PrinterPaperNames={"Letter","Letter Small","Tabloid","Ledger","Legal","Statement","Executive","A3","A4","A4 Small","A5","B4 (JIS)","B5 (JIS)","Folio","Quarto","10×14","11×17","Note","Envelope #9","Envelope #10","Envelope #11","Envelope #12","Envelope #14","C size sheet","D size sheet","E size sheet","Envelope DL","Envelope C5","Envelope C3","Envelope C4","Envelope C6","Envelope C65","Envelope B4","Envelope B5","Envelope B6","Envelope","Envelope Monarch","6 3/4 Envelope","US Std Fanfold","German Std Fanfold","German Legal Fanfold","B4 (ISO)","Japanese Postcard","9×11","10×11","15×11","Envelope Invite","Letter Extra","Legal Extra","A4 Extra","Letter Transverse","A4 Transverse","Letter Extra Transverse","Super A","Super B","Letter Plus","A4 Plus","A5 Transverse","B5 (JIS) Transverse","A3 Extra","A5 Extra","B5 (ISO) Extra","A2","A3 Transverse","A3 Extra Transverse","Japanese Double Postcard","A6","Japanese Envelope Kaku #2","Japanese Envelope Kaku #3","Japanese Envelope Chou #3","Japanese Envelope Chou #4","Letter Rotated","A3 Rotated","A4 Rotated","A5 Rotated","B4 (JIS) Rotated","B5 (JIS) Rotated","Japanese Postcard Rotated","Double Japan Postcard Rotated","A6 Rotated","Japan Envelope Kaku #2 Rotated","Japan Envelope Kaku #3 Rotated","Japan Envelope Chou #3 Rotated","Japan Envelope Chou #4 Rotated","B6 (JIS)","B6 (JIS) Rotated","12×11","Japan Envelope You #4","Japan Envelope You #4 Rotated","PRC Envelope #1","PRC Envelope #3","PRC Envelope #4","PRC Envelope #5","PRC Envelope #6","PRC Envelope #7","PRC Envelope #8","PRC Envelope #9","PRC Envelope #10","PRC Envelope #1 Rotated","PRC Envelope #3 Rotated","PRC Envelope #4 Rotated","PRC Envelope #5 Rotated","PRC Envelope #6 Rotated","PRC Envelope #7 Rotated","PRC Envelope #8 Rotated","PRC Envelope #9 Rotated","User Defined Size"}
VerticalResolution=600
```

</details>

## 通过 PowerShell 管理打印机

<details>
<summary>打印相关 PowerShell 命令列表</summary>

```shell
CommandType     Name                                               Version    Source
-----------     ----                                               -------    ------
Function        Add-Printer                                        1.1        PrintManagement
Function        Add-PrinterDriver                                  1.1        PrintManagement
Function        Add-PrinterPort                                    1.1        PrintManagement
Function        Get-PrintConfiguration                             1.1        PrintManagement
Function        Get-Printer                                        1.1        PrintManagement
Function        Get-PrinterDriver                                  1.1        PrintManagement
Function        Get-PrinterPort                                    1.1        PrintManagement
Function        Get-PrinterProperty                                1.1        PrintManagement
Function        Get-PrintJob                                       1.1        PrintManagement
Function        Read-PrinterNfcTag                                 1.1        PrintManagement
Function        Remove-Printer                                     1.1        PrintManagement
Function        Remove-PrinterDriver                               1.1        PrintManagement
Function        Remove-PrinterPort                                 1.1        PrintManagement
Function        Remove-PrintJob                                    1.1        PrintManagement
Function        Rename-Printer                                     1.1        PrintManagement
Function        Restart-PrintJob                                   1.1        PrintManagement
Function        Resume-PrintJob                                    1.1        PrintManagement
Function        Set-PrintConfiguration                             1.1        PrintManagement
Function        Set-Printer                                        1.1        PrintManagement
Function        Set-PrinterProperty                                1.1        PrintManagement
Function        Suspend-PrintJob                                   1.1        PrintManagement
Function        Write-PrinterNfcTag                                1.1        PrintManagement
Cmdlet          Out-Printer                                        3.1.0.0    Microsoft.PowerShell.Utility
Application     EduPrintProv.exe                                   10.0.19... C:\Windows\system32\EduPrintProv.exe\
Application     print.exe                                          10.0.19... C:\Windows\system32\print.exe\
Application     printui.exe                                        10.0.19... C:\Windows\system32\printui.exe
```

</details>

### 设置默认打印机-PowerShell

```shell
(New-Object -ComObject WScript.Network).SetDefaultPrinter('Microsoft XPS Document Writer')
```

### 获取打印机信息-PowerShell

#### 获取全部打印机所有属性，并以列表形式输出

```shell
Get-Printer | Format-List
```

<details>
<summary>输出结果</summary>

```shell
Name                         : 导出为WPS PDF
ComputerName                 :
Type                         : Local
ShareName                    :
PortName                     : Kingsoft Virtual Printer Port
DriverName                   : Kingsoft Virtual Printer Driver
Location                     :
Comment                      :
SeparatorPageFile            :
PrintProcessor               : winprint
Datatype                     : NT EMF 1.006
Shared                       : False
Published                    : False
DeviceType                   : Print
PermissionSDDL               :
RenderingMode                :
KeepPrintedJobs              : False
Priority                     : 1
DefaultJobPriority           : 0
StartTime                    : 0
UntilTime                    : 0
PrinterStatus                : Normal
JobCount                     : 0
DisableBranchOfficeLogging   :
BranchOfficeOfflineLogSizeMB :
WorkflowPolicy               :

Name                         : ToDesk Printer
ComputerName                 :
Type                         : Local
ShareName                    :
PortName                     : TDXPSPrinterPort
DriverName                   : ToDesk Printer
Location                     :
Comment                      :
SeparatorPageFile            :
PrintProcessor               : winprint
Datatype                     : RAW
Shared                       : False
Published                    : False
DeviceType                   : Print
PermissionSDDL               :
RenderingMode                :
KeepPrintedJobs              : False
Priority                     : 1
DefaultJobPriority           : 0
StartTime                    : 0
UntilTime                    : 0
PrinterStatus                : Normal
JobCount                     : 0
DisableBranchOfficeLogging   :
BranchOfficeOfflineLogSizeMB :
WorkflowPolicy               :

Name                         : Microsoft XPS Document Writer
ComputerName                 :
Type                         : Local
ShareName                    :
PortName                     : PORTPROMPT:
DriverName                   : Microsoft XPS Document Writer v4
Location                     :
Comment                      :
SeparatorPageFile            :
PrintProcessor               : winprint
Datatype                     : RAW
Shared                       : False
Published                    : False
DeviceType                   : Print
PermissionSDDL               :
RenderingMode                :
KeepPrintedJobs              : False
Priority                     : 1
DefaultJobPriority           : 0
StartTime                    : 0
UntilTime                    : 0
PrinterStatus                : Normal
JobCount                     : 0
DisableBranchOfficeLogging   :
BranchOfficeOfflineLogSizeMB :
WorkflowPolicy               :

Name                         : Microsoft Print To PDF
ComputerName                 :
Type                         : Local
ShareName                    :
PortName                     : PORTPROMPT:
DriverName                   : Microsoft Print To PDF
Location                     :
Comment                      :
SeparatorPageFile            :
PrintProcessor               : winprint
Datatype                     : RAW
Shared                       : False
Published                    : False
DeviceType                   : Print
PermissionSDDL               :
RenderingMode                :
KeepPrintedJobs              : False
Priority                     : 1
DefaultJobPriority           : 0
StartTime                    : 0
UntilTime                    : 0
PrinterStatus                : Normal
JobCount                     : 0
DisableBranchOfficeLogging   :
BranchOfficeOfflineLogSizeMB :
WorkflowPolicy               :

Name                         : Fax
ComputerName                 :
Type                         : Local
ShareName                    :
PortName                     : SHRFAX:
DriverName                   : Microsoft Shared Fax Driver
Location                     :
Comment                      :
SeparatorPageFile            :
PrintProcessor               : winprint
Datatype                     : RAW
Shared                       : False
Published                    : False
DeviceType                   : Print
PermissionSDDL               :
RenderingMode                :
KeepPrintedJobs              : False
Priority                     : 1
DefaultJobPriority           : 0
StartTime                    : 0
UntilTime                    : 0
PrinterStatus                : Normal
JobCount                     : 0
DisableBranchOfficeLogging   :
BranchOfficeOfflineLogSizeMB :
WorkflowPolicy               :
```

</details>

#### 获取指定打印机所有属性，并以列表形式输出

```shell
Get-Printer -Name "Microsoft XPS Document Writer" | Format-List
```

<details>
<summary>输出结果</summary>

```shell
Name                         : Microsoft XPS Document Writer
ComputerName                 :
Type                         : Local
ShareName                    :
PortName                     : PORTPROMPT:
DriverName                   : Microsoft XPS Document Writer v4
Location                     :
Comment                      :
SeparatorPageFile            :
PrintProcessor               : winprint
Datatype                     : RAW
Shared                       : False
Published                    : False
DeviceType                   : Print
PermissionSDDL               :
RenderingMode                :
KeepPrintedJobs              : False
Priority                     : 1
DefaultJobPriority           : 0
StartTime                    : 0
UntilTime                    : 0
PrinterStatus                : Normal
JobCount                     : 0
DisableBranchOfficeLogging   :
BranchOfficeOfflineLogSizeMB :
WorkflowPolicy               :
```

</details>

#### 指定属性、排序方式，并以表格形式输出

```shell
Get-Printer | Select-Object -Property Name,Type,Shared,Published | Sort-Object -Property Name
```

<details>
<summary>输出结果</summary>

```shell
Name                                     Type Shared Published
----                                     ---- ------ ---------
Fax                                     Local  False     False
Microsoft Print To PDF                  Local  False     False
Microsoft XPS Document Writer           Local  False     False
ToDesk Printer                          Local  False     False
导出为WPS PDF                           Local  False     False
```

</details>

#### 指定属性、排序方式，并以列表形式输出

```shell
Get-Printer | Select-Object -Property Name,Type,Shared,Published | Sort-Object -Property Name | Format-List
```

<details>
<summary>输出结果</summary>

```shell
Name      : Fax
Type      : Local
Shared    : False
Published : False

Name      : Microsoft Print To PDF
Type      : Local
Shared    : False
Published : False

Name      : Microsoft XPS Document Writer
Type      : Local
Shared    : False
Published : False

Name      : ToDesk Printer
Type      : Local
Shared    : False
Published : False

Name      : 导出为WPS PDF
Type      : Local
Shared    : False
Published : False
```

</details>

### 获取打印机配置信息

```shell
Get-PrintConfiguration "Microsoft XPS Document Writer" | Select-Object -Property PrinterName,Color,DuplexingMode
```

<details>
<summary>输出结果</summary>

```shell
PrinterName                   Color DuplexingMode
-----------                   ----- -------------
Microsoft XPS Document Writer False      OneSided
```

</details>

