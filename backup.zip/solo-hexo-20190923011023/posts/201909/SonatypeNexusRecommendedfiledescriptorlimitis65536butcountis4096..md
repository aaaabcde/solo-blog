title: 'Sonatype Nexus: Recommended file descriptor limit is 65536 but count is 4096.'
date: '2019-09-20 17:10:33'
updated: '2019-09-20 17:31:34'
tags: [Sonatype, Nexus, Linux, Mac]
permalink: /sonatype-nexus-3-linux-file-descriptor-limit
---
## 问题说明

在 CentOS 或其他 Linux 系统上安装 __Sonatype Nexus Repository Manager__，配置完毕启动登录后，在 `/support/status` 状态页面的 __File Descriptors__ 项目可能会显示 _Recommended file descriptor limit is 65536 but count is 4096._ 警告。

原因是 Nexus 3 将很有可能要消耗比 Linux 或 OSX 操作系统允许每个用户的默认文件句柄数（4096）更多的数量。

> 耗尽文件描述符可能是灾难性的，并且很可能导致数据丢失。确保在启动之前将运行 Nexus Repository Manager 的用户打开的文件描述符的数量限制永久增加到 65,536 个或更多。

## 解决方法

在多数 Linux 系统上，可以通过编辑 `/etc/security/limits.conf` 文件为特定用户设置持久限制。若要将 Nexus 用户的软限制和硬限制的最大打开文件数设置为 65536，请在 `/etc/security/limits.conf` 文件中添加以下行，其中 “nexus” 应该替换为用于运行 `Nexus` 的用户登录名（如 `root`）：

~~~
nexus - nofile 65536
~~~

保存此配置文件后重启 Nexus，文件描述符状态恢复正常：

![image.png](https://img.hacpai.com/file/2019/09/image-c25cd8f7.png)

## 参考链接：

> <https://help.sonatype.com/repomanager3/system-requirements#SystemRequirements-AdequateFileHandleLimits>
