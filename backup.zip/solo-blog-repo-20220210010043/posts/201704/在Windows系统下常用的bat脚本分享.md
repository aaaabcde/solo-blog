title: 在 Windows 系统下常用的 bat 脚本分享
date: '2017-04-22 18:43:44'
updated: '2019-02-17 21:35:24'
tags: [分享, bat, Windows]
permalink: /articles/2017/04/21/1492777994685.html
---

以网络配置举例说明，网络连接默认情况下都是 DHCP（自动获取 IP 和 DNS 地址） 模式，但很多情况下，需要我们设置为指定的静态 IP 和 DNS 地址。在 Windows 系统中通常我们都是在系统托盘中右键网络图标，点击 ` 打开网络和共享中心 ` → ` 更改适配器设置 ` → ` 右键 以太网（WLAN...） 属性` → ` IPv4 属性 ` 这样一步一步的来修改，即繁琐又浪费时间，所以在这里将自己常用的 bat 脚本分享出来，使用后多多少少能节省一点时间，提高工作效率。

### 1. WLAN（以太网等）静态IP / DHCP 快速配置脚本
因鄙人所在公司的网络是进行了监控和限制了的，每个人都分有一个连接互联网的 IP 地址，就连 QQ 也是限制登录了的，只要使用公司的网络就只有登记的工作 QQ 可以登录的上去。因为在公司用的是自己的电脑，在家的时候都是使用自动获取 IP 的模式，到公司就得改成静态 IP，所以使用 bat 脚本一键修改 IP 可以节约很多时间。废话有点多了...上图：
> ![静态IP / DHCP 快速配置](https://res.zixizixi.cn/4df63b1ea76d4fae9ad095246caa7501.png.zximg)

**使用方法：**
> ![IPChange使用方法](https://res.zixizixi.cn/file/2017/4/e92025c9ca8f411db5470cb44ed8c200-IPCS.png.zximg) 
> 
> 绿色框线部分设为自己常用的静态 IP 配置，使用时直接选择第 2 项回车即可。变量 ` Nic ` 对应网络连接中的 ` WLAN ` 或 ` 以太网 ` （Win7 以前的应该叫 本地连接）：
> ![网络连接](https://res.zixizixi.cn/file/2017/4/53ee1ea4fd9c4adfa17519f67f59e99a-net.png.zximg) 
> 
> [iTanken官方下载地址](https://www.itanken.cn/docs/bat/IP快速配置工具.rar)
> [七牛云备用下载地址](https://res.zixizixi.cn/file/2017/4/d60d159878a541c98aa41f7b0db6bc64-IP.rar)
> 

### 2. MySQL（SQL Server等）服务快速启动关闭脚本
用来快速启动和关闭 MySQL / SQL Server(默认实例的服务名为 MSSQLSERVER)等服务，和快速打开 MySQL 的管理程序 SQLyog（SQL Server 为 SSMS，即 SQL Server Management Studio）：
> 
> **MySQL 快速启动：**
> 我安装的是 MySQL 5.7,服务名为 ` MySQL57`,打开脚本时会先启动或关闭服务，然后再显示选择菜单。
> ![MYSQL 服务](https://res.zixizixi.cn/file/2017/4/c9c4c0fd141d4ada8b84578358105350-MYSQL.png.zximg) 
> 
> **SQL Server 服务快速启动：**
> 与 MySQL 的启动方式一致，默认的服务名为 `MSSQLSERVER`，我之前在自己的电脑上安装的实例名为 SSS，服务名为 MSSQL$SSS，因为重装系统后只安装了 SSMS，没有安装数据库实例，所以下图中会显示服务名无效。一会下面会介绍查看服务名的方法。
> ![MSSQL 服务](https://res.zixizixi.cn/file/2017/4/0fea284ef9c74317bde4befe4a69abbd-MSSQL.png.zximg) 
> 图中的 ` 打开 SQL Server ` 意思是打开 SQL Server Management Studio，使用了 SSMS 快捷命令。第 3 项 ` 重新运行命令 ` 的意思是，如果服务已经启动则关闭，否则启动相应的服务。
> 
> #### 查看 Windows 系统服务名的方法：
> 1. 打开系统 ` 服务 ` 界面，可在运行窗口中使用 ` services.msc ` 快捷命令：
> ![打开服务界面](https://res.zixizixi.cn/file/2017/4/7e4ddf2c9d7a41a683c81ccb74836a5a-services.png.zximg) 
> 
> 2. 右键对应的服务查看 ` 属性 `：
> ![查看服务属性](https://res.zixizixi.cn/file/2017/4/749c315919ca4fe8ab9e23256d9d9647-servicename.png.zximg) 
> 需要查看的就是蓝色框线中的 ` 服务名称 `。
> 
> 直接在运行窗口中运行服务可使用命令 ` net start 服务名 ` 来启动相应的服务。
> 
> [iTanken官方下载地址](https://www.itanken.cn/docs/bat/MySql和MSSQL服务快速启动关闭工具.rar)
> [七牛云备用下载地址](https://res.zixizixi.cn/file/2017/4/5a588884291b4087ad2c3eef901c1836-MySqlMSSQL.rar)
> 

### 3. Nginx 服务管理功能脚本
Windows 版 Nginx 的快速管理工具，可以一键启动、关闭、重启、验证配置文件等：
> ![Nginx 管理工具](https://res.zixizixi.cn/file/2017/4/8b7f0dd57ffe4ee6a330912a250084e3-Nginx.png.zximg) 
> 
> 这里的重启是先关闭，再启动；这里的刷新是 Nginx 的 reload 命令。
> 
> [iTanken官方下载地址](https://www.itanken.cn/docs/bat/Nginx管理工具.rar)
> [七牛云备用下载地址](https://res.zixizixi.cn/file/2017/4/43b5d33d341449b69625ad8296aecdbb-Nginx.rar) 
> 

### 4. sfc 一键修复命令
sfc 全称为 SystemFileChecker，是用来检查和修复系统文件的比较有用的一个命令，但我也不太常用。需要的话直接复制下面的代码新建保存为 .bat 格式的文件使用。
> ```bat
> @echo off
> color 0f
> title Windows 一键修复
> @echo.
> @echo 右键 以管理员身份运行(A)
> C:\WINDOWS\system32\sfc.exe /scannow
> @echo.
> @echo Done.
> rem shutdown
> @echo.
> @pause
> ```
>

### 5. 一键清理垃圾文件
用来清除 Windows 系统下的缓存文件、日志文件、回收站文件和备份文件等垃圾文件。个人不太常用，在网上都能查的到。
> ```bat
> @echo off 
> title 一键清除系统垃圾
> echo 正在清除系统垃圾文件，请稍等...... 
> echo.
> del /f /s /q %systemdrive%\*.tmp 
> del /f /s /q %systemdrive%\*._mp 
> del /f /s /q %systemdrive%\*.log 
> del /f /s /q %systemdrive%\*.gid 
> del /f /s /q %systemdrive%\*.chk 
> del /f /s /q %systemdrive%\*.old 
> del /f /s /q %systemdrive%\recycled\*.* 
> del /f /s /q %windir%\*.bak 
> del /f /s /q %windir%\prefetch\*.* 
> rd /s /q %windir%\temp & md %windir%\temp 
> del /f /q %userprofile%\cookies\*.* 
> del /f /q %userprofile%\recent\*.* 
> del /f /s /q "%userprofile%\Local Settings\Temporary Internet Files\*.*" 
> del /f /s /q "%userprofile%\Local Settings\Temp\*.*" 
> del /f /s /q "%userprofile%\recent\*.*" 
> echo.
> echo 清除系统垃圾完成！ 
> echo. & pause 
> ```
> 

### 6. Windows 快捷运行小技巧
在 Windows 中，已经习惯了用 Win + R 运行命令的方式快速打开应用程序，通常我会创建一个专用的文件夹，配置在环境变量的 Path 里，将常用的程序的快捷方式和 bat 脚本等放在该目录中后修改成一个简短的名称，就可以通过这个简短的名称直接运行相应的程序或 bat 脚本了，比如最常用的一个命令 ` ipconfig `，查看 IP 配置信息，我会创建一个名为 IP.bat 的文件，内容如下：
> ```bat
> @echo off
> color 0f
> title 查看本机 IP 配置信息
> ipconfig /all
> echo.
> pause
> ```
> 
然后按 Win + R 输入 ` IP ` 直接回车即可查看 IP 配置信息。
> **运行目录：**
> ![运行目录](https://res.zixizixi.cn/file/2017/4/81750941d9ff4280aad918fc75255ff3-Run.png.zximg) 
>
> **环境变量：**
> ![环境变量](https://res.zixizixi.cn/file/2017/4/84cab61547354f1aa2afc3e0177cbced-Path.png.zximg) 
> 
> **小提示：Windows 系统下选中文件或文件夹，按住 Alt 键，直接拖动到相应的位置，即可在当前位置创建快捷方式。**
> 

``` 不定期更新 ```