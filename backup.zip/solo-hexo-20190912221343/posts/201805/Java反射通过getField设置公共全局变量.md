title: Java 反射：通过 getField() 设置公共全局变量
date: '2018-05-31 14:27:26'
updated: '2019-04-07 00:34:10'
tags: [Java, 反射]
permalink: /java-reflection-getfield
---
![java-reflection-getfield](https://res.zixizixi.cn/file/2018/05/4a371c219e10468cac5cb02e3c4692a8_javareflectiongetfield.png.coverimg "java-reflection-getfield") 

# Java 通过 getField() 操作公共全局变量

以前写 JavaWeb 项目启动初始化系统配置全局变量的代码，都是 `variable = Properties.getProperty(name)` 这样一行一行代码的设置，变量少还好说，变量一多真的很磨叽。所以一直想通过 `循环` 简化代码，重构某个项目时无意间发现了 Java 反射中的 `getField()` 以及其他相关方法，节省了大量代码，所以在此记录一下。由于反射的 `性能` 问题，只在系统启动时初始化数据使用。


## 依赖工具类 PropertiesUtils
```java
package net.itanken.test.util;

import java.util.Properties;

public class PropertiesUtils {

    private static Properties props = new Properties();

    public static final String get(String key) {
        return props.getProperty(key, "");
    }
	
    // 省略 Properties.load() 等其他相关代码
}
```

## 全局配置类 Configuration
重点代码为 `Configuration.class.getField(name).set(Configuration.class, value);`，在 `foreach` 循环中设置非空配置对应变量的值，`.properties` 文件中的 `key` 需与要设置的变量名一致。

``` java
package net.itanken.test.basic;

import net.itanken.test.util.PropertiesUtils;

/**
 * System Config
 * @author T
 * @since 20180530
 */
public class Configuration {

    public static String sysName = "系统名称";

    public static String sysVer = "系统版本";

    public static String resVer = "静态资源版本";

    public static String support = "技术支持";

    public static String copyright = "版权声明";

    public static final boolean initConfig() {
        String[] names = new String[]{"sysName", "sysVer", "resVer", "support", "copyright"};

        String value = null;
        try {
            for (String name : names) {
                value = PropertiesUtils.get(name);
                if (value.length() > 0) {
                    Configuration.class.getField(name).set(Configuration.class, value);
                }
                // System.out.println(name + "=" + Configuration.class.getField(name).get(Configuration.class));
            }
        } catch (Exception e) {
            return false;
        }
        return true;
    }

}
``` 

## 测试结果

嗯，测试结果与 `.properties` 文件中的配置一致，OK。
``` java
sysName=自定义系统显示名称
sysVer=67.0.3396.62（正式版）
resVer=20180530150546
support=Technical support provided by StarSevenSky Studio.
copyright=©2018 子兮子兮 版权所有
``` 

## 其他

`Class.getField(String name)` 方法用于获取由 `public` 修饰的公共成员字段，获取 `private` 修饰的私有成员字段可使用 `Class.getDeclaredField(String name)` 方法。
与之对应的获取 **所有** 公共成员字段 和 私有成员字段 的方法为 `Class.getFields()` 和 `Class.getDeclaredFields()`。
另外从代码中可以看出，获取和设置字段值的方法分别为 `get()` 和 `set()`。

PS. `以前对 getField 及其他相关方法并不了解，完全是依靠 IDE 的代码提示功能在偶然间发现的，多亏了我的 IDE。`


> | 内容声明 @Seves |
> | :-------- |
> | 本文链接：[https://zixizixi.cn/](https://zixizixi.cn/ '原文地址') |
> | 版权说明：</a>本作品采用<a rel="license" href="https://creativecommons.org/licenses/by-sa/4.0/deed.zh" target="_blank">知识共享署名-相同方式共享 4.0 国际许可协议</a>进行许可。 <a rel="license" href="https://creativecommons.org/licenses/by-sa/4.0/deed.zh" target="_blank"><img src="https://i.creativecommons.org/l/by-sa/4.0/80x15.png" style="vertical-align: middle;"></a> |
> | 本文发布于 [子兮子兮](https://zixizixi.cn/ '内容来源')</a> 个人博客，欢迎转载，但未经作者同意请在页面明显位置保留此声明，谢谢。 |

