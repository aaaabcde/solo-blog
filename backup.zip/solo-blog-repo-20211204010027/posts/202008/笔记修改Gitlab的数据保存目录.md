title: 【笔记】修改 Gitlab 的数据保存目录
date: '2020-08-06 16:00:49'
updated: '2020-08-06 16:03:25'
tags: [笔记, Git, Gitlab]
permalink: /configure-gitlab-data-dir
---
要修改 GitLab 的仓库数据存储目录，需要依次执行以下命令和操作：

1. 停止 GitLab，防止在移动存储库时有用户写入数据：

   ```bash
   sudo gitlab-ctl stop
   ```

2. 编辑配置文件：

   ```bash
   sudo code /etc/gitlab/gitlab.rb
   # code --user-data-dir / /etc/gitlab/gitlab.rb
   ```

   或

   ```bash
   sudo vim /etc/gitlab/gitlab.rb
   ```

   找到 `git_data_dirs` 配置项，并修改 `path` 参数：

   ```rb
   git_data_dirs({
     "default" => { "path" => "/home/Workspace/GitLab/data" }
   }) 
   ```

3. 同步数据目录文件：

   ```bash
   sudo rsync -av /var/opt/gitlab/git-data/repositories /home/Workspace/GitLab/data/
   ```

4.  启动必要的进程并运行 `reconfigure` 来修复权限：

    ```bash
    sudo gitlab-ctl upgrade
    ```

5. 再次检查新数据目录的配置，预期输出 `repositories`：

   ```bash
   sudo ls /home/Workspace/GitLab/data/
   ```

6. 启动 GitLab 并确保可以在 Web 界面中浏览存储库：

   ```bash
   sudo gitlab-ctl start
   ```

