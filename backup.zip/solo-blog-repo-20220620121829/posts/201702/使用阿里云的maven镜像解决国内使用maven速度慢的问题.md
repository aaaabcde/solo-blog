title: 使用阿里云的maven镜像解决国内使用maven速度慢的问题
date: '2017-02-13 17:55:24'
updated: '2017-04-15 19:28:54'
tags: [阿里巴巴, Maven]
permalink: /articles/2017/02/13/1486979524858.html
---
### 国内 maven 访问速度慢问题处理

#### 阿里云 maven 镜像地址：[http://maven.aliyun.com/nexus/content/groups/public/](http://maven.aliyun.com/nexus/content/groups/public/)

开发中使用 maven 的猿猿们都知道，在国内 maven 的访问效率那叫一个速(坑)度(爹)…之前国内也有开源中国的镜像可以使用，但是貌似也已经死翘翘了，直到最近发现了神奇的阿里巴巴的 maven 镜像，使用之后才体会到什么叫做痛快。

废话打住，下面是 maven 的 .m2 目录下的 `settings.xml` 中， mirrors 节点的阿里云 maven 镜像配置：

```xml
<mirror>
	<id>alimaven</id>
	<name>aliyun maven</name>
	<url>http://maven.aliyun.com/nexus/content/groups/public/</url>
	<mirrorOf>central</mirrorOf>
</mirror>
```

### `settings.xml` 完整配置：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<settings xmlns="http://maven.apache.org/SETTINGS/1.0.0"
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.0.0 http://maven.apache.org/xsd/settings-1.0.0.xsd">
	<localRepository>/Users/用户名/.m2/repository</localRepository>
	<pluginGroups/>
	<proxies/>
	<servers/>
	<mirrors>
		<mirror>
			<id>alimaven</id>
			<name>aliyun maven</name>
			<url>http://maven.aliyun.com/nexus/content/groups/public/</url>
			<mirrorOf>central</mirrorOf>
		</mirror>
	</mirrors>
	<profiles>
	</profiles>
</settings>
```

## 相关参考资料：

云栖社区：[https://yq.aliyun.com/articles/46991](https://yq.aliyun.com/articles/46991)

### Maven相关知识

> Maven 是一个项目管理和综合工具。Maven 提供了开发人员构建一个完整的生命周期框架。开发团队可以自动完成项目的基础工具建设，Maven 使用标准的目录结构和默认构建生命周期。
> 
> 在多个开发团队环境时，Maven 可以设置按标准在非常短的时间里完成配置工作。由于大部分项目的设置都很简单，并且可重复使用，Maven 让开发人员的工作更轻松，同时创建报表，检查，构建和测试自动化设置。

Maven提供了开发人员的方式来管理：

*   Builds
*   Documentation
*   Reporting
*   Dependencies
*   SCMs
*   Releases
*   Distribution
*   mailing list

概括地说，Maven简化和标准化项目建设过程。处理编译，分配，文档，团队协作和其他任务的无缝连接。 Maven增加可重用性并负责建立相关的任务。
