title: RDP 剪贴板单向失效问题处理：Windows 远程桌面 mstsc 只能“远程→本地”，不能“本地→远程”
date: '2026-02-11 10:29:33'
updated: '2026-02-11 10:34:05'
tags: [Windows, 远程, Q&amp, A]
permalink: /windows-mstsc-rdp-clipboard-can-only-copy-in-one-direction
---
在使用 **Windows mstsc 远程桌面** 时，经常会遇到一个剪贴板复制粘贴问题：

> ✔ 可以从远程服务器复制内容到本机
> ✘ 但无法从本机复制内容到远程服务器

这种情况本质上是 **RDP 剪贴板重定向通道异常**，通常与客户端配置、rdpclip 进程、组策略或企业安全策略有关。本文提供一套从基础到企业级环境的 **完整排查与修复流程**，适用于 Windows 10 / 11 / Server 系列。

---

## 一、问题本质解析

RDP 使用 **虚拟通道（Virtual Channel）** 同步剪贴板数据，其中关键组件为：

```cmd
rdpclip.exe
```

当以下任一环节异常时，可能出现：

- 剪贴板完全失效
- 只能单向复制
- 只能复制文本，不能复制文件或图片

---

## 二、基础排查

### 1. 检查 mstsc 是否开启剪贴板重定向

在本机执行：

```cmd
mstsc → 显示选项 → 本地资源
```

确认勾选「剪贴板」：

![本地资源](https://i.zixizixi.cn/api/images/1_1770775357_14d83a.png "剪贴板")

如果未勾选，复制将无法从本地同步到远程。

---

### 2. 重启远程机 rdpclip 进程

当剪贴板只能单向复制粘贴时，最有可能是由于 rdpclip 进程异常。在远程服务器中：

#### 打开任务管理器

结束进程：

```cmd
rdpclip.exe
```

按 <kbd>Win</kbd> + <kbd>R</kbd> 快捷键重新启动：

```cmd
rdpclip.exe
```

#### 原理

**rdpclip** 是 RDP 剪贴板同步代理：

- 崩溃后会出现单向复制
- 卡死后会完全无法复制

---

### 3. 检查远程机组策略限制

远程服务器执行：

```cmd
gpedit.msc
```

路径：

```cmd
计算机配置
 └ 管理模板
    └ Windows 组件
       └ 远程桌面服务
          └ 远程桌面会话主机
             └ 设备和资源重定向
```

检查策略：

```cmd
不允许剪贴板重定向
```

必须为 **未配置** 或 **已禁用**。

---

## 三、企业环境常见原因

### 4. .rdp 文件限制剪贴板

如果使用 `.rdp` 文件连接：

检查是否存在：

```ini
redirectclipboard:i:0
```

修改为：

```ini
redirectclipboard:i:1
```

---

### 5. 安全软件或终端管控策略

企业环境中极常见，例如：

- 深信服
- 奇安信
- CrowdStrike
- 火绒企业版
- Symantec

可能策略：

- 禁止数据外发
- 阻止虚拟通道
- 限制剪贴板同步

#### 典型表现

| 现象            | 可能原因   |
| ----------------- | ------------- |
| 只能复制文本 | DLP策略  |
| 图片无法复制 | 通道过滤  |
| 文件复制失败 | 安全审计  |

---

### 6. 域控策略限制

---

按 <kbd>Win</kbd> + <kbd>R</kbd> 快捷键执行：

```cmd
rsop.msc
```

查看：

```cmd
Remote Desktop Services
Clipboard Redirection
```

---

## 四、高级排查

### 7. 检查 RDP 会话状态

```cmd
qwinsta
```

确认存在：

```
rdp-tcp#x
```

---

### 8. 查看 RDP 事件日志

路径：

```cmd
事件查看器
 └ Applications and Services Logs
    └ Microsoft
       └ Windows
          └ TerminalServices-LocalSessionManager
```

---

### 9. 检查注册表策略

远程服务器注册表：

```cmd
HKEY_LOCAL_MACHINE
 └ SOFTWARE
  └ Policies
   └ Microsoft
    └ Windows NT
     └ Terminal Services
```

键值：

```
fDisableClip
```

应为 `0` 或不存在。

---

## 五、生产环境快速修复流程（推荐）

---

按以下顺序执行：

---

### Step 1

- 断开远程连接
- 重新连接并勾选「剪贴板」：
  ![本地资源](https://i.zixizixi.cn/api/images/1_1770775357_14d83a.png "剪贴板")

---

### Step 2

远程服务器执行：

```cmd
taskkill /im rdpclip.exe /f
```

```cmd
start rdpclip.exe
```

---

### Step 3

刷新策略：

```cmd
gpupdate /force
```

---

### Step 4

注销远程用户会话

> 注意：不是重启服务器！

---

## 六、企业级长期优化建议

### 建议一：部署 rdpclip 守护脚本

定时检测：

```cmd
rdpclip.exe
```

是否运行。

异常自动重启。

---

### 建议二：统一 RDP 模板文件

集中维护模板：

```cmd
mstsc.rdp
```

避免策略漂移。

---

### 建议三：建立 RDP 故障标准排查表

建议记录：

- 是否域环境
- 是否安装安全软件
- 是否仅单台服务器异常
- 是否仅单用户异常

---

## 七、总结

Windows 远程桌面出现 **只能远程→本地复制** 的情况，本质上是剪贴板虚拟通道异常。常见原因包括：

- mstsc 未开启剪贴板
- rdpclip 进程异常
- 组策略限制
- .rdp 参数关闭
- 企业安全软件阻断

优先检查：

```
mstsc 勾选 → 重启 rdpclip → 组策略
```

大多数问题都可以解决。

