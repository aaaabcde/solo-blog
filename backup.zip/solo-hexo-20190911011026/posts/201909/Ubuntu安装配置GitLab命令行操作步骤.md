title: Ubuntu 安装配置 GitLab 命令行操作步骤
date: '2019-09-09 09:39:01'
updated: '2019-09-10 00:13:34'
tags: [Git, Gitlab, 命令行, 译文]
permalink: /ubuntu-install-gitlab
---
## 特别说明

如果要在 WSL （适用于 Linux 的 Windows 子系统）中安装 GitLab，则必须使用内部版本号为 18917 或更高版本的 Windows 系统，并将 WSL 升级到 WSL 2（也支持安装 Docker）。
> 参考链接：<https://docs.microsoft.com/zh-cn/windows/wsl/wsl2-install>

## 安装和配置必要的依赖项

```sh
sudo apt-get update
```

```sh
sudo apt-get install -y curl openssh-server ca-certificates
```

### 安装 Postfix 用于发送通知邮件

```sh
sudo apt-get install -y postfix
```

安装 `Postfix` 过程中选择 `Internet Site` 并回车，然后输入要发送邮件的邮箱地址域。
如发送方邮件地址为 `username@example.com`，则输入 `example.com`，然后回车。

## 添加 GitLab 包存储库并安装

### 添加 GitLab 包存储库

```sh
curl https://packages.gitlab.com/install/repositories/gitlab/gitlab-ee/script.deb.sh | sudo bash
```

### 安装 GitLab

```sh
sudo apt-get install gitlab-ee
```

## 配置 GitLab

安装完成后，执行以下命令编辑配置文件中的访问地址 `external_url` 和邮箱等设置：

```sh
# 使用 VIM 编辑
sudo vim /etc/gitlab/gitlab.rb

# 使用 GEdit 编辑
sudo gedit /etc/gitlab/gitlab.rb
```

如：

```
external_url 'http://192.168.1.6:666'
```

## 启动 GitLab

配置完成后，执行以下命令启动 GitLab 实例：

```sh
sudo gitlab-ctl reconfigure
```

启用 GitLab 开机自动启动：
```sh
sudo systemctl enable gitlab-runsvdir.service
```

禁用 GitLab 开机自动启动：
```sh
sudo systemctl disable gitlab-runsvdir.service
```

## 登录

使用配置好的 `external_url` 地址进行访问，第一次访问将被重定向到一个密码重置页面。密码重置完成后将被重定向到登录页面，使用默认管理帐户的用户名 `root` 及刚刚重置的密码进行登录。

## 其他常用命令

### 停止

```sh
sudo gitlab-ctl stop
```

### 启动

```sh
sudo gitlab-ctl start
```

### 重启

```sh
sudo gitlab-ctl restart
```

### 状态

```sh
sudo gitlab-ctl status
```

### 日志

```sh
sudo gitlab-ctl tail
```

> 参考链接：<https://about.gitlab.com/install/#ubuntu>
