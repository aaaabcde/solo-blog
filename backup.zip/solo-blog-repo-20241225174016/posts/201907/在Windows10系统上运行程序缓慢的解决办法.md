title: 在 Windows 10 系统上运行程序缓慢的解决办法
date: '2019-07-24 13:30:24'
updated: '2019-10-10 21:19:06'
tags: [Windows, 译文, 优化]
permalink: /windows-defender-app-startup-stop-slow
---
由于本人 Windows 10 系统的电脑未安装任何第三方安全软件，启用了系统自带的 Windows Defender，而微软的 Windows 安全性一直使某些应用程序的启动速度非常缓慢，但 Windows 允许用户为可信应用程序添加排除项，并绕过扫描以加快启动速度。这就是在 Windows 10 上启动/停止程序缓慢的解决方法。

下面将以 Eclipse 和 MyEclipse 为例，来说明添加 Windows Defender 排除项的必要性和操作步骤。

如下图所示，闲置的 Windows Defender 的 CPU 使用率几乎不可察觉；然而，当打开 Eclipse 或 MyEclipse 时，它突然开始使用大量资源，使大多数用户的启动速度变慢。  
![image.png](https://b3logfile.com/file/2019/07/image-13cff9c2.png)

感谢 Windows Defender 占用的 CPU 使用率从 15％ 到 20％ 不等。
![image.png](https://b3logfile.com/file/2019/07/image-9e319178.png)

好处是 Windows 安全中心允许向我们信任的某些进程添加排除项，因此我们可以排除 Eclipse 和 MyEclipse 并绕过扫描。

以下是向 Windows 安全添加排除项的步骤列表，这是一个非常简单的过程，不需要花费超过 5 分钟的时间来完成，并且将来会节省很多时间。

**步骤：**

1. 右键单击“**开始**”图标并选择“**设置**”或在“开始”菜单上点击“**设置**”图标，打开“Windows 设置”。   
![image.png](https://b3logfile.com/file/2019/07/image-a18b9efa.png)

2. 在“Windows 设置”中，选择“**更新和安全**”。
![image.png](https://b3logfile.com/file/2019/07/image-c1aad98c.png)

3. 在左侧栏中，选择“**Windows 安全中心**”。 

4. 在 Windows 安全中心的“保护区域”下选择“**病毒和威胁防护**”。
![image.png](https://b3logfile.com/file/2019/07/image-262d04e0.png)

5. 在“病毒和威胁防护”设置中，选择“**管理设置**”。
![image.png](https://b3logfile.com/file/2019/07/image-b9c68352.png)

6. 在病毒和威胁防护设置上，向下滚动，直至看到排除项，然后选择“**添加或删除排除项**”。 
![image.png](https://b3logfile.com/file/2019/07/image-8c33fc4e.png)

7. 点击“**添加排除项**”，然后选择“**进程**”。
![image.png](https://b3logfile.com/file/2019/07/image-18359688.png)

8. 对于 Eclipse，输入**eclipse.exe** 作为进程名称，然后单击“**添加**”；
对于 MyEclipse，输入**myeclipse.exe** 作为进程名称，然后单击“**添加**”。 
![image.png](https://b3logfile.com/file/2019/07/image-860b24f0.png)![image.png](https://b3logfile.com/file/2019/07/image-7ec1f067.png)

9. Windows 要求获取应用这些更改的权限时，请选择“**是**”。

如下图所示，eclipse.exe 和 myeclipse.exe 的排除都处于活动状态。![image.png](https://b3logfile.com/file/2019/07/image-59825c3b.png)

这将修复启动 Eclipse 或 MyEclipse 时加载时间过长的问题，还可以在打开这些进程时减少 CPU 负载，并为我们提供更快更好的体验。希望这个迷你指南可以帮助您改善Eclipse/MyEclipse 的体验。

其他可信任的应用程序在启动时如果 Windows Defender 的 CUP 使用率过高，也可以采用上面的步骤进行操作，能够在一定程度上提高程序的运行性能。可通过任务管理器的“详细信息”查看应用程序的进程“名称”：
![image.png](https://b3logfile.com/file/2019/07/image-2a31aaa7.png)

或者，也可以通过关闭 Windows 10 自带的 Windows Defender 功能来解决此问题，但不推荐。

> 参考资料：[https://www.genuitec.com/stop-slow-eclipse-myeclipse-startups/](https://www.genuitec.com/stop-slow-eclipse-myeclipse-startups/)
> Translate by <https://zixizixi.cn>
